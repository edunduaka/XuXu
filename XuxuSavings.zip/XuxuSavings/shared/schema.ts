import { pgTable, text, serial, integer, boolean, date, timestamp, decimal, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  firstName: text("first_name").notNull(),
  middleName: text("middle_name"),
  lastName: text("last_name").notNull(),
  email: text("email").notNull().unique(),
  phoneNumber: text("phone_number").notNull(),
  phoneCountryCode: text("phone_country_code"),
  phoneNationalNumber: text("phone_national_number"),
  dateOfBirth: date("date_of_birth").notNull(),
  gender: text("gender").notNull(),
  selfieImage: text("selfie_image"),
  region: text("region"),
  country: text("country").notNull(),
  state: text("state").notNull(),
  city: text("city").notNull(),
  address1: text("address1").notNull(),
  address2: text("address2"),
  idType: text("id_type"),
  idDocumentPath: text("id_document_path"),
  password: text("password").notNull(),
  emailHash: text("email_hash").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const groups = pgTable("groups", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  contributionAmount: decimal("contribution_amount", { precision: 10, scale: 2 }).notNull(),
  frequency: text("frequency").notNull(), // weekly, monthly, etc.
  maxMembers: integer("max_members").notNull(),
  currentMembers: integer("current_members").default(1).notNull(),
  startDate: date("start_date").notNull(),
  status: text("status").default("recruiting").notNull(), // recruiting, active, completed
  creatorId: integer("creator_id").notNull().references(() => users.id),
  inviteCode: text("invite_code").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const groupMembers = pgTable("group_members", {
  id: serial("id").primaryKey(),
  groupId: integer("group_id").notNull().references(() => groups.id),
  userId: integer("user_id").notNull().references(() => users.id),
  role: text("role").default("member").notNull(), // creator, member
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
  isActive: boolean("is_active").default(true).notNull(),
});

export const contributions = pgTable("contributions", {
  id: serial("id").primaryKey(),
  groupId: integer("group_id").notNull().references(() => groups.id),
  memberId: integer("member_id").notNull().references(() => users.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  contributionDate: date("contribution_date").notNull(),
  status: text("status").default("pending").notNull(), // pending, completed, missed
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  createdGroups: many(groups),
  groupMemberships: many(groupMembers),
  contributions: many(contributions),
}));

export const groupsRelations = relations(groups, ({ one, many }) => ({
  creator: one(users, {
    fields: [groups.creatorId],
    references: [users.id],
  }),
  members: many(groupMembers),
  contributions: many(contributions),
}));

export const groupMembersRelations = relations(groupMembers, ({ one }) => ({
  group: one(groups, {
    fields: [groupMembers.groupId],
    references: [groups.id],
  }),
  user: one(users, {
    fields: [groupMembers.userId],
    references: [users.id],
  }),
}));

export const contributionsRelations = relations(contributions, ({ one }) => ({
  group: one(groups, {
    fields: [contributions.groupId],
    references: [groups.id],
  }),
  member: one(users, {
    fields: [contributions.memberId],
    references: [users.id],
  }),
}));

// Create the base schemas
const baseInsertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  emailHash: true, // Generated automatically on server
});

const baseInsertGroupSchema = createInsertSchema(groups).omit({
  id: true,
  createdAt: true,
  currentMembers: true,
});

const baseInsertGroupMemberSchema = createInsertSchema(groupMembers).omit({
  id: true,
  joinedAt: true,
});

const baseInsertContributionSchema = createInsertSchema(contributions).omit({
  id: true,
  createdAt: true,
});

// Then modify them to handle date/decimal fields for API requests
export const insertUserSchema = baseInsertUserSchema.extend({
  dateOfBirth: z.string().transform((str) => new Date(str)),
  selfieImage: z.string().optional(),
  region: z.string().optional(),
  idType: z.string().optional(),
});

export const insertGroupSchema = baseInsertGroupSchema.extend({
  startDate: z.string().transform((str) => new Date(str)),
  contributionAmount: z.string().transform((str) => str),
});

export const insertGroupMemberSchema = baseInsertGroupMemberSchema;

export const insertContributionSchema = baseInsertContributionSchema.extend({
  contributionDate: z.string().transform((str) => new Date(str)),
  amount: z.string().transform((str) => str),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertGroup = z.infer<typeof insertGroupSchema>;
export type Group = typeof groups.$inferSelect;
export type InsertGroupMember = z.infer<typeof insertGroupMemberSchema>;
export type GroupMember = typeof groupMembers.$inferSelect;
export type InsertContribution = z.infer<typeof insertContributionSchema>;
export type Contribution = typeof contributions.$inferSelect;
