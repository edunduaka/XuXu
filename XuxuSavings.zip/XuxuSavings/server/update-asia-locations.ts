// Update Asia location data with authentic geographical information
import { writeFileSync, readFileSync } from 'fs';
import { join } from 'path';
import { asiaLocationData } from './asia-location-data';

export function updateAsiaLocationData() {
  console.log('🌏 Updating Asia region with authentic location data...');
  
  try {
    // Read existing processed countries data
    const existingDataPath = join(process.cwd(), 'processed-countries.json');
    let existingCountries = [];
    
    try {
      const existingData = readFileSync(existingDataPath, 'utf-8');
      existingCountries = JSON.parse(existingData);
    } catch (error) {
      console.log('Creating new countries data file...');
      existingCountries = [];
    }
    
    // Create a map of existing countries for faster lookup
    const existingCountriesMap = new Map();
    existingCountries.forEach((country: any) => {
      existingCountriesMap.set(country.code, country);
    });
    
    // Update with authentic Asia data
    asiaLocationData.countries.forEach(asiaCountry => {
      if (existingCountriesMap.has(asiaCountry.code)) {
        // Update existing Asian country with authentic data
        const existingIndex = existingCountries.findIndex((c: any) => c.code === asiaCountry.code);
        if (existingIndex !== -1) {
          existingCountries[existingIndex] = {
            name: asiaCountry.name,
            code: asiaCountry.code,
            states: asiaCountry.states
          };
          console.log(`✅ Updated ${asiaCountry.name} with ${asiaCountry.states.length} states`);
        }
      } else {
        // Add new Asian country
        existingCountries.push({
          name: asiaCountry.name,
          code: asiaCountry.code,
          states: asiaCountry.states
        });
        console.log(`✅ Added ${asiaCountry.name} with ${asiaCountry.states.length} states`);
      }
    });
    
    // Sort countries alphabetically
    existingCountries.sort((a: any, b: any) => a.name.localeCompare(b.name));
    
    // Write updated data back to file
    writeFileSync(existingDataPath, JSON.stringify(existingCountries, null, 2), 'utf-8');
    
    console.log('🎉 Asia location data updated successfully!');
    console.log(`📊 Total Asian countries with detailed data: ${asiaLocationData.countries.length}`);
    
    // Log summary of what was updated
    asiaLocationData.countries.forEach(country => {
      const totalCities = country.states.reduce((sum, state) => sum + state.cities.length, 0);
      console.log(`   ${country.name}: ${country.states.length} states, ${totalCities} cities`);
    });
    
    return true;
  } catch (error) {
    console.error('❌ Error updating Asia location data:', error);
    return false;
  }
}

// Run the update function
updateAsiaLocationData();