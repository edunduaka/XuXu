// Advanced Load Balancer for Xuxu Financial Platform
// Implements multiple load balancing algorithms for optimal performance

import { Request, Response, NextFunction } from 'express';
import { createHash } from 'crypto';

export interface ServerInstance {
  id: string;
  host: string;
  port: number;
  weight: number;
  healthStatus: 'healthy' | 'unhealthy' | 'maintenance';
  activeConnections: number;
  responseTime: number;
  lastHealthCheck: Date;
  region: string;
}

export type LoadBalancingAlgorithm = 
  | 'round-robin' 
  | 'weighted-round-robin' 
  | 'least-connections' 
  | 'ip-hash' 
  | 'geographic' 
  | 'response-time'
  | 'resource-based';

export interface LoadBalancerConfig {
  algorithm: LoadBalancingAlgorithm;
  healthCheckInterval: number;
  maxRetries: number;
  timeout: number;
  stickySession: boolean;
  geoRouting: boolean;
  autoScaling: boolean;
}

export class XuxuLoadBalancer {
  private servers: ServerInstance[] = [];
  private currentIndex = 0;
  private config: LoadBalancerConfig;
  private healthCheckTimer?: NodeJS.Timeout;
  private requestCounts = new Map<string, number>();
  private sessionMap = new Map<string, string>();

  constructor(config: LoadBalancerConfig) {
    this.config = config;
    this.initializeDefaultServers();
    this.startHealthChecks();
  }

  private initializeDefaultServers(): void {
    // Initialize multiple server instances for load distribution
    this.servers = [
      {
        id: 'primary-1',
        host: '0.0.0.0',
        port: 5000,
        weight: 3,
        healthStatus: 'healthy',
        activeConnections: 0,
        responseTime: 50,
        lastHealthCheck: new Date(),
        region: 'primary'
      },
      {
        id: 'secondary-1',
        host: '0.0.0.0',
        port: 5001,
        weight: 2,
        healthStatus: 'healthy',
        activeConnections: 0,
        responseTime: 75,
        lastHealthCheck: new Date(),
        region: 'secondary'
      },
      {
        id: 'cache-server',
        host: '0.0.0.0',
        port: 5002,
        weight: 1,
        healthStatus: 'healthy',
        activeConnections: 0,
        responseTime: 25,
        lastHealthCheck: new Date(),
        region: 'cache'
      }
    ];
  }

  // Round Robin Load Balancing
  private roundRobinSelect(): ServerInstance | null {
    const healthyServers = this.getHealthyServers();
    if (healthyServers.length === 0) return null;
    
    const server = healthyServers[this.currentIndex % healthyServers.length];
    this.currentIndex = (this.currentIndex + 1) % healthyServers.length;
    return server;
  }

  // Weighted Round Robin Load Balancing
  private weightedRoundRobinSelect(): ServerInstance | null {
    const healthyServers = this.getHealthyServers();
    if (healthyServers.length === 0) return null;

    // Calculate total weight
    const totalWeight = healthyServers.reduce((sum, server) => sum + server.weight, 0);
    let randomWeight = Math.random() * totalWeight;

    for (const server of healthyServers) {
      randomWeight -= server.weight;
      if (randomWeight <= 0) {
        return server;
      }
    }

    return healthyServers[0];
  }

  // Least Connections Load Balancing
  private leastConnectionsSelect(): ServerInstance | null {
    const healthyServers = this.getHealthyServers();
    if (healthyServers.length === 0) return null;

    return healthyServers.reduce((min, server) => 
      server.activeConnections < min.activeConnections ? server : min
    );
  }

  // IP Hash Load Balancing (Sticky Sessions)
  private ipHashSelect(clientIP: string): ServerInstance | null {
    const healthyServers = this.getHealthyServers();
    if (healthyServers.length === 0) return null;

    const hash = createHash('md5').update(clientIP).digest('hex');
    const index = parseInt(hash.substr(0, 8), 16) % healthyServers.length;
    return healthyServers[index];
  }

  // Geographic Load Balancing
  private geographicSelect(clientRegion: string): ServerInstance | null {
    const healthyServers = this.getHealthyServers();
    if (healthyServers.length === 0) return null;

    // Try to find server in same region first
    const regionalServer = healthyServers.find(server => server.region === clientRegion);
    if (regionalServer) return regionalServer;

    // Fallback to least connections
    return this.leastConnectionsSelect();
  }

  // Response Time Based Load Balancing
  private responseTimeSelect(): ServerInstance | null {
    const healthyServers = this.getHealthyServers();
    if (healthyServers.length === 0) return null;

    return healthyServers.reduce((fastest, server) => 
      server.responseTime < fastest.responseTime ? server : fastest
    );
  }

  // Resource-Based Load Balancing
  private resourceBasedSelect(): ServerInstance | null {
    const healthyServers = this.getHealthyServers();
    if (healthyServers.length === 0) return null;

    // Calculate load score based on connections and response time
    return healthyServers.reduce((best, server) => {
      const serverLoad = (server.activeConnections * 0.7) + (server.responseTime * 0.3);
      const bestLoad = (best.activeConnections * 0.7) + (best.responseTime * 0.3);
      return serverLoad < bestLoad ? server : best;
    });
  }

  // Main server selection method
  public selectServer(req: Request): ServerInstance | null {
    const clientIP = this.getClientIP(req);
    const clientRegion = this.detectClientRegion(req);

    // Check for sticky session
    if (this.config.stickySession && this.sessionMap.has(clientIP)) {
      const sessionServerId = this.sessionMap.get(clientIP)!;
      const server = this.servers.find(s => s.id === sessionServerId);
      if (server && server.healthStatus === 'healthy') {
        return server;
      }
    }

    let selectedServer: ServerInstance | null = null;

    switch (this.config.algorithm) {
      case 'round-robin':
        selectedServer = this.roundRobinSelect();
        break;
      case 'weighted-round-robin':
        selectedServer = this.weightedRoundRobinSelect();
        break;
      case 'least-connections':
        selectedServer = this.leastConnectionsSelect();
        break;
      case 'ip-hash':
        selectedServer = this.ipHashSelect(clientIP);
        break;
      case 'geographic':
        selectedServer = this.geographicSelect(clientRegion);
        break;
      case 'response-time':
        selectedServer = this.responseTimeSelect();
        break;
      case 'resource-based':
        selectedServer = this.resourceBasedSelect();
        break;
      default:
        selectedServer = this.roundRobinSelect();
    }

    // Set sticky session if enabled
    if (selectedServer && this.config.stickySession) {
      this.sessionMap.set(clientIP, selectedServer.id);
    }

    return selectedServer;
  }

  // Health Check Implementation
  private async performHealthCheck(server: ServerInstance): Promise<boolean> {
    try {
      const startTime = Date.now();
      
      // Simulate health check (in real implementation, this would be an HTTP request)
      const isHealthy = server.healthStatus !== 'maintenance' && Math.random() > 0.05; // 95% success rate
      
      const responseTime = Date.now() - startTime;
      server.responseTime = responseTime;
      server.lastHealthCheck = new Date();
      server.healthStatus = isHealthy ? 'healthy' : 'unhealthy';

      return isHealthy;
    } catch (error) {
      server.healthStatus = 'unhealthy';
      return false;
    }
  }

  private startHealthChecks(): void {
    this.healthCheckTimer = setInterval(async () => {
      for (const server of this.servers) {
        await this.performHealthCheck(server);
      }
    }, this.config.healthCheckInterval);
  }

  // Utility Methods
  private getHealthyServers(): ServerInstance[] {
    return this.servers.filter(server => server.healthStatus === 'healthy');
  }

  private getClientIP(req: Request): string {
    return req.ip || 
           req.headers['x-forwarded-for'] as string || 
           req.headers['x-real-ip'] as string || 
           req.connection.remoteAddress || 
           '127.0.0.1';
  }

  private detectClientRegion(req: Request): string {
    // In a real implementation, this would use GeoIP or similar service
    const userAgent = req.headers['user-agent'] || '';
    const acceptLanguage = req.headers['accept-language'] || '';
    
    // Simple region detection based on language
    if (acceptLanguage.includes('ar')) return 'middle-east';
    if (acceptLanguage.includes('en-US')) return 'north-america';
    if (acceptLanguage.includes('en-GB')) return 'europe';
    
    return 'primary';
  }

  // Connection Management
  public incrementConnections(serverId: string): void {
    const server = this.servers.find(s => s.id === serverId);
    if (server) {
      server.activeConnections++;
    }
  }

  public decrementConnections(serverId: string): void {
    const server = this.servers.find(s => s.id === serverId);
    if (server && server.activeConnections > 0) {
      server.activeConnections--;
    }
  }

  // Monitoring and Analytics
  public getLoadBalancerStats() {
    return {
      totalServers: this.servers.length,
      healthyServers: this.getHealthyServers().length,
      algorithm: this.config.algorithm,
      totalConnections: this.servers.reduce((sum, server) => sum + server.activeConnections, 0),
      averageResponseTime: this.servers.reduce((sum, server) => sum + server.responseTime, 0) / this.servers.length,
      servers: this.servers.map(server => ({
        id: server.id,
        status: server.healthStatus,
        connections: server.activeConnections,
        responseTime: server.responseTime,
        region: server.region
      }))
    };
  }

  // Auto-scaling triggers
  private checkAutoScaling(): void {
    if (!this.config.autoScaling) return;

    const totalConnections = this.servers.reduce((sum, server) => sum + server.activeConnections, 0);
    const averageLoad = totalConnections / this.servers.length;

    // Scale up if average load > 80%
    if (averageLoad > 80) {
      console.log('🚀 Auto-scaling triggered: High load detected');
      // In production, this would trigger server provisioning
    }

    // Scale down if average load < 20%
    if (averageLoad < 20 && this.servers.length > 1) {
      console.log('📉 Auto-scaling triggered: Low load detected');
      // In production, this would trigger server decommissioning
    }
  }

  // Cleanup
  public shutdown(): void {
    if (this.healthCheckTimer) {
      clearInterval(this.healthCheckTimer);
    }
    this.sessionMap.clear();
    this.requestCounts.clear();
  }
}

// Load Balancer Middleware
export function createLoadBalancerMiddleware(config: LoadBalancerConfig) {
  const loadBalancer = new XuxuLoadBalancer(config);

  return (req: Request, res: Response, next: NextFunction) => {
    const selectedServer = loadBalancer.selectServer(req);
    
    if (!selectedServer) {
      return res.status(503).json({
        error: 'Service Temporarily Unavailable',
        message: 'No healthy servers available',
        timestamp: new Date().toISOString()
      });
    }

    // Add server info to request for monitoring
    req.selectedServer = selectedServer;
    
    // Increment connection count
    loadBalancer.incrementConnections(selectedServer.id);

    // Add cleanup on response finish
    res.on('finish', () => {
      loadBalancer.decrementConnections(selectedServer.id);
    });

    // Add load balancer stats to response headers
    res.setHeader('X-Load-Balancer-Server', selectedServer.id);
    res.setHeader('X-Load-Balancer-Algorithm', config.algorithm);
    
    next();
  };
}

// Default load balancer configuration
export const defaultLoadBalancerConfig: LoadBalancerConfig = {
  algorithm: 'resource-based',
  healthCheckInterval: 30000, // 30 seconds
  maxRetries: 3,
  timeout: 5000,
  stickySession: true,
  geoRouting: true,
  autoScaling: true
};

// Load balancer factory
export function createXuxuLoadBalancer(customConfig?: Partial<LoadBalancerConfig>): XuxuLoadBalancer {
  const config = { ...defaultLoadBalancerConfig, ...customConfig };
  return new XuxuLoadBalancer(config);
}

// Export types for external use
declare global {
  namespace Express {
    interface Request {
      selectedServer?: ServerInstance;
    }
  }
}

export default XuxuLoadBalancer;