// Update Middle East location data with authentic geographical information
import { writeFileSync, readFileSync } from 'fs';
import { join } from 'path';
import { middleEastLocationData } from './middle-east-location-data';

export function updateMiddleEastLocationData() {
  console.log('🌏 Updating Middle East region with authentic location data...');
  
  try {
    // Read existing processed countries data
    const existingDataPath = join(process.cwd(), 'server/processed-countries.json');
    let existingCountries = [];
    
    try {
      const existingData = readFileSync(existingDataPath, 'utf-8');
      existingCountries = JSON.parse(existingData);
    } catch (error) {
      console.log('Reading existing countries data...');
      existingCountries = [];
    }
    
    // Create a map of existing countries for faster lookup
    const existingCountriesMap = new Map();
    existingCountries.forEach((country: any) => {
      existingCountriesMap.set(country.code, country);
    });
    
    // Update with authentic Middle East data
    middleEastLocationData.countries.forEach(middleEastCountry => {
      if (existingCountriesMap.has(middleEastCountry.code)) {
        // Update existing Middle Eastern country with authentic data
        const existingIndex = existingCountries.findIndex((c: any) => c.code === middleEastCountry.code);
        if (existingIndex !== -1) {
          existingCountries[existingIndex] = {
            name: middleEastCountry.name,
            code: middleEastCountry.code,
            states: middleEastCountry.states
          };
          console.log(`✅ Updated ${middleEastCountry.name} with ${middleEastCountry.states.length} states`);
        }
      } else {
        // Add new Middle Eastern country
        existingCountries.push({
          name: middleEastCountry.name,
          code: middleEastCountry.code,
          states: middleEastCountry.states
        });
        console.log(`✅ Added ${middleEastCountry.name} with ${middleEastCountry.states.length} states`);
      }
    });
    
    // Sort countries alphabetically
    existingCountries.sort((a: any, b: any) => a.name.localeCompare(b.name));
    
    // Write updated data back to file
    writeFileSync(existingDataPath, JSON.stringify(existingCountries, null, 2), 'utf-8');
    
    console.log('🎉 Middle East location data updated successfully!');
    console.log(`📊 Total Middle Eastern countries with detailed data: ${middleEastLocationData.countries.length}`);
    
    // Log summary of what was updated
    middleEastLocationData.countries.forEach(country => {
      const totalCities = country.states.reduce((sum, state) => sum + state.cities.length, 0);
      console.log(`   ${country.name}: ${country.states.length} states, ${totalCities} cities`);
    });
    
    return true;
  } catch (error) {
    console.error('❌ Error updating Middle East location data:', error);
    return false;
  }
}

// Run the update function
updateMiddleEastLocationData();