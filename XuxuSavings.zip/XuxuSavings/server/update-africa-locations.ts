// Update Africa location data with authentic geographical information
import { writeFileSync, readFileSync } from 'fs';
import { join } from 'path';
import { africaLocationData } from './africa-location-data';

export function updateAfricaLocationData() {
  console.log('🌍 Updating Africa region with authentic location data...');
  
  try {
    // Read existing processed countries data
    const existingDataPath = join(process.cwd(), 'processed-countries.json');
    let existingCountries = [];
    
    try {
      const existingData = readFileSync(existingDataPath, 'utf-8');
      existingCountries = JSON.parse(existingData);
    } catch (error) {
      console.log('Creating new countries data file...');
      existingCountries = [];
    }
    
    // Create a map of existing countries for faster lookup
    const existingCountriesMap = new Map();
    existingCountries.forEach((country: any) => {
      existingCountriesMap.set(country.code, country);
    });
    
    // Update with authentic Africa data
    africaLocationData.countries.forEach(africaCountry => {
      if (existingCountriesMap.has(africaCountry.code)) {
        // Update existing African country with authentic data
        const existingIndex = existingCountries.findIndex((c: any) => c.code === africaCountry.code);
        if (existingIndex !== -1) {
          existingCountries[existingIndex] = {
            name: africaCountry.name,
            code: africaCountry.code,
            states: africaCountry.states
          };
          console.log(`✅ Updated ${africaCountry.name} with ${africaCountry.states.length} states`);
        }
      } else {
        // Add new African country
        existingCountries.push({
          name: africaCountry.name,
          code: africaCountry.code,
          states: africaCountry.states
        });
        console.log(`✅ Added ${africaCountry.name} with ${africaCountry.states.length} states`);
      }
    });
    
    // Sort countries alphabetically
    existingCountries.sort((a: any, b: any) => a.name.localeCompare(b.name));
    
    // Write updated data back to file
    writeFileSync(existingDataPath, JSON.stringify(existingCountries, null, 2), 'utf-8');
    
    console.log('🎉 Africa location data updated successfully!');
    console.log(`📊 Total African countries with detailed data: ${africaLocationData.countries.length}`);
    
    // Log summary of what was updated
    africaLocationData.countries.forEach(country => {
      const totalCities = country.states.reduce((sum, state) => sum + state.cities.length, 0);
      console.log(`   ${country.name}: ${country.states.length} states, ${totalCities} cities`);
    });
    
    return true;
  } catch (error) {
    console.error('❌ Error updating Africa location data:', error);
    return false;
  }
}

// Run the update function
updateAfricaLocationData();