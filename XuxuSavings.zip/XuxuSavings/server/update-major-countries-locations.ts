import { readFileSync, writeFileSync } from 'fs';
import { join } from 'path';

// Major countries with comprehensive authentic state/province data
const majorCountriesData = {
  countries: [
    {
      name: "India",
      code: "IN",
      region: "Asia",
      states: [
        { name: "Andhra Pradesh", code: "AP", cities: ["Hyderabad", "Visakhapatnam", "Vijayawada", "Guntur", "Nellore", "Kurnool", "Rajahmundry", "Kadapa", "Kakinada", "Tirupati", "Anantapur", "Vizianagaram", "Eluru", "Ongole", "Nandyal", "Machilipatnam", "Adoni", "Tenali", "Chittoor", "Hindupur"] },
        { name: "Arunachal Pradesh", code: "AR", cities: ["Itanagar", "Naharlagun", "Pasighat", "Aalo", "Bomdila", "Tawang", "Ziro", "Tezu", "Changlang", "Khonsa", "Namsai", "Seppa", "Yingkiong", "Roing", "Anini", "Hawai", "Koloriang", "Daporijo", "Basar", "Mechuka"] },
        { name: "Assam", code: "AS", cities: ["Guwahati", "Silchar", "Dibrugarh", "Jorhat", "Nagaon", "Tinsukia", "Tezpur", "Bongaigaon", "Dhubri", "North Lakhimpur", "Karimganj", "Sibsagar", "Goalpara", "Barpeta", "Mangaldoi", "Diphu", "Haflong", "Kokrajhar", "Hojai", "Morigaon"] },
        { name: "Bihar", code: "BR", cities: ["Patna", "Gaya", "Bhagalpur", "Muzaffarpur", "Purnia", "Darbhanga", "Bihar Sharif", "Arrah", "Begusarai", "Katihar", "Munger", "Chhapra", "Danapur", "Saharsa", "Sasaram", "Hajipur", "Dehri", "Siwan", "Motihari", "Nawada"] },
        { name: "Chhattisgarh", code: "CG", cities: ["Raipur", "Bhilai", "Bilaspur", "Korba", "Durg", "Rajnandgaon", "Jagdalpur", "Raigarh", "Ambikapur", "Mahasamund", "Dhamtari", "Chirmiri", "Bhatapara", "Dalli-Rajhara", "Naila Janjgir", "Tilda Newra", "Mungeli", "Manendragarh", "Sakti", "Akaltara"] },
        { name: "Delhi", code: "DL", cities: ["New Delhi", "Delhi", "North Delhi", "South Delhi", "East Delhi", "West Delhi", "Central Delhi", "North East Delhi", "North West Delhi", "South East Delhi", "South West Delhi", "Shahdara", "Najafgarh", "Narela", "Rohini", "Dwarka", "Vasant Kunj", "Karol Bagh", "Connaught Place", "Lajpat Nagar"] },
        { name: "Goa", code: "GA", cities: ["Panaji", "Vasco da Gama", "Margao", "Mapusa", "Ponda", "Bicholim", "Curchorem", "Sanquelim", "Cuncolim", "Quepem", "Canacona", "Pernem", "Sanguem", "Aldona", "Arambol", "Anjuna", "Calangute", "Candolim", "Colva", "Benaulim"] },
        { name: "Gujarat", code: "GJ", cities: ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar", "Jamnagar", "Junagadh", "Gandhinagar", "Anand", "Navsari", "Morbi", "Nadiad", "Surendranagar", "Bharuch", "Mehsana", "Bhuj", "Porbandar", "Palanpur", "Valsad", "Vapi"] },
        { name: "Haryana", code: "HR", cities: ["Gurugram", "Faridabad", "Panipat", "Ambala", "Yamunanagar", "Rohtak", "Hisar", "Karnal", "Sonipat", "Panchkula", "Bhiwani", "Sirsa", "Bahadurgarh", "Jind", "Thanesar", "Kaithal", "Rewari", "Narnaul", "Pundri", "Kosli"] },
        { name: "Himachal Pradesh", code: "HP", cities: ["Shimla", "Dharamshala", "Solan", "Mandi", "Palampur", "Baddi", "Nahan", "Paonta Sahib", "Sundarnagar", "Chamba", "Una", "Kullu", "Hamirpur", "Bilaspur", "Yol", "Jubbal", "Chail", "Kasauli", "Manali", "Dalhousie"] },
        { name: "Jharkhand", code: "JH", cities: ["Ranchi", "Jamshedpur", "Dhanbad", "Bokaro", "Deoghar", "Phusro", "Hazaribagh", "Giridih", "Ramgarh", "Medininagar", "Chirkunda", "Chaibasa", "Gumla", "Dumka", "Godda", "Sahebganj", "Pakur", "Simdega", "Khunti", "Seraikela"] },
        { name: "Karnataka", code: "KA", cities: ["Bangalore", "Mysore", "Hubli-Dharwad", "Mangalore", "Belgaum", "Gulbarga", "Davanagere", "Bellary", "Bijapur", "Shimoga", "Tumkur", "Raichur", "Bidar", "Hospet", "Hassan", "Gadag-Betigeri", "Udupi", "Bhadravati", "Chitradurga", "Kolar"] },
        { name: "Kerala", code: "KL", cities: ["Thiruvananthapuram", "Kochi", "Kozhikode", "Thrissur", "Kollam", "Palakkad", "Alappuzha", "Malappuram", "Kannur", "Kasaragod", "Idukki", "Ernakulam", "Kottayam", "Wayanad", "Pathanamthitta", "Perinthalmanna", "Chalakudy", "Changanassery", "Kalpetta", "Munnar"] },
        { name: "Madhya Pradesh", code: "MP", cities: ["Bhopal", "Indore", "Gwalior", "Jabalpur", "Ujjain", "Sagar", "Dewas", "Satna", "Ratlam", "Rewa", "Murwara", "Singrauli", "Burhanpur", "Khandwa", "Bhind", "Chhindwara", "Guna", "Shivpuri", "Vidisha", "Chhatarpur"] },
        { name: "Maharashtra", code: "MH", cities: ["Mumbai", "Pune", "Nagpur", "Thane", "Nashik", "Aurangabad", "Solapur", "Amravati", "Virar", "Navi Mumbai", "Sangli", "Malegaon", "Akola", "Latur", "Dhule", "Ahmednagar", "Chandrapur", "Parbhani", "Ichalkaranji", "Jalna"] },
        { name: "Manipur", code: "MN", cities: ["Imphal", "Thoubal", "Bishnupur", "Churachandpur", "Ukhrul", "Senapati", "Tamenglong", "Chandel", "Jiribam", "Kangpokpi", "Tengnoupal", "Pherzawl", "Noney", "Kamjong", "Kakching", "Moreh", "Sugnu", "Pallel", "Kumbi", "Moirang"] },
        { name: "Meghalaya", code: "ML", cities: ["Shillong", "Tura", "Cherrapunji", "Jowai", "Nongstoin", "Baghmara", "Williamnagar", "Resubelpara", "Ampati", "Mairang", "Mawkyrwat", "Khliehriat", "Nongpoh", "Sohra", "Dawki", "Bholaganj", "Umiam", "Mawsynram", "Nongthymmai", "Laitumkhrah"] },
        { name: "Mizoram", code: "MZ", cities: ["Aizawl", "Lunglei", "Saiha", "Champhai", "Kolasib", "Serchhip", "Mamit", "Lawngtlai", "Saitual", "Khawzawl", "Hnahthial", "Bairabi", "North Vanlaiphai", "Thenzawl", "Tlabung", "Zawlnuam", "Darlawn", "Biate", "Tuipang", "Lungsen"] },
        { name: "Nagaland", code: "NL", cities: ["Kohima", "Dimapur", "Mokokchung", "Tuensang", "Wokha", "Zunheboto", "Phek", "Kiphire", "Longleng", "Peren", "Mon", "Noklak", "Chumukedima", "Tseminyu", "Tuli", "Bhandari", "Jalukie", "Tizit", "Aboi", "Changtongya"] },
        { name: "Odisha", code: "OR", cities: ["Bhubaneswar", "Cuttack", "Rourkela", "Berhampur", "Sambalpur", "Puri", "Balasore", "Bhadrak", "Baripada", "Jharsuguda", "Jeypore", "Barbil", "Khordha", "Kendujhar", "Sunabeda", "Rayagada", "Paradip", "Kendrapara", "Dhenkanal", "Koraput"] },
        { name: "Punjab", code: "PB", cities: ["Ludhiana", "Amritsar", "Jalandhar", "Patiala", "Bathinda", "Mohali", "Firozpur", "Batala", "Pathankot", "Moga", "Abohar", "Malerkotla", "Khanna", "Phagwara", "Muktsar", "Barnala", "Rajpura", "Hoshiarpur", "Kapurthala", "Faridkot"] },
        { name: "Rajasthan", code: "RJ", cities: ["Jaipur", "Jodhpur", "Kota", "Bikaner", "Ajmer", "Udaipur", "Bhilwara", "Alwar", "Bharatpur", "Sikar", "Pali", "Sri Ganganagar", "Kishangarh", "Baran", "Dhaulpur", "Tonk", "Beawar", "Hanumangarh", "Gangapur City", "Banswara"] },
        { name: "Sikkim", code: "SK", cities: ["Gangtok", "Namchi", "Geyzing", "Mangan", "Jorethang", "Naya Bazar", "Rangpo", "Singtam", "Yuksom", "Pelling", "Ravangla", "Soreng", "Dentam", "Legship", "Hee Bermiok", "Rhenock", "Pakyong", "Rongli", "Chungthang", "Lachung"] },
        { name: "Tamil Nadu", code: "TN", cities: ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem", "Tirunelveli", "Tiruppur", "Vellore", "Erode", "Thoothukkudi", "Dindigul", "Thanjavur", "Ranipet", "Sivakasi", "Karur", "Udhagamandalam", "Hosur", "Nagercoil", "Kanchipuram", "Kumarakonam"] },
        { name: "Telangana", code: "TG", cities: ["Hyderabad", "Warangal", "Nizamabad", "Khammam", "Karimnagar", "Ramagundam", "Mahabubnagar", "Nalgonda", "Adilabad", "Suryapet", "Miryalaguda", "Jagtial", "Mancherial", "Nirmal", "Kothagudem", "Bodhan", "Sangareddy", "Metpally", "Zahirabad", "Armoor"] },
        { name: "Tripura", code: "TR", cities: ["Agartala", "Dharmanagar", "Udaipur", "Kailashahar", "Belonia", "Khowai", "Teliamura", "Bishalgarh", "Ambassa", "Ranirbazar", "Sonamura", "Sabroom", "Kumarghat", "Panisagar", "Longtharai Valley", "Jirania", "Kamalasagar", "Melaghar", "Mohanpur", "Gandacherra"] },
        { name: "Uttar Pradesh", code: "UP", cities: ["Lucknow", "Kanpur", "Ghaziabad", "Agra", "Varanasi", "Meerut", "Allahabad", "Bareilly", "Aligarh", "Moradabad", "Saharanpur", "Gorakhpur", "Noida", "Firozabad", "Jhansi", "Muzaffarnagar", "Mathura", "Rampur", "Shahjahanpur", "Farrukhabad"] },
        { name: "Uttarakhand", code: "UT", cities: ["Dehradun", "Haridwar", "Roorkee", "Haldwani-cum-Kathgodam", "Rudrapur", "Kashipur", "Rishikesh", "Pithoragarh", "Jaspur", "Manglaur", "Kotdwara", "Nainital", "Mussoorie", "Tehri", "Pauri", "Bageshwar", "Champawat", "Almora", "Rudraprayag", "Chamoli"] },
        { name: "West Bengal", code: "WB", cities: ["Kolkata", "Howrah", "Durgapur", "Asansol", "Siliguri", "Malda", "Bardhaman", "Barasat", "Raiganj", "Kharagpur", "Naihati", "English Bazar", "Bankura", "Dabgram-Fulbari", "Purulia", "Haldia", "Habra", "Ranaghat", "Medinipur", "Jalpaiguri"] }
      ]
    },
    {
      name: "Germany",
      code: "DE",
      region: "Europe",
      states: [
        { name: "Baden-Württemberg", code: "BW", cities: ["Stuttgart", "Mannheim", "Karlsruhe", "Freiburg", "Heidelberg", "Heilbronn", "Ulm", "Pforzheim", "Reutlingen", "Esslingen", "Ludwigsburg", "Tübingen", "Villingen-Schwenningen", "Konstanz", "Sindelfingen", "Aalen", "Offenburg", "Göppingen", "Schwäbisch Gmünd", "Ravensburg"] },
        { name: "Bavaria", code: "BY", cities: ["Munich", "Nuremberg", "Augsburg", "Würzburg", "Regensburg", "Ingolstadt", "Fürth", "Erlangen", "Bayreuth", "Bamberg", "Aschaffenburg", "Landshut", "Kempten", "Rosenheim", "Neu-Ulm", "Schweinfurt", "Passau", "Freising", "Straubing", "Dachau"] },
        { name: "Berlin", code: "BE", cities: ["Berlin", "Charlottenburg", "Spandau", "Tempelhof", "Neukölln", "Friedrichshain", "Kreuzberg", "Prenzlauer Berg", "Wedding", "Reinickendorf", "Steglitz", "Zehlendorf", "Wilmersdorf", "Schöneberg", "Mitte", "Tiergarten", "Moabit", "Gesundbrunnen", "Lichtenberg", "Treptow"] },
        { name: "Brandenburg", code: "BB", cities: ["Potsdam", "Cottbus", "Brandenburg", "Frankfurt", "Oranienburg", "Falkensee", "Königs Wusterhausen", "Schwedt", "Eberswalde", "Rathenow", "Bernau", "Strausberg", "Luckenwalde", "Neuruppin", "Hennigsdorf", "Eisenhüttenstadt", "Fürstenwalde", "Wandlitz", "Hohen Neuendorf", "Teltow"] },
        { name: "Bremen", code: "HB", cities: ["Bremen", "Bremerhaven", "Vegesack", "Blumenthal", "Burglesum", "Gröpelingen", "Walle", "Findorff", "Schwachhausen", "Horn-Lehe", "Borgfeld", "Vahr", "Hemelingen", "Osterholz", "Oberneuland", "Seehausen", "Strom", "Woltmershausen", "Neustadt", "Obervieland"] },
        { name: "Hamburg", code: "HH", cities: ["Hamburg", "Altona", "Eimsbüttel", "Hamburg-Mitte", "Hamburg-Nord", "Harburg", "Bergedorf", "Wandsbek", "St. Pauli", "Ottensen", "Blankenese", "Uhlenhorst", "Winterhude", "Eppendorf", "Rotherbaum", "Barmbek", "Billstedt", "Wilhelmsburg", "Rahlstedt", "Bramfeld"] },
        { name: "Hesse", code: "HE", cities: ["Frankfurt", "Wiesbaden", "Kassel", "Darmstadt", "Offenbach", "Hanau", "Marburg", "Fulda", "Rüsselsheim", "Gießen", "Bad Homburg", "Bensheim", "Hofheim", "Oberursel", "Rodgau", "Dreieich", "Maintal", "Dietzenbach", "Lampertheim", "Viernheim"] },
        { name: "Lower Saxony", code: "NI", cities: ["Hannover", "Braunschweig", "Oldenburg", "Osnabrück", "Wolfsburg", "Göttingen", "Salzgitter", "Hildesheim", "Delmenhorst", "Wilhelmshaven", "Lüneburg", "Celle", "Garbsen", "Hameln", "Lingen", "Langenhagen", "Nordhorn", "Wolfenbüttel", "Goslar", "Peine"] },
        { name: "Mecklenburg-Vorpommern", code: "MV", cities: ["Rostock", "Schwerin", "Neubrandenburg", "Stralsund", "Greifswald", "Wismar", "Güstrow", "Waren", "Neustrelitz", "Parchim", "Ribnitz-Damgarten", "Bergen auf Rügen", "Anklam", "Wolgast", "Barth", "Grimmen", "Pasewalk", "Ludwigslust", "Bad Doberan", "Ueckermünde"] },
        { name: "North Rhine-Westphalia", code: "NW", cities: ["Cologne", "Düsseldorf", "Dortmund", "Essen", "Duisburg", "Bochum", "Wuppertal", "Bielefeld", "Bonn", "Münster", "Mönchengladbach", "Gelsenkirchen", "Aachen", "Krefeld", "Oberhausen", "Hagen", "Hamm", "Mülheim", "Leverkusen", "Solingen"] },
        { name: "Rhineland-Palatinate", code: "RP", cities: ["Mainz", "Ludwigshafen", "Koblenz", "Kaiserslautern", "Trier", "Neustadt", "Speyer", "Frankenthal", "Bad Kreuznach", "Pirmasens", "Zweibrücken", "Bad Neuenahr-Ahrweiler", "Landau", "Idar-Oberstein", "Neuwied", "Worms", "Andernach", "Germersheim", "Ingelheim", "Alzey"] },
        { name: "Saarland", code: "SL", cities: ["Saarbrücken", "Neunkirchen", "Homburg", "Völklingen", "St. Ingbert", "Merzig", "St. Wendel", "Dillingen", "Blieskastel", "Lebach", "Püttlingen", "Heusweiler", "Schiffweiler", "Wadgassen", "Sulzbach", "Friedrichsthal", "Ottweiler", "Riegelsberg", "Schwalbach", "Losheim"] },
        { name: "Saxony", code: "SN", cities: ["Leipzig", "Dresden", "Chemnitz", "Zwickau", "Plauen", "Görlitz", "Freiberg", "Bautzen", "Freital", "Pirna", "Radebeul", "Riesa", "Delitzsch", "Hoyerswerda", "Glauchau", "Markkleeberg", "Meißen", "Limbach-Oberfrohna", "Coswig", "Döbeln"] },
        { name: "Saxony-Anhalt", code: "ST", cities: ["Magdeburg", "Halle", "Dessau-Roßlau", "Wittenberg", "Stendal", "Weißenfels", "Merseburg", "Bernburg", "Naumburg", "Quedlinburg", "Köthen", "Zeitz", "Aschersleben", "Sangerhausen", "Wernigerode", "Halberstadt", "Schönebeck", "Salzwedel", "Gardelegen", "Burg"] },
        { name: "Schleswig-Holstein", code: "SH", cities: ["Kiel", "Lübeck", "Flensburg", "Neumünster", "Norderstedt", "Elmshorn", "Pinneberg", "Wedel", "Ahrensburg", "Geesthacht", "Henstedt-Ulzburg", "Reinbek", "Bad Oldesloe", "Schleswig", "Husum", "Heide", "Kaltenkirchen", "Bad Segeberg", "Itzehoe", "Rendsburg"] },
        { name: "Thuringia", code: "TH", cities: ["Erfurt", "Jena", "Gera", "Weimar", "Gotha", "Nordhausen", "Eisenach", "Suhl", "Mühlhausen", "Altenburg", "Greiz", "Arnstadt", "Ilmenau", "Meiningen", "Sonneberg", "Saalfeld", "Rudolstadt", "Apolda", "Bad Langensalza", "Leinefelde-Worbis"] }
      ]
    },
    {
      name: "Australia",
      code: "AU",
      region: "Oceania",
      states: [
        { name: "New South Wales", code: "NSW", cities: ["Sydney", "Newcastle", "Wollongong", "Central Coast", "Maitland", "Albury", "Wagga Wagga", "Port Macquarie", "Tamworth", "Orange", "Dubbo", "Queanbeyan", "Bathurst", "Nowra", "Lismore", "Armidale", "Coffs Harbour", "Taree", "Goulburn", "Cessnock"] },
        { name: "Victoria", code: "VIC", cities: ["Melbourne", "Geelong", "Ballarat", "Bendigo", "Shepparton", "Melton", "Latrobe City", "Warrnambool", "Wodonga", "Sunbury", "Mildura", "Frankston", "Pakenham", "Horsham", "Sale", "Bacchus Marsh", "Torquay", "Bairnsdale", "Colac", "Echuca"] },
        { name: "Queensland", code: "QLD", cities: ["Brisbane", "Gold Coast", "Sunshine Coast", "Townsville", "Cairns", "Toowoomba", "Rockhampton", "Mackay", "Bundaberg", "Hervey Bay", "Gladstone", "Redcliffe", "Mount Isa", "Maryborough", "Warwick", "Chinchilla", "Innisfail", "Charleville", "Roma", "Emerald"] },
        { name: "Western Australia", code: "WA", cities: ["Perth", "Fremantle", "Rockingham", "Mandurah", "Bunbury", "Kalgoorlie", "Geraldton", "Albany", "Broome", "Port Hedland", "Karratha", "Northam", "Esperance", "Carnarvon", "Newman", "Derby", "Kununurra", "Merredin", "Narrogin", "Collie"] },
        { name: "South Australia", code: "SA", cities: ["Adelaide", "Mount Gambier", "Whyalla", "Murray Bridge", "Port Lincoln", "Port Pirie", "Victor Harbor", "Gawler", "Port Augusta", "Kadina", "Loxton", "Mount Barker", "Berri", "Millicent", "Naracoorte", "Clare", "Renmark", "Wallaroo", "Tanunda", "Yorketown"] },
        { name: "Tasmania", code: "TAS", cities: ["Hobart", "Launceston", "Devonport", "Burnie", "Ulverstone", "Kingston", "Wynyard", "Somerset", "New Norfolk", "George Town", "Smithton", "Scottsdale", "St Helens", "Deloraine", "Sorell", "Huonville", "Penguin", "Queenstown", "Zeehan", "Rosebery"] },
        { name: "Northern Territory", code: "NT", cities: ["Darwin", "Alice Springs", "Palmerston", "Katherine", "Nhulunbuy", "Tennant Creek", "Casuarina", "Nightcliff", "Fannie Bay", "Stuart Park", "Larrakeyah", "Coconut Grove", "Rapid Creek", "Tiwi", "Leanyer", "Karama", "Malak", "Wanguri", "Jingili", "Anula"] },
        { name: "Australian Capital Territory", code: "ACT", cities: ["Canberra", "Gungahlin", "Tuggeranong", "Woden", "Belconnen", "Molonglo Valley", "Jerrabomberra", "Queanbeyan", "Hall", "Tharwa", "Uriarra", "Paddys River", "Naas", "Brindabella", "Cotter River", "Stromlo", "Kowen", "Oaks Estate", "Beard", "Bonython"] }
      ]
    },
    {
      name: "Japan",
      code: "JP",
      region: "Asia",
      states: [
        { name: "Tokyo", code: "13", cities: ["Tokyo", "Hachioji", "Tachikawa", "Musashino", "Mitaka", "Ome", "Fuchu", "Akishima", "Chofu", "Machida", "Koganei", "Kodaira", "Hino", "Higashimurayama", "Kokubunji", "Kunitachi", "Fussa", "Komae", "Higashiyamato", "Kiyose"] },
        { name: "Osaka", code: "27", cities: ["Osaka", "Sakai", "Higashiosaka", "Hirakata", "Toyonaka", "Suita", "Yao", "Takatsuki", "Ibaraki", "Neyagawa", "Kishiwada", "Izumi", "Mino", "Matsubara", "Daito", "Izumisano", "Tondabayashi", "Nara", "Kashiwara", "Ikeda"] },
        { name: "Kyoto", code: "26", cities: ["Kyoto", "Uji", "Kameoka", "Maizuru", "Fukuchiyama", "Ayabe", "Miyazu", "Muko", "Joyo", "Yawata", "Kyotanabe", "Kyotango", "Nantan", "Kizugawa", "Oyamazaki", "Kumiyama", "Ide", "Ujitawara", "Kasagi", "Wazuka"] },
        { name: "Kanagawa", code: "14", cities: ["Yokohama", "Kawasaki", "Sagamihara", "Fujisawa", "Chigasaki", "Odawara", "Hiratsuka", "Machida", "Yamato", "Fujisawa", "Atsugi", "Zama", "Miura", "Hadano", "Ebina", "Zushi", "Ayase", "Isehara", "座間", "綾瀬"] },
        { name: "Aichi", code: "23", cities: ["Nagoya", "Toyota", "Okazaki", "Ichinomiya", "Seto", "Kasugai", "Tsushima", "Handa", "Kariya", "Anjo", "Nishio", "Komaki", "Inazawa", "Konan", "Ogaki", "Inuyama", "Tokoname", "Kanie", "Taketoyo", "Mihama"] },
        { name: "Saitama", code: "11", cities: ["Saitama", "Kawaguchi", "Kawagoe", "Tokorozawa", "Koshigaya", "Ageo", "Kasukabe", "Kumagaya", "Soka", "Niiza", "Sayama", "Hanyu", "Konosu", "Fukaya", "Higashimatsuyama", "Hasuda", "Misato", "Asaka", "Iruma", "Toda"] },
        { name: "Chiba", code: "12", cities: ["Chiba", "Funabashi", "Matsudo", "Ichikawa", "Kashiwa", "Ichihara", "Yachiyo", "Abiko", "Kamagaya", "Kisarazu", "Narita", "Sakura", "Noda", "Nagareyama", "Urayasu", "Sodegaura", "Yotsukaido", "Shiroi", "Tomisato", "Inzai"] },
        { name: "Hyogo", code: "28", cities: ["Kobe", "Himeji", "Nishinomiya", "Amagasaki", "Akashi", "Kakogawa", "Takasago", "Kawanishi", "Itami", "Sanda", "Ako", "Takarazuka", "Miki", "Ono", "Kasai", "Kato", "Tatsuno", "Shiso", "Toyooka", "Tanba"] },
        { name: "Hokkaido", code: "01", cities: ["Sapporo", "Asahikawa", "Hakodate", "Kushiro", "Tomakomai", "Otaru", "Ebetsu", "Kitami", "Obihiro", "Iwamizawa", "Abashiri", "Rumoi", "Nemuro", "Chitose", "Takikawa", "Sunagawa", "Bibai", "Ashibetsu", "Utashinai", "Mikasa"] },
        { name: "Fukuoka", code: "40", cities: ["Fukuoka", "Kitakyushu", "Kurume", "Omuta", "Iizuka", "Tagawa", "Yanagawa", "Yame", "Chikugo", "Okawa", "Yukuhashi", "Buzen", "Nakama", "Ogori", "Chikushino", "Kasuga", "Onojo", "Munakata", "Dazaifu", "Koga"] }
      ]
    }
  ]
};

export function updateMajorCountriesLocationData() {
  console.log('🌍 Updating major countries with comprehensive authentic location data...');
  
  try {
    // Read the current comprehensive location file
    const locationFilePath = join(process.cwd(), '../client/src/lib/utils/comprehensive-world-locations.ts');
    let fileContent = readFileSync(locationFilePath, 'utf-8');
    
    let updatedCount = 0;
    
    // Update each major country
    majorCountriesData.countries.forEach(countryData => {
      const searchPattern = new RegExp(
        `\\{\\s*name:\\s*"${countryData.name}"[^}]*code:\\s*"${countryData.code}"[^}]*states:\\s*\\[[^\\]]*\\]\\s*\\}`,
        'gs'
      );
      
      const replacement = `{
    name: "${countryData.name}",
    code: "${countryData.code}",
    region: "${countryData.region}",
    states: [
${countryData.states.map(state => 
  `      { name: "${state.name}", code: "${state.code}", cities: [${state.cities.map(city => `"${city}"`).join(', ')}] }`
).join(',\n')}
    ]
  }`;

      if (searchPattern.test(fileContent)) {
        fileContent = fileContent.replace(searchPattern, replacement);
        updatedCount++;
        console.log(`✅ Updated ${countryData.name} with ${countryData.states.length} states`);
      } else {
        console.log(`⚠️  Could not find ${countryData.name} in location data`);
      }
    });
    
    // Write the updated content back to the file
    writeFileSync(locationFilePath, fileContent);
    
    console.log(`✅ Major countries location data update completed!`);
    console.log(`📊 Updated ${updatedCount} countries with authentic state data`);
    
    return true;
  } catch (error) {
    console.error('❌ Error updating major countries location data:', error);
    return false;
  }
}

// Execute the update
updateMajorCountriesLocationData();