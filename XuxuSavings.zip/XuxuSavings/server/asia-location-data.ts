// Comprehensive authentic Asia location data
// This contains real countries, states/provinces, and major cities across Asia

export const asiaLocationData = {
  countries: [
    {
      name: "India",
      code: "IN",
      states: [
        {
          name: "Andhra Pradesh",
          code: "AP",
          cities: ["Visakhapatnam", "Vijayawada", "Guntur", "Nellore", "Kurnool", "Kakinada", "Rajahmundry", "Tirupati", "Kadapa", "Anantapur"]
        },
        {
          name: "Arunachal Pradesh",
          code: "AR",
          cities: ["Itanagar", "Naharlagun", "Pasighat", "Tawang", "Ziro", "Bomdila", "Tezu", "Namsai", "Roing", "Aalo"]
        },
        {
          name: "Assam",
          code: "AS",
          cities: ["Guwahati", "Silchar", "Dibrugarh", "Jorhat", "Nagaon", "Tinsukia", "Tezpur", "Karimganj", "Dhubri", "Bongaigaon"]
        },
        {
          name: "Bihar",
          code: "BR",
          cities: ["Patna", "Gaya", "Bhagalpur", "Muzaffarpur", "Darbhanga", "Purnia", "Arrah", "Begusarai", "Katihar", "Munger"]
        },
        {
          name: "Chhattisgarh",
          code: "CG",
          cities: ["Raipur", "Bhilai", "Bilaspur", "Korba", "Durg", "Rajnandgaon", "Jagdalpur", "Ambikapur", "Dhamtari", "Raigarh"]
        },
        {
          name: "Goa",
          code: "GA",
          cities: ["Panaji", "Margao", "Vasco da Gama", "Mapusa", "Ponda", "Cuncolim", "Bicholim", "Canacona", "Curchorem", "Sanquelim"]
        },
        {
          name: "Gujarat",
          code: "GJ",
          cities: ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar", "Jamnagar", "Junagadh", "Gandhinagar", "Anand", "Nadiad"]
        },
        {
          name: "Haryana",
          code: "HR",
          cities: ["Faridabad", "Gurgaon", "Panipat", "Ambala", "Karnal", "Hisar", "Rohtak", "Sonipat", "Yamunanagar", "Panchkula"]
        },
        {
          name: "Himachal Pradesh",
          code: "HP",
          cities: ["Shimla", "Mandi", "Dharamshala", "Solan", "Kullu", "Palampur", "Hamirpur", "Una", "Chamba", "Bilaspur"]
        },
        {
          name: "Jharkhand",
          code: "JH",
          cities: ["Ranchi", "Jamshedpur", "Dhanbad", "Bokaro", "Hazaribagh", "Deoghar", "Giridih", "Ramgarh", "Dumka", "Phusro"]
        },
        {
          name: "Karnataka",
          code: "KA",
          cities: ["Bangalore", "Mysore", "Hubli", "Mangalore", "Belgaum", "Gulbarga", "Davanagere", "Bellary", "Bijapur", "Shimoga"]
        },
        {
          name: "Kerala",
          code: "KL",
          cities: ["Thiruvananthapuram", "Kochi", "Kozhikode", "Thrissur", "Kollam", "Alappuzha", "Kannur", "Kottayam", "Palakkad", "Malappuram"]
        },
        {
          name: "Madhya Pradesh",
          code: "MP",
          cities: ["Indore", "Bhopal", "Jabalpur", "Gwalior", "Ujjain", "Sagar", "Dewas", "Satna", "Ratlam", "Rewa"]
        },
        {
          name: "Maharashtra",
          code: "MH",
          cities: ["Mumbai", "Pune", "Nagpur", "Thane", "Nashik", "Aurangabad", "Solapur", "Kolhapur", "Amravati", "Nanded"]
        },
        {
          name: "Manipur",
          code: "MN",
          cities: ["Imphal", "Thoubal", "Bishnupur", "Ukhrul", "Churachandpur", "Chandel", "Senapati", "Tamenglong", "Jiribam", "Kangpokpi"]
        },
        {
          name: "Meghalaya",
          code: "ML",
          cities: ["Shillong", "Tura", "Jowai", "Nongpoh", "Williamnagar", "Baghmara", "Nongstoin", "Resubelpara", "Ampati", "Mairang"]
        },
        {
          name: "Mizoram",
          code: "MZ",
          cities: ["Aizawl", "Lunglei", "Champhai", "Serchhip", "Kolasib", "Saitual", "Khawzawl", "Hnahthial", "Lawngtlai", "Mamit"]
        },
        {
          name: "Nagaland",
          code: "NL",
          cities: ["Kohima", "Dimapur", "Mokokchung", "Tuensang", "Wokha", "Zunheboto", "Phek", "Mon", "Kiphire", "Longleng"]
        },
        {
          name: "Odisha",
          code: "OD",
          cities: ["Bhubaneswar", "Cuttack", "Rourkela", "Berhampur", "Sambalpur", "Puri", "Balasore", "Bhadrak", "Baripada", "Jeypore"]
        },
        {
          name: "Punjab",
          code: "PB",
          cities: ["Ludhiana", "Amritsar", "Jalandhar", "Patiala", "Bathinda", "Hoshiarpur", "Mohali", "Batala", "Pathankot", "Moga"]
        },
        {
          name: "Rajasthan",
          code: "RJ",
          cities: ["Jaipur", "Jodhpur", "Kota", "Bikaner", "Ajmer", "Udaipur", "Bhilwara", "Alwar", "Sikar", "Sri Ganganagar"]
        },
        {
          name: "Sikkim",
          code: "SK",
          cities: ["Gangtok", "Namchi", "Gyalshing", "Mangan", "Jorethang", "Singtam", "Rangpo", "Soreng", "Ravangla", "Chungthang"]
        },
        {
          name: "Tamil Nadu",
          code: "TN",
          cities: ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem", "Tirunelveli", "Erode", "Vellore", "Thoothukudi", "Dindigul"]
        },
        {
          name: "Telangana",
          code: "TG",
          cities: ["Hyderabad", "Warangal", "Nizamabad", "Karimnagar", "Ramagundam", "Khammam", "Mahbubnagar", "Nalgonda", "Adilabad", "Suryapet"]
        },
        {
          name: "Tripura",
          code: "TR",
          cities: ["Agartala", "Dharmanagar", "Kailashahar", "Udaipur", "Belonia", "Khowai", "Ambassa", "Teliamura", "Sabroom", "Gomati"]
        },
        {
          name: "Uttar Pradesh",
          code: "UP",
          cities: ["Lucknow", "Kanpur", "Varanasi", "Agra", "Meerut", "Allahabad", "Bareilly", "Aligarh", "Moradabad", "Gorakhpur"]
        },
        {
          name: "Uttarakhand",
          code: "UK",
          cities: ["Dehradun", "Haridwar", "Roorkee", "Haldwani", "Rudrapur", "Kashipur", "Rishikesh", "Nainital", "Mussoorie", "Pithoragarh"]
        },
        {
          name: "West Bengal",
          code: "WB",
          cities: ["Kolkata", "Howrah", "Durgapur", "Asansol", "Siliguri", "Bardhaman", "Malda", "Jalpaiguri", "Kharagpur", "Haldia"]
        },
        {
          name: "Andaman and Nicobar Islands",
          code: "AN",
          cities: ["Port Blair", "Car Nicobar", "Mayabunder", "Diglipur", "Little Andaman", "Rangat", "Havelock Island", "Neil Island", "Great Nicobar", "Kamorta"]
        },
        {
          name: "Chandigarh",
          code: "CH",
          cities: ["Chandigarh", "Manimajra", "Burail", "Attawa", "Badheri", "Behlana", "Daria", "Dhanas", "Hallomajra", "Khuda Lahora"]
        },
        {
          name: "Dadra and Nagar Haveli",
          code: "DH",
          cities: ["Silvassa", "Amli", "Khanvel", "Naroli", "Dadra", "Samarvarni", "Dudhani", "Dapada", "Kilvani", "Luhari"]
        },
        {
          name: "Daman and Diu",
          code: "DD",
          cities: ["Daman", "Diu", "Moti Daman", "Nani Daman", "Ghoghla", "Vanakbara", "Fudam", "Kachigam", "Marwad", "Varkund"]
        },
        {
          name: "Delhi",
          code: "DL",
          cities: ["New Delhi", "North Delhi", "South Delhi", "East Delhi", "West Delhi", "Central Delhi", "North East Delhi", "North West Delhi", "South East Delhi", "South West Delhi"]
        },
        {
          name: "Jammu and Kashmir",
          code: "JK",
          cities: ["Srinagar", "Jammu", "Anantnag", "Baramulla", "Kathua", "Udhampur", "Sopore", "Kupwara", "Pulwama", "Rajouri"]
        },
        {
          name: "Ladakh",
          code: "LA",
          cities: ["Leh", "Kargil", "Drass", "Khalsi", "Diskit", "Nyoma", "Zanskar", "Nubra", "Suru Valley", "Chiktan"]
        },
        {
          name: "Lakshadweep",
          code: "LD",
          cities: ["Kavaratti", "Agatti", "Andrott", "Amini", "Kadmat", "Kiltan", "Kalpeni", "Minicoy", "Bitra", "Bangaram"]
        },
        {
          name: "Puducherry",
          code: "PY",
          cities: ["Puducherry", "Karaikal", "Mahe", "Yanam", "Ozhukarai", "Villianur", "Thirubhuvanai", "Bahour", "Mannadipet", "Nettapakkam"]
        }
      ]
    },
    {
      name: "China",
      code: "CN",
      states: [
        {
          name: "Beijing",
          code: "BJ",
          cities: ["Beijing", "Haidian", "Chaoyang", "Fengtai", "Shijingshan", "Mentougou", "Changping", "Shunyi", "Tongzhou", "Daxing"]
        },
        {
          name: "Shanghai",
          code: "SH",
          cities: ["Shanghai", "Pudong", "Huangpu", "Jing'an", "Xuhui", "Changning", "Putuo", "Hongkou", "Yangpu", "Minhang"]
        },
        {
          name: "Guangdong",
          code: "GD",
          cities: ["Guangzhou", "Shenzhen", "Dongguan", "Foshan", "Zhongshan", "Zhuhai", "Shantou", "Jiangmen", "Zhaoqing", "Huizhou"]
        },
        {
          name: "Jiangsu",
          code: "JS",
          cities: ["Nanjing", "Suzhou", "Wuxi", "Changzhou", "Nantong", "Yangzhou", "Xuzhou", "Taizhou", "Yancheng", "Zhenjiang"]
        },
        {
          name: "Zhejiang",
          code: "ZJ",
          cities: ["Hangzhou", "Ningbo", "Wenzhou", "Jiaxing", "Shaoxing", "Jinhua", "Taizhou", "Huzhou", "Quzhou", "Lishui"]
        },
        {
          name: "Fujian",
          code: "FJ",
          cities: ["Fuzhou", "Xiamen", "Quanzhou", "Putian", "Zhangzhou", "Nanping", "Longyan", "Sanming", "Ningde", "Pingtan"]
        },
        {
          name: "Henan",
          code: "HA",
          cities: ["Zhengzhou", "Luoyang", "Kaifeng", "Xinxiang", "Jiaozuo", "Anyang", "Nanyang", "Shangqiu", "Xinyang", "Zhoukou"]
        },
        {
          name: "Shandong",
          code: "SD",
          cities: ["Jinan", "Qingdao", "Yantai", "Weifang", "Zibo", "Weihai", "Linyi", "Jining", "Dezhou", "Rizhao"]
        },
        {
          name: "Sichuan",
          code: "SC",
          cities: ["Chengdu", "Mianyang", "Nanchong", "Leshan", "Deyang", "Yibin", "Zigong", "Luzhou", "Dazhou", "Neijiang"]
        },
        {
          name: "Hubei",
          code: "HB",
          cities: ["Wuhan", "Huangshi", "Yichang", "Xiangyang", "Ezhou", "Jingmen", "Xiaogan", "Jingzhou", "Huanggang", "Shiyan"]
        },
        {
          name: "Anhui",
          code: "AH",
          cities: ["Hefei", "Wuhu", "Bengbu", "Ma'anshan", "Huainan", "Anqing", "Suzhou", "Fuyang", "Huaibei", "Chuzhou"]
        },
        {
          name: "Liaoning",
          code: "LN",
          cities: ["Shenyang", "Dalian", "Anshan", "Fushun", "Benxi", "Dandong", "Jinzhou", "Yingkou", "Panjin", "Tieling"]
        },
        {
          name: "Shaanxi",
          code: "SN",
          cities: ["Xi'an", "Baoji", "Xianyang", "Weinan", "Hanzhong", "Ankang", "Shangluo", "Yan'an", "Yulin", "Tongchuan"]
        },
        {
          name: "Hebei",
          code: "HE",
          cities: ["Shijiazhuang", "Tangshan", "Baoding", "Langfang", "Qinhuangdao", "Zhangjiakou", "Chengde", "Handan", "Xingtai", "Cangzhou"]
        },
        {
          name: "Hunan",
          code: "HN",
          cities: ["Changsha", "Zhuzhou", "Xiangtan", "Hengyang", "Yueyang", "Changde", "Shaoyang", "Yongzhou", "Yiyang", "Chenzhou"]
        },
        {
          name: "Yunnan",
          code: "YN",
          cities: ["Kunming", "Dali", "Lijiang", "Baoshan", "Qujing", "Yuxi", "Zhaotong", "Chuxiong", "Honghe", "Wenshan"]
        },
        {
          name: "Jiangxi",
          code: "JX",
          cities: ["Nanchang", "Jiujiang", "Ganzhou", "Yichun", "Pingxiang", "Xinyu", "Shangrao", "Jingdezhen", "Yingtan", "Ji'an"]
        },
        {
          name: "Guizhou",
          code: "GZ",
          cities: ["Guiyang", "Zunyi", "Anshun", "Bijie", "Liupanshui", "Qiannan", "Qiandongnan", "Qianxinan", "Tongren", "Duyun"]
        },
        {
          name: "Shanxi",
          code: "SX",
          cities: ["Taiyuan", "Datong", "Changzhi", "Jincheng", "Yangquan", "Shuozhou", "Jinzhong", "Yuncheng", "Xinzhou", "Linfen"]
        },
        {
          name: "Jilin",
          code: "JL",
          cities: ["Changchun", "Jilin", "Siping", "Tonghua", "Baishan", "Liaoyuan", "Songyuan", "Baicheng", "Yanbian", "Gongzhuling"]
        },
        {
          name: "Inner Mongolia",
          code: "NM",
          cities: ["Hohhot", "Baotou", "Ordos", "Chifeng", "Tongliao", "Hulunbuir", "Wuhai", "Bayannur", "Ulanqab", "Hinggan"]
        },
        {
          name: "Gansu",
          code: "GS",
          cities: ["Lanzhou", "Tianshui", "Jiuquan", "Baiyin", "Pingliang", "Qingyang", "Jinchang", "Wuwei", "Zhangye", "Dingxi"]
        },
        {
          name: "Guangxi",
          code: "GX",
          cities: ["Nanning", "Liuzhou", "Guilin", "Beihai", "Wuzhou", "Yulin", "Qinzhou", "Guigang", "Baise", "Hechi"]
        },
        {
          name: "Heilongjiang",
          code: "HL",
          cities: ["Harbin", "Qiqihar", "Jixi", "Mudanjiang", "Daqing", "Hegang", "Yichun", "Jiamusi", "Qitaihe", "Shuangyashan"]
        },
        {
          name: "Hainan",
          code: "HI",
          cities: ["Haikou", "Sanya", "Wenchang", "Qionghai", "Danzhou", "Wanning", "Dongfang", "Chengmai", "Lingao", "Tunchang"]
        },
        {
          name: "Chongqing",
          code: "CQ",
          cities: ["Chongqing", "Wanzhou", "Fuling", "Qianjiang", "Yongchuan", "Hechuan", "Jiangjin", "Nanchuan", "Bishan", "Tongliang"]
        },
        {
          name: "Qinghai",
          code: "QH",
          cities: ["Xining", "Haidong", "Delingha", "Golmud", "Yushu", "Gonghe", "Menyuan", "Guide", "Dulan", "Huangyuan"]
        },
        {
          name: "Tianjin",
          code: "TJ",
          cities: ["Tianjin", "Binhai", "Ninghe", "Jinghai", "Wuqing", "Baodi", "Jizhou", "Xiqing", "Dongli", "Jinnan"]
        },
        {
          name: "Xinjiang",
          code: "XJ",
          cities: ["Urumqi", "Karamay", "Turpan", "Hami", "Korla", "Kashgar", "Yining", "Aksu", "Altay", "Hotan"]
        },
        {
          name: "Tibet",
          code: "XZ",
          cities: ["Lhasa", "Shigatse", "Chamdo", "Nyingchi", "Nagqu", "Ngari", "Shannan", "Gyantse", "Tingri", "Zetang"]
        },
        {
          name: "Hong Kong",
          code: "HK",
          cities: ["Hong Kong", "Kowloon", "New Territories", "Tsuen Wan", "Tuen Mun", "Yuen Long", "Sha Tin", "Tai Po", "Sai Kung", "Islands"]
        },
        {
          name: "Macau",
          code: "MO",
          cities: ["Macau", "Taipa", "Coloane", "Cotai", "Macau Peninsula", "Santo António", "São Lázaro", "São Lourenço", "Sé", "Nossa Senhora de Fátima"]
        },
        {
          name: "Taiwan",
          code: "TW",
          cities: ["Taipei", "Kaohsiung", "Taichung", "Tainan", "New Taipei", "Taoyuan", "Hsinchu", "Keelung", "Chiayi", "Changhua"]
        }
      ]
    },
    {
      name: "Japan",
      code: "JP",
      states: [
        {
          name: "Tokyo",
          code: "13",
          cities: ["Tokyo", "Shinjuku", "Shibuya", "Minato", "Chiyoda", "Chuo", "Toshima", "Koto", "Bunkyo", "Sumida"]
        },
        {
          name: "Osaka",
          code: "27",
          cities: ["Osaka", "Sakai", "Higashiosaka", "Hirakata", "Takatsuki", "Toyonaka", "Ibaraki", "Suita", "Izumisano", "Kadoma"]
        },
        {
          name: "Aichi",
          code: "23",
          cities: ["Nagoya", "Toyota", "Okazaki", "Toyohashi", "Ichinomiya", "Kasugai", "Kariya", "Anjo", "Seto", "Nishio"]
        },
        {
          name: "Kanagawa",
          code: "14",
          cities: ["Yokohama", "Kawasaki", "Sagamihara", "Fujisawa", "Kamakura", "Hiratsuka", "Yamato", "Atsugi", "Zushi", "Miura"]
        },
        {
          name: "Saitama",
          code: "11",
          cities: ["Saitama", "Kawaguchi", "Koshigaya", "Tokorozawa", "Kawagoe", "Kasukabe", "Sayama", "Kumagaya", "Niiza", "Iruma"]
        },
        {
          name: "Chiba",
          code: "12",
          cities: ["Chiba", "Funabashi", "Matsudo", "Ichikawa", "Kashiwa", "Narita", "Narashino", "Yachiyo", "Abiko", "Kamagaya"]
        },
        {
          name: "Hyogo",
          code: "28",
          cities: ["Kobe", "Himeji", "Nishinomiya", "Amagasaki", "Akashi", "Takarazuka", "Ashiya", "Itami", "Kakogawa", "Sasayama"]
        },
        {
          name: "Fukuoka",
          code: "40",
          cities: ["Fukuoka", "Kitakyushu", "Kurume", "Iizuka", "Omuta", "Kasuga", "Onojo", "Munakata", "Chikushino", "Dazaifu"]
        },
        {
          name: "Hokkaido",
          code: "01",
          cities: ["Sapporo", "Asahikawa", "Hakodate", "Otaru", "Kushiro", "Obihiro", "Tomakomai", "Kitami", "Iwamizawa", "Muroran"]
        },
        {
          name: "Kyoto",
          code: "26",
          cities: ["Kyoto", "Uji", "Kameoka", "Joyo", "Nagaokakyo", "Muko", "Ayabe", "Maizuru", "Kyotanabe", "Fukuchiyama"]
        },
        {
          name: "Shizuoka",
          code: "22",
          cities: ["Shizuoka", "Hamamatsu", "Numazu", "Fuji", "Iwata", "Mishima", "Yaizu", "Kakegawa", "Atami", "Ito"]
        },
        {
          name: "Hiroshima",
          code: "34",
          cities: ["Hiroshima", "Fukuyama", "Kure", "Onomichi", "Mihara", "Otake", "Hatsukaichi", "Higashihiroshima", "Etajima", "Miyoshi"]
        },
        {
          name: "Miyagi",
          code: "04",
          cities: ["Sendai", "Ishinomaki", "Shiogama", "Natori", "Tagajo", "Iwanuma", "Tome", "Kesennuma", "Kurihara", "Higashimatsushima"]
        },
        {
          name: "Niigata",
          code: "15",
          cities: ["Niigata", "Nagaoka", "Joetsu", "Sanjo", "Kashiwazaki", "Shibata", "Tokamachi", "Murakami", "Tsubame", "Ojiya"]
        },
        {
          name: "Nagasaki",
          code: "42",
          cities: ["Nagasaki", "Sasebo", "Isahaya", "Omura", "Shimabara", "Hirado", "Tsushima", "Goto", "Saikai", "Matsuura"]
        },
        {
          name: "Tochigi",
          code: "09",
          cities: ["Utsunomiya", "Oyama", "Ashikaga", "Tochigi", "Sano", "Kanuma", "Moka", "Otawara", "Nasushiobara", "Nikko"]
        },
        {
          name: "Okinawa",
          code: "47",
          cities: ["Naha", "Okinawa", "Uruma", "Ginowan", "Urasoe", "Itoman", "Tomigusuku", "Miyakojima", "Ishigaki", "Nago"]
        },
        {
          name: "Kagoshima",
          code: "46",
          cities: ["Kagoshima", "Kanoya", "Kirishima", "Satsumasendai", "Amami", "Ibusuki", "Nishinoomote", "Tarumizu", "Minamisatsuma", "Soo"]
        },
        {
          name: "Kumamoto",
          code: "43",
          cities: ["Kumamoto", "Yatsushiro", "Tamana", "Arao", "Amakusa", "Hitoyoshi", "Uto", "Kikuchi", "Aso", "Yamaga"]
        },
        {
          name: "Ibaraki",
          code: "08",
          cities: ["Mito", "Tsukuba", "Hitachi", "Tsuchiura", "Koga", "Kashima", "Toride", "Ushiku", "Ryugasaki", "Hitachinaka"]
        },
        {
          name: "Ehime",
          code: "38",
          cities: ["Matsuyama", "Imabari", "Niihama", "Saijo", "Uwajima", "Shikokuchuo", "Yawatahama", "Ozu", "Iyo", "Toon"]
        },
        {
          name: "Okayama",
          code: "33",
          cities: ["Okayama", "Kurashiki", "Tsuyama", "Tamano", "Kasaoka", "Soja", "Takahashi", "Niimi", "Bizen", "Setouchi"]
        },
        {
          name: "Kagawa",
          code: "37",
          cities: ["Takamatsu", "Marugame", "Sakaide", "Zentsuji", "Kanonji", "Sanuki", "Higashikagawa", "Mitoyo", "Kan'onji", "Ayagawa"]
        },
        {
          name: "Gunma",
          code: "10",
          cities: ["Maebashi", "Takasaki", "Ota", "Isesaki", "Kiryu", "Numata", "Tatebayashi", "Shibukawa", "Fujioka", "Tomioka"]
        },
        {
          name: "Akita",
          code: "05",
          cities: ["Akita", "Yuzawa", "Odate", "Noshiro", "Yokote", "Oga", "Kazuno", "Yurihonjo", "Daisen", "Katagami"]
        },
        {
          name: "Gifu",
          code: "21",
          cities: ["Gifu", "Ogaki", "Tajimi", "Kakamigahara", "Minokamo", "Ena", "Mizunami", "Mino", "Seki", "Gero"]
        },
        {
          name: "Mie",
          code: "24",
          cities: ["Tsu", "Yokkaichi", "Ise", "Suzuka", "Matsusaka", "Kuwana", "Nabari", "Owase", "Kameyama", "Toba"]
        },
        {
          name: "Miyazaki",
          code: "45",
          cities: ["Miyazaki", "Miyakonojo", "Nobeoka", "Nichinan", "Hyuga", "Kushima", "Kobayashi", "Saito", "Ebino", "Nishimera"]
        },
        {
          name: "Tokushima",
          code: "36",
          cities: ["Tokushima", "Anan", "Komatsushima", "Yoshinogawa", "Naruto", "Awa", "Mima", "Aizumi", "Ishii", "Miyoshi"]
        },
        {
          name: "Nara",
          code: "29",
          cities: ["Nara", "Ikoma", "Kashihara", "Yamatokoriyama", "Tenri", "Gose", "Sakurai", "Katsuragi", "Uda", "Gojo"]
        },
        {
          name: "Iwate",
          code: "03",
          cities: ["Morioka", "Ichinoseki", "Oshu", "Hanamaki", "Kitakami", "Miyako", "Ninohe", "Kamaishi", "Tono", "Kuji"]
        },
        {
          name: "Yamagata",
          code: "06",
          cities: ["Yamagata", "Yonezawa", "Tsuruoka", "Tendo", "Sakata", "Shinjo", "Nagai", "Kaminoyama", "Murayama", "Sagae"]
        },
        {
          name: "Ishikawa",
          code: "17",
          cities: ["Kanazawa", "Hakusan", "Komatsu", "Kaga", "Nonoichi", "Nanao", "Wajima", "Suzu", "Nomi", "Kahoku"]
        },
        {
          name: "Kochi",
          code: "39",
          cities: ["Kochi", "Nankoku", "Sukumo", "Tosashimizu", "Muroto", "Susaki", "Aki", "Konan", "Kami", "Tosa"]
        },
        {
          name: "Saga",
          code: "41",
          cities: ["Saga", "Karatsu", "Tosu", "Imari", "Takeo", "Taku", "Ureshino", "Ogi", "Kanzaki", "Kashima"]
        },
        {
          name: "Yamaguchi",
          code: "35",
          cities: ["Yamaguchi", "Shimonoseki", "Ube", "Shunan", "Iwakuni", "Hofu", "Kudamatsu", "Hikari", "Nagato", "Mine"]
        },
        {
          name: "Oita",
          code: "44",
          cities: ["Oita", "Beppu", "Nakatsu", "Hita", "Saiki", "Usuki", "Tsukumi", "Taketa", "Bungo-Ono", "Kunisaki"]
        },
        {
          name: "Fukushima",
          code: "07",
          cities: ["Fukushima", "Iwaki", "Koriyama", "Aizuwakamatsu", "Sukagawa", "Shirakawa", "Kitakata", "Soma", "Nihonmatsu", "Date"]
        },
        {
          name: "Yamanashi",
          code: "19",
          cities: ["Kofu", "Fuefuki", "Kai", "Tsuru", "Nirasaki", "Yamanashi", "Otsuki", "Minami-Alps", "Hokuto", "Koshu"]
        },
        {
          name: "Fukui",
          code: "18",
          cities: ["Fukui", "Sakai", "Echizen", "Sabae", "Obama", "Ono", "Katsuyama", "Awara", "Tsuruga", "Eiheiji"]
        },
        {
          name: "Toyama",
          code: "16",
          cities: ["Toyama", "Takaoka", "Namerikawa", "Uozu", "Kurobe", "Tonami", "Nanto", "Oyabe", "Himi", "Nyuzen"]
        },
        {
          name: "Shimane",
          code: "32",
          cities: ["Matsue", "Izumo", "Masuda", "Yasugi", "Hamada", "Gotsu", "Oda", "Unnan", "Okuizumo", "Kawamoto"]
        },
        {
          name: "Wakayama",
          code: "30",
          cities: ["Wakayama", "Tanabe", "Hashimoto", "Kainan", "Arida", "Gobō", "Kinokawa", "Iwade", "Shingu", "Kushimoto"]
        },
        {
          name: "Aomori",
          code: "02",
          cities: ["Aomori", "Hachinohe", "Hirosaki", "Towada", "Misawa", "Mutsu", "Goshogawara", "Tsugaru", "Hirakawa", "Kuroishi"]
        },
        {
          name: "Nagano",
          code: "20",
          cities: ["Nagano", "Matsumoto", "Ueda", "Iida", "Suzaka", "Komoro", "Okaya", "Saku", "Chino", "Ina"]
        },
        {
          name: "Tottori",
          code: "31",
          cities: ["Tottori", "Yonago", "Kurayoshi", "Sakaiminato", "Hokuei", "Daisen", "Nanbu", "Kofu", "Chizu", "Misasa"]
        },
        {
          name: "Shiga",
          code: "25",
          cities: ["Otsu", "Hikone", "Nagahama", "Moriyama", "Kusatsu", "Ritto", "Omihachiman", "Higashiomi", "Konan", "Takashima"]
        }
      ]
    },
    {
      name: "Indonesia",
      code: "ID",
      states: [
        {
          name: "Jakarta",
          code: "JK",
          cities: ["Jakarta", "East Jakarta", "West Jakarta", "North Jakarta", "South Jakarta", "Central Jakarta", "Thousand Islands"]
        },
        {
          name: "East Java",
          code: "JI",
          cities: ["Surabaya", "Malang", "Kediri", "Madiun", "Banyuwangi", "Jember", "Probolinggo", "Pasuruan", "Mojokerto", "Blitar"]
        },
        {
          name: "West Java",
          code: "JB",
          cities: ["Bandung", "Bogor", "Bekasi", "Depok", "Cirebon", "Tasikmalaya", "Sukabumi", "Cimahi", "Banjar", "Indramayu"]
        },
        {
          name: "Central Java",
          code: "JT",
          cities: ["Semarang", "Surakarta", "Pekalongan", "Salatiga", "Tegal", "Magelang", "Kudus", "Jepara", "Klaten", "Purwokerto"]
        },
        {
          name: "North Sumatra",
          code: "SU",
          cities: ["Medan", "Binjai", "Tebing Tinggi", "Pematang Siantar", "Tanjung Balai", "Sibolga", "Padang Sidempuan", "Gunungsitoli", "Rantau Prapat", "Kisaran"]
        },
        {
          name: "Bali",
          code: "BA",
          cities: ["Denpasar", "Kuta", "Ubud", "Singaraja", "Gianyar", "Tabanan", "Bangli", "Karangasem", "Klungkung", "Jimbaran"]
        },
        {
          name: "Yogyakarta",
          code: "YO",
          cities: ["Yogyakarta", "Bantul", "Sleman", "Wates", "Wonosari", "Godean", "Gamping", "Condongcatur", "Sewon", "Kasihan"]
        },
        {
          name: "South Sulawesi",
          code: "SN",
          cities: ["Makassar", "Parepare", "Palopo", "Watampone", "Bulukumba", "Sinjai", "Maros", "Bantaeng", "Jeneponto", "Takalar"]
        },
        {
          name: "East Kalimantan",
          code: "KI",
          cities: ["Samarinda", "Balikpapan", "Bontang", "Tenggarong", "Sangatta", "Penajam", "Tanah Grogot", "Kutai Kartanegara", "Berau", "Tanjung Redeb"]
        },
        {
          name: "Riau",
          code: "RI",
          cities: ["Pekanbaru", "Dumai", "Duri", "Rengat", "Bangkinang", "Tembilahan", "Bengkalis", "Selat Panjang", "Siak Sri Indrapura", "Pangkalan Kerinci"]
        },
        {
          name: "South Sumatra",
          code: "SS",
          cities: ["Palembang", "Prabumulih", "Pagaralam", "Lubuklinggau", "Muara Enim", "Lahat", "Pagar Alam", "Baturaja", "Indralaya", "Kayu Agung"]
        },
        {
          name: "West Sumatra",
          code: "SB",
          cities: ["Padang", "Bukittinggi", "Pariaman", "Payakumbuh", "Sawahlunto", "Solok", "Padang Panjang", "Batusangkar", "Painan", "Lubuk Basung"]
        },
        {
          name: "Lampung",
          code: "LA",
          cities: ["Bandar Lampung", "Metro", "Kotabumi", "Pringsewu", "Liwa", "Kalianda", "Sukadana", "Mesuji", "Menggala", "Krui"]
        },
        {
          name: "South Kalimantan",
          code: "KS",
          cities: ["Banjarmasin", "Banjarbaru", "Martapura", "Marabahan", "Pelaihari", "Kotabaru", "Amuntai", "Kandangan", "Rantau", "Tanjung"]
        },
        {
          name: "Banten",
          code: "BT",
          cities: ["Serang", "Tangerang", "Cilegon", "South Tangerang", "Rangkasbitung", "Pandeglang", "Labuan", "Anyer", "Merak", "Balaraja"]
        },
        {
          name: "Papua",
          code: "PA",
          cities: ["Jayapura", "Merauke", "Biak", "Timika", "Sentani", "Wamena", "Abepura", "Nabire", "Manokwari", "Sorong"]
        },
        {
          name: "North Sulawesi",
          code: "SA",
          cities: ["Manado", "Bitung", "Tomohon", "Kotamobagu", "Amurang", "Tondano", "Ratahan", "Tahuna", "Lolak", "Melonguane"]
        },
        {
          name: "West Kalimantan",
          code: "KB",
          cities: ["Pontianak", "Singkawang", "Sintang", "Ketapang", "Sanggau", "Ngabang", "Sukadana", "Mempawah", "Sambas", "Putussibau"]
        },
        {
          name: "Aceh",
          code: "AC",
          cities: ["Banda Aceh", "Lhokseumawe", "Langsa", "Sabang", "Meulaboh", "Sigli", "Bireuen", "Takengon", "Kutacane", "Calang"]
        },
        {
          name: "Maluku",
          code: "MA",
          cities: ["Ambon", "Tual", "Masohi", "Namlea", "Piru", "Saumlaki", "Dobo", "Bula", "Namrole", "Ilwaki"]
        },
        {
          name: "Jambi",
          code: "JA",
          cities: ["Jambi", "Sungai Penuh", "Muara Bungo", "Kuala Tungkal", "Bangko", "Sarolangun", "Muara Bulian", "Muaro Jambi", "Kerinci", "Tebo"]
        },
        {
          name: "Central Kalimantan",
          code: "KT",
          cities: ["Palangkaraya", "Sampit", "Pangkalan Bun", "Kuala Kapuas", "Muara Teweh", "Buntok", "Tamiang Layang", "Kasongan", "Kuala Pembuang", "Sukamara"]
        },
        {
          name: "Bengkulu",
          code: "BE",
          cities: ["Bengkulu", "Curup", "Manna", "Mukomuko", "Arga Makmur", "Kepahiang", "Tais", "Lebong", "Kaur", "Bintunan"]
        },
        {
          name: "Central Sulawesi",
          code: "ST",
          cities: ["Palu", "Luwuk", "Poso", "Toli-Toli", "Donggala", "Buol", "Ampana", "Parigi", "Morowali", "Sigi"]
        },
        {
          name: "Gorontalo",
          code: "GO",
          cities: ["Gorontalo", "Limboto", "Tilamuta", "Marisa", "Kwandang", "Suwawa", "Bonebolango", "Boalemo", "Pohuwato", "Gorontalo Utara"]
        },
        {
          name: "Southeast Sulawesi",
          code: "SG",
          cities: ["Kendari", "Baubau", "Raha", "Kolaka", "Unaaha", "Wangi-Wangi", "Andoolo", "Rumbia", "Lainea", "Moramo"]
        },
        {
          name: "West Papua",
          code: "PB",
          cities: ["Manokwari", "Sorong", "Fakfak", "Kaimana", "Wasior", "Waisai", "Teminabuan", "Bintuni", "Rasiei", "Aimas"]
        },
        {
          name: "West Nusa Tenggara",
          code: "NB",
          cities: ["Mataram", "Bima", "Sumbawa Besar", "Dompu", "Praya", "Gili Trawangan", "Senggigi", "Selong", "Tanjung", "Alas"]
        },
        {
          name: "East Nusa Tenggara",
          code: "NT",
          cities: ["Kupang", "Ende", "Maumere", "Labuan Bajo", "Ruteng", "Kefamenanu", "Atambua", "Waingapu", "Kalabahi", "Soe"]
        },
        {
          name: "North Kalimantan",
          code: "KU",
          cities: ["Tanjung Selor", "Tarakan", "Malinau", "Nunukan", "Tanjung Palas", "Sesayap", "Tana Tidung", "Sembakung", "Bunyu", "Sekatak"]
        },
        {
          name: "Bangka Belitung Islands",
          code: "BB",
          cities: ["Pangkalpinang", "Tanjung Pandan", "Sungailiat", "Toboali", "Koba", "Belinyu", "Manggar", "Mentok", "Jebus", "Tempilang"]
        },
        {
          name: "North Maluku",
          code: "MU",
          cities: ["Ternate", "Tidore", "Sofifi", "Tobelo", "Jailolo", "Morotai", "Weda", "Labuha", "Sanana", "Maba"]
        },
        {
          name: "West Sulawesi",
          code: "SR",
          cities: ["Mamuju", "Majene", "Polewali", "Mamasa", "Pasangkayu", "Somba", "Topoyo", "Malunda", "Campalagian", "Wonomulyo"]
        },
        {
          name: "Riau Islands",
          code: "KR",
          cities: ["Tanjung Pinang", "Batam", "Tanjung Balai Karimun", "Ranai", "Daik", "Tarempa", "Sedanau", "Pulau Laut", "Senayang", "Dabo Singkep"]
        }
      ]
    },
    {
      name: "South Korea",
      code: "KR",
      states: [
        {
          name: "Seoul",
          code: "11",
          cities: ["Seoul", "Gangnam", "Gangdong", "Gangbuk", "Gangseo", "Gwanak", "Gwangjin", "Guro", "Geumcheon", "Nowon"]
        },
        {
          name: "Busan",
          code: "26",
          cities: ["Busan", "Haeundae", "Suyeong", "Geumjeong", "Busanjin", "Nam District", "Buk District", "Dong District", "Seo District", "Jung District"]
        },
        {
          name: "Incheon",
          code: "28",
          cities: ["Incheon", "Jung-gu", "Dong-gu", "Michuhol-gu", "Yeonsu-gu", "Namdong-gu", "Bupyeong-gu", "Gyeyang-gu", "Seo-gu", "Ganghwa-gun"]
        },
        {
          name: "Daegu",
          code: "27",
          cities: ["Daegu", "Jung-gu", "Dong-gu", "Seo-gu", "Nam-gu", "Buk-gu", "Suseong-gu", "Dalseo-gu", "Dalseong-gun", "Chilgok-gun"]
        },
        {
          name: "Daejeon",
          code: "30",
          cities: ["Daejeon", "Dong-gu", "Jung-gu", "Seo-gu", "Yuseong-gu", "Daedeok-gu", "Dunsan-dong", "Daejeon Station", "Expo Park", "Doryong-dong"]
        },
        {
          name: "Gwangju",
          code: "29",
          cities: ["Gwangju", "Dong-gu", "Seo-gu", "Nam-gu", "Buk-gu", "Gwangsan-gu", "Geumnam-ro", "Mudeung Mountain", "Songjeong-dong", "Cheomdan-dong"]
        },
        {
          name: "Ulsan",
          code: "31",
          cities: ["Ulsan", "Jung-gu", "Nam-gu", "Dong-gu", "Buk-gu", "Ulju-gun", "Taehwa River", "Hyundai Heavy Industries", "Ulsan Grand Park", "Ilsan Beach"]
        },
        {
          name: "Sejong",
          code: "36",
          cities: ["Sejong", "Hansol", "Government Complex", "Dodam", "Areum", "Daepyeong", "Jochiwon", "Goun", "Cheotmaul", "Boram"]
        },
        {
          name: "Gyeonggi Province",
          code: "41",
          cities: ["Suwon", "Seongnam", "Anyang", "Bucheon", "Goyang", "Yongin", "Ansan", "Namyangju", "Hwaseong", "Pyeongtaek"]
        },
        {
          name: "Gangwon Province",
          code: "42",
          cities: ["Chuncheon", "Wonju", "Gangneung", "Donghae", "Sokcho", "Taebaek", "Samcheok", "Hoengseong", "Pyeongchang", "Jeongseon"]
        },
        {
          name: "North Chungcheong Province",
          code: "43",
          cities: ["Cheongju", "Chungju", "Jecheon", "Eumseong", "Jincheon", "Boeun", "Okcheon", "Yeongdong", "Danyang", "Goesan"]
        },
        {
          name: "South Chungcheong Province",
          code: "44",
          cities: ["Cheonan", "Asan", "Seosan", "Nonsan", "Gongju", "Boryeong", "Gyeryong", "Dangjin", "Hongseong", "Buyeo"]
        },
        {
          name: "North Jeolla Province",
          code: "45",
          cities: ["Jeonju", "Iksan", "Gunsan", "Namwon", "Jeongeup", "Gimje", "Wanju", "Jinan", "Muju", "Imsil"]
        },
        {
          name: "South Jeolla Province",
          code: "46",
          cities: ["Gwangyang", "Mokpo", "Suncheon", "Yeosu", "Naju", "Jangheung", "Haenam", "Gangjin", "Gokseong", "Boseong"]
        },
        {
          name: "North Gyeongsang Province",
          code: "47",
          cities: ["Pohang", "Gyeongju", "Gimcheon", "Andong", "Gumi", "Yeongju", "Yeongcheon", "Sangju", "Mungyeong", "Gyeongsan"]
        },
        {
          name: "South Gyeongsang Province",
          code: "48",
          cities: ["Changwon", "Jinju", "Geoje", "Tongyeong", "Sacheon", "Gimhae", "Miryang", "Yangsan", "Hadong", "Geochang"]
        },
        {
          name: "Jeju Province",
          code: "49",
          cities: ["Jeju City", "Seogwipo", "Hallim", "Jungmun", "Seongsan", "Aewol", "Daejeong", "Hamdeok", "Gujwa", "Andeok"]
        }
      ]
    },
    {
      name: "Vietnam",
      code: "VN",
      states: [
        {
          name: "Hanoi",
          code: "HN",
          cities: ["Hanoi", "Ba Dinh", "Hai Ba Trung", "Dong Da", "Cau Giay", "Tay Ho", "Long Bien", "Hoang Mai", "Thanh Xuan", "Ha Dong"]
        },
        {
          name: "Ho Chi Minh City",
          code: "SG",
          cities: ["Ho Chi Minh City", "District 1", "District 2", "District 3", "District 4", "District 5", "District 6", "District 7", "District 8", "District 9"]
        },
        {
          name: "Da Nang",
          code: "DN",
          cities: ["Da Nang", "Hai Chau", "Thanh Khe", "Son Tra", "Ngu Hanh Son", "Cam Le", "Lien Chieu", "Hoa Vang", "My Khe Beach", "Non Nuoc Beach"]
        },
        {
          name: "Hai Phong",
          code: "HP",
          cities: ["Hai Phong", "Hong Bang", "Ngo Quyen", "Le Chan", "Hai An", "Kien An", "Do Son", "Duong Kinh", "An Duong", "Cat Hai"]
        },
        {
          name: "Can Tho",
          code: "CT",
          cities: ["Can Tho", "Ninh Kieu", "Binh Thuy", "Cai Rang", "O Mon", "Thot Not", "Vinh Thanh", "Co Do", "Phong Dien", "Thoi Lai"]
        },
        {
          name: "Quang Ninh",
          code: "QN",
          cities: ["Ha Long", "Cam Pha", "Uong Bi", "Mong Cai", "Quang Yen", "Dong Trieu", "Van Don", "Tien Yen", "Dam Ha", "Binh Lieu"]
        },
        {
          name: "Thanh Hoa",
          code: "TH",
          cities: ["Thanh Hoa", "Sam Son", "Bim Son", "Nghi Son", "Thieu Hoa", "Dong Son", "Nga Son", "Nong Cong", "Cam Thuy", "Lang Chanh"]
        },
        {
          name: "Nghe An",
          code: "NA",
          cities: ["Vinh", "Cua Lo", "Thai Hoa", "Hoang Mai", "Quy Hop", "Do Luong", "Dien Chau", "Anh Son", "Con Cuong", "Nam Dan"]
        },
        {
          name: "Thua Thien Hue",
          code: "TTH",
          cities: ["Hue", "Huong Thuy", "Huong Tra", "Phu Loc", "Phong Dien", "Quang Dien", "Phu Vang", "A Luoi", "Nam Dong", "Phong Dien"]
        },
        {
          name: "Khanh Hoa",
          code: "KH",
          cities: ["Nha Trang", "Cam Ranh", "Ninh Hoa", "Van Ninh", "Dien Khanh", "Khanh Vinh", "Khanh Son", "Truong Sa", "Dong Tac", "Vinh Phuoc"]
        },
        {
          name: "Lam Dong",
          code: "LD",
          cities: ["Da Lat", "Bao Loc", "Di Linh", "Duc Trong", "Don Duong", "Lam Ha", "Dam Rong", "Cat Tien", "Bao Lam", "Da Huoai"]
        },
        {
          name: "Dong Nai",
          code: "DN",
          cities: ["Bien Hoa", "Long Khanh", "Nhon Trach", "Trang Bom", "Long Thanh", "Xuan Loc", "Thong Nhat", "Vinh Cuu", "Cam My", "Dinh Quan"]
        },
        {
          name: "Ba Ria - Vung Tau",
          code: "BR",
          cities: ["Vung Tau", "Ba Ria", "Phu My", "Long Dien", "Dat Do", "Xuyen Moc", "Chau Duc", "Con Dao", "Phuoc Tinh", "Long Hai"]
        },
        {
          name: "Binh Duong",
          code: "BDU",
          cities: ["Thu Dau Mot", "Di An", "Thuan An", "Ben Cat", "Tan Uyen", "Bac Tan Uyen", "Phu Giao", "Dau Tieng", "Bau Bang", "Song Be"]
        },
        {
          name: "Long An",
          code: "LA",
          cities: ["Tan An", "Kien Tuong", "Ben Luc", "Can Duoc", "Can Giuoc", "Duc Hoa", "Chau Thanh", "Tan Tru", "Thu Thua", "Tan Hung"]
        },
        {
          name: "Quang Nam",
          code: "QNA",
          cities: ["Tam Ky", "Hoi An", "Dien Ban", "Dai Loc", "Duy Xuyen", "Que Son", "Thang Binh", "Phu Ninh", "Nui Thanh", "Nam Giang"]
        },
        {
          name: "Binh Dinh",
          code: "BDI",
          cities: ["Quy Nhon", "An Nhon", "Hoai Nhon", "Tuy Phuoc", "Phu Cat", "Phu My", "Tay Son", "Van Canh", "Vinh Thanh", "An Lao"]
        },
        {
          name: "Dak Lak",
          code: "DLK",
          cities: ["Buon Ma Thuot", "Buon Ho", "Ea Kar", "Krong Pak", "Cu Mgar", "Ea Sup", "Krong Ana", "Krong Bong", "Krong Buk", "Lak"]
        },
        {
          name: "Phu Tho",
          code: "PT",
          cities: ["Viet Tri", "Phu Tho", "Song Thao", "Lam Thao", "Thanh Ba", "Tam Nong", "Thanh Son", "Tan Son", "Cam Khe", "Doan Hung"]
        },
        {
          name: "Tien Giang",
          code: "TG",
          cities: ["My Tho", "Go Cong", "Cai Lay", "Cai Be", "Cho Gao", "Chau Thanh", "Tan Phuoc", "Tan Phu Dong", "Cho Gao", "Go Cong Tay"]
        },
        {
          name: "Bac Ninh",
          code: "BN",
          cities: ["Bac Ninh", "Tu Son", "Tien Du", "Thuan Thanh", "Que Vo", "Yen Phong", "Luong Tai", "Gia Binh", "Hiep Hoa", "Son Dong"]
        },
        {
          name: "Thai Nguyen",
          code: "TN",
          cities: ["Thai Nguyen", "Song Cong", "Pho Yen", "Dong Hy", "Phu Binh", "Phu Luong", "Dai Tu", "Dinh Hoa", "Vo Nhai", "Trang Xa"]
        },
        {
          name: "Bac Giang",
          code: "BG",
          cities: ["Bac Giang", "Viet Yen", "Yen Dung", "Luc Nam", "Luc Ngan", "Lang Giang", "Son Dong", "Tan Yen", "Hiep Hoa", "Yen The"]
        },
        {
          name: "Ben Tre",
          code: "BTE",
          cities: ["Ben Tre", "Ba Tri", "Binh Dai", "Chau Thanh", "Cho Lach", "Giong Trom", "Mo Cay Bac", "Mo Cay Nam", "Thanh Phu", "Thach Phu"]
        },
        {
          name: "Vinh Long",
          code: "VL",
          cities: ["Vinh Long", "Binh Minh", "Long Ho", "Mang Thit", "Tam Binh", "Tra On", "Vung Liem", "Binh Tan", "Co Chien", "Tan Dinh"]
        },
        {
          name: "Nam Dinh",
          code: "NDD",
          cities: ["Nam Dinh", "Giao Thuy", "Hai Hau", "My Loc", "Nam Truc", "Nghia Hung", "Truc Ninh", "Xuan Truong", "Y Yen", "Vu Ban"]
        },
        {
          name: "Vinh Phuc",
          code: "VP",
          cities: ["Vinh Yen", "Phuc Yen", "Binh Xuyen", "Lap Thach", "Song Lo", "Tam Dao", "Tam Duong", "Vinh Tuong", "Yen Lac", "Huong Canh"]
        },
        {
          name: "Binh Thuan",
          code: "BTH",
          cities: ["Phan Thiet", "La Gi", "Phan Ri Cua", "Phu Quy", "Bac Binh", "Ham Tan", "Ham Thuan Bac", "Ham Thuan Nam", "Tanh Linh", "Tuy Phong"]
        },
        {
          name: "Phu Yen",
          code: "PY",
          cities: ["Tuy Hoa", "Song Cau", "Dong Hoa", "Phu Hoa", "Tay Hoa", "Son Hoa", "Song Hinh", "Tuy An", "Dong Xuan", "Tan Vien"]
        },
        {
          name: "Ha Tinh",
          code: "HT",
          cities: ["Ha Tinh", "Hong Linh", "Ky Anh", "Thach Ha", "Cam Xuyen", "Can Loc", "Duc Tho", "Huong Khe", "Huong Son", "Vu Quang"]
        },
        {
          name: "Tra Vinh",
          code: "TV",
          cities: ["Tra Vinh", "Duyen Hai", "Cang Long", "Cau Ke", "Cau Ngang", "Chau Thanh", "Tieu Can", "Tra Cu", "Duyen Hai", "Tieu Can"]
        }
      ]
    }
  ]
};