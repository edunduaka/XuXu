import CryptoJS from 'crypto-js';
import bcrypt from 'bcryptjs';

// Encryption configuration
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'xuxu-platform-secure-key-2024';
const SALT_ROUNDS = 12;

export class DataEncryption {
  // Encrypt sensitive data for database storage
  static encrypt(data: string): string {
    try {
      return CryptoJS.AES.encrypt(data, ENCRYPTION_KEY).toString();
    } catch (error) {
      console.error('Encryption error:', error);
      throw new Error('Failed to encrypt data');
    }
  }

  // Decrypt data from database
  static decrypt(encryptedData: string): string {
    try {
      const bytes = CryptoJS.AES.decrypt(encryptedData, ENCRYPTION_KEY);
      return bytes.toString(CryptoJS.enc.Utf8);
    } catch (error) {
      console.error('Decryption error:', error);
      throw new Error('Failed to decrypt data');
    }
  }

  // Hash passwords securely
  static async hashPassword(password: string): Promise<string> {
    try {
      return await bcrypt.hash(password, SALT_ROUNDS);
    } catch (error) {
      console.error('Password hashing error:', error);
      throw new Error('Failed to hash password');
    }
  }

  // Verify password against hash
  static async verifyPassword(password: string, hash: string): Promise<boolean> {
    try {
      return await bcrypt.compare(password, hash);
    } catch (error) {
      console.error('Password verification error:', error);
      return false;
    }
  }

  // Encrypt personal information
  static encryptPersonalInfo(data: {
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
    address1: string;
    address2?: string;
  }) {
    return {
      firstName: this.encrypt(data.firstName),
      lastName: this.encrypt(data.lastName),
      email: this.encrypt(data.email),
      phoneNumber: this.encrypt(data.phoneNumber),
      address1: this.encrypt(data.address1),
      address2: data.address2 ? this.encrypt(data.address2) : null,
    };
  }

  // Decrypt personal information
  static decryptPersonalInfo(encryptedData: {
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
    address1: string;
    address2?: string | null;
  }) {
    return {
      firstName: this.decrypt(encryptedData.firstName),
      lastName: this.decrypt(encryptedData.lastName),
      email: this.decrypt(encryptedData.email),
      phoneNumber: this.decrypt(encryptedData.phoneNumber),
      address1: this.decrypt(encryptedData.address1),
      address2: encryptedData.address2 ? this.decrypt(encryptedData.address2) : undefined,
    };
  }

  // Encrypt file data (for ID documents and images)
  static encryptFileData(fileBuffer: Buffer): string {
    try {
      const fileString = fileBuffer.toString('base64');
      return this.encrypt(fileString);
    } catch (error) {
      console.error('File encryption error:', error);
      throw new Error('Failed to encrypt file data');
    }
  }

  // Decrypt file data
  static decryptFileData(encryptedData: string): Buffer {
    try {
      const decryptedString = this.decrypt(encryptedData);
      return Buffer.from(decryptedString, 'base64');
    } catch (error) {
      console.error('File decryption error:', error);
      throw new Error('Failed to decrypt file data');
    }
  }

  // Generate secure random tokens
  static generateSecureToken(): string {
    return CryptoJS.lib.WordArray.random(32).toString();
  }

  // Hash sensitive identifiers for secure lookup
  static hashIdentifier(identifier: string): string {
    return CryptoJS.SHA256(identifier + ENCRYPTION_KEY).toString();
  }
}

// Middleware for encrypting request data in transit
export const encryptTransitData = (req: any, res: any, next: any) => {
  // Ensure HTTPS in production
  if (process.env.NODE_ENV === 'production' && !req.secure && req.headers['x-forwarded-proto'] !== 'https') {
    return res.redirect(301, `https://${req.headers.host}${req.url}`);
  }

  // Add security headers for data in transit
  res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');

  next();
};

// Utility for secure data handling
export const secureDataHandler = {
  // Sanitize input data
  sanitizeInput: (data: any): any => {
    if (typeof data === 'string') {
      return data.trim().replace(/[<>]/g, '');
    }
    if (typeof data === 'object' && data !== null) {
      const sanitized: any = {};
      for (const key in data) {
        sanitized[key] = secureDataHandler.sanitizeInput(data[key]);
      }
      return sanitized;
    }
    return data;
  },

  // Validate data integrity
  validateDataIntegrity: (data: any): boolean => {
    try {
      // Check for required fields and data types
      if (!data || typeof data !== 'object') return false;
      
      // Validate email format if present
      if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) return false;
      
      // Validate phone number if present
      if (data.phoneNumber && !/^\+?[\d\s\-\(\)]{10,}$/.test(data.phoneNumber)) return false;
      
      return true;
    } catch (error) {
      return false;
    }
  }
};