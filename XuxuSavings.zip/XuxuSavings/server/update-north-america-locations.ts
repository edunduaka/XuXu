import { readFileSync, writeFileSync } from 'fs';
import { join } from 'path';
import { northAmericaLocationData } from './north-america-location-data';

export function updateNorthAmericaLocationData() {
  console.log('🇺🇸 Updating North America region with authentic location data...');
  
  try {
    // Read existing processed countries data
    const existingDataPath = join(process.cwd(), 'processed-countries.json');
    let existingCountries = [];
    
    try {
      const existingData = readFileSync(existingDataPath, 'utf-8');
      existingCountries = JSON.parse(existingData);
    } catch (error) {
      console.log('Creating new countries data file...');
      existingCountries = [];
    }
    
    // Create a map of existing countries for faster lookup
    const existingCountriesMap = new Map();
    existingCountries.forEach((country: any) => {
      existingCountriesMap.set(country.code, country);
    });
    
    // Update with authentic North America data
    northAmericaLocationData.countries.forEach(northAmericaCountry => {
      if (existingCountriesMap.has(northAmericaCountry.code)) {
        // Update existing North American country with authentic data
        const existingIndex = existingCountries.findIndex((c: any) => c.code === northAmericaCountry.code);
        if (existingIndex !== -1) {
          existingCountries[existingIndex] = {
            name: northAmericaCountry.name,
            code: northAmericaCountry.code,
            region: northAmericaCountry.region,
            states: northAmericaCountry.states
          };
          console.log(`✅ Updated ${northAmericaCountry.name} with ${northAmericaCountry.states.length} states`);
        }
      } else {
        // Add new North American country
        existingCountries.push({
          name: northAmericaCountry.name,
          code: northAmericaCountry.code,
          region: northAmericaCountry.region,
          states: northAmericaCountry.states
        });
        console.log(`🆕 Added ${northAmericaCountry.name} with ${northAmericaCountry.states.length} states`);
      }
    });
    
    // Write the updated countries data back to file
    writeFileSync(existingDataPath, JSON.stringify(existingCountries, null, 2));
    console.log('✅ North America location data update completed successfully!');
    console.log(`📊 Total countries in database: ${existingCountries.length}`);
    
    // Log specific US states count
    const usCountry = existingCountries.find((c: any) => c.code === 'US');
    if (usCountry) {
      console.log(`🇺🇸 United States now has ${usCountry.states.length} states with complete city data`);
    }
    
    return true;
  } catch (error) {
    console.error('❌ Error updating North America location data:', error);
    return false;
  }
}

// Execute the update
updateNorthAmericaLocationData();