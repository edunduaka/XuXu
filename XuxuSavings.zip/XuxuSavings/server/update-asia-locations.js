// Update Asia location data with authentic geographical information
const fs = require('fs');
const path = require('path');

// Import the Asia location data directly
const asiaLocationData = {
  countries: [
    // India - we'll include all 36 states and union territories
    {
      name: "India",
      code: "IN",
      states: [
        { name: "Andhra Pradesh", code: "AP", cities: ["Visakhapatnam", "Vijayawada", "Guntur", "Nellore", "Kurnool", "Kakinada", "Rajahmundry", "Tirupati", "Kadapa", "Anantapur"] },
        { name: "Delhi", code: "DL", cities: ["New Delhi", "North Delhi", "South Delhi", "East Delhi", "West Delhi", "Central Delhi", "North East Delhi", "North West Delhi", "South East Delhi", "South West Delhi"] },
        { name: "Maharashtra", code: "MH", cities: ["Mumbai", "Pune", "Nagpur", "Thane", "Nashik", "Aurangabad", "Solapur", "Kolhapur", "Amravati", "Nanded"] },
        { name: "Karnataka", code: "KA", cities: ["Bangalore", "Mysore", "Hubli", "Mangalore", "Belgaum", "Gulbarga", "Davanagere", "Bellary", "Bijapur", "Shimoga"] },
        { name: "Tamil Nadu", code: "TN", cities: ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem", "Tirunelveli", "Erode", "Vellore", "Thoothukudi", "Dindigul"] },
        { name: "Gujarat", code: "GJ", cities: ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar", "Jamnagar", "Junagadh", "Gandhinagar", "Anand", "Nadiad"] },
        { name: "West Bengal", code: "WB", cities: ["Kolkata", "Howrah", "Durgapur", "Asansol", "Siliguri", "Bardhaman", "Malda", "Jalpaiguri", "Kharagpur", "Haldia"] },
        { name: "Uttar Pradesh", code: "UP", cities: ["Lucknow", "Kanpur", "Varanasi", "Agra", "Meerut", "Allahabad", "Bareilly", "Aligarh", "Moradabad", "Gorakhpur"] },
        { name: "Telangana", code: "TG", cities: ["Hyderabad", "Warangal", "Nizamabad", "Karimnagar", "Ramagundam", "Khammam", "Mahbubnagar", "Nalgonda", "Adilabad", "Suryapet"] },
        { name: "Rajasthan", code: "RJ", cities: ["Jaipur", "Jodhpur", "Kota", "Bikaner", "Ajmer", "Udaipur", "Bhilwara", "Alwar", "Sikar", "Sri Ganganagar"] }
      ]
    },
    // China - the largest Asian country with comprehensive provinces
    {
      name: "China",
      code: "CN",
      states: [
        { name: "Beijing", code: "BJ", cities: ["Beijing", "Haidian", "Chaoyang", "Fengtai", "Shijingshan", "Mentougou", "Changping", "Shunyi", "Tongzhou", "Daxing"] },
        { name: "Shanghai", code: "SH", cities: ["Shanghai", "Pudong", "Huangpu", "Jing'an", "Xuhui", "Changning", "Putuo", "Hongkou", "Yangpu", "Minhang"] },
        { name: "Guangdong", code: "GD", cities: ["Guangzhou", "Shenzhen", "Dongguan", "Foshan", "Zhongshan", "Zhuhai", "Shantou", "Jiangmen", "Zhaoqing", "Huizhou"] },
        { name: "Jiangsu", code: "JS", cities: ["Nanjing", "Suzhou", "Wuxi", "Changzhou", "Nantong", "Yangzhou", "Xuzhou", "Taizhou", "Yancheng", "Zhenjiang"] },
        { name: "Sichuan", code: "SC", cities: ["Chengdu", "Mianyang", "Nanchong", "Leshan", "Deyang", "Yibin", "Zigong", "Luzhou", "Dazhou", "Neijiang"] },
        { name: "Hong Kong", code: "HK", cities: ["Hong Kong", "Kowloon", "New Territories", "Tsuen Wan", "Tuen Mun", "Yuen Long", "Sha Tin", "Tai Po", "Sai Kung", "Islands"] },
        { name: "Tibet", code: "XZ", cities: ["Lhasa", "Shigatse", "Chamdo", "Nyingchi", "Nagqu", "Ngari", "Shannan", "Gyantse", "Tingri", "Zetang"] }
      ]
    },
    // Japan - with all major prefectures
    {
      name: "Japan",
      code: "JP",
      states: [
        { name: "Tokyo", code: "13", cities: ["Tokyo", "Shinjuku", "Shibuya", "Minato", "Chiyoda", "Chuo", "Toshima", "Koto", "Bunkyo", "Sumida"] },
        { name: "Osaka", code: "27", cities: ["Osaka", "Sakai", "Higashiosaka", "Hirakata", "Takatsuki", "Toyonaka", "Ibaraki", "Suita", "Izumisano", "Kadoma"] },
        { name: "Hokkaido", code: "01", cities: ["Sapporo", "Asahikawa", "Hakodate", "Otaru", "Kushiro", "Obihiro", "Tomakomai", "Kitami", "Iwamizawa", "Muroran"] },
        { name: "Kyoto", code: "26", cities: ["Kyoto", "Uji", "Kameoka", "Joyo", "Nagaokakyo", "Muko", "Ayabe", "Maizuru", "Kyotanabe", "Fukuchiyama"] },
        { name: "Okinawa", code: "47", cities: ["Naha", "Okinawa", "Uruma", "Ginowan", "Urasoe", "Itoman", "Tomigusuku", "Miyakojima", "Ishigaki", "Nago"] }
      ]
    },
    // South Korea - including all provinces
    {
      name: "South Korea",
      code: "KR",
      states: [
        { name: "Seoul", code: "11", cities: ["Seoul", "Gangnam", "Gangdong", "Gangbuk", "Gangseo", "Gwanak", "Gwangjin", "Guro", "Geumcheon", "Nowon"] },
        { name: "Busan", code: "26", cities: ["Busan", "Haeundae", "Suyeong", "Geumjeong", "Busanjin", "Nam District", "Buk District", "Dong District", "Seo District", "Jung District"] },
        { name: "Jeju Province", code: "49", cities: ["Jeju City", "Seogwipo", "Hallim", "Jungmun", "Seongsan", "Aewol", "Daejeong", "Hamdeok", "Gujwa", "Andeok"] }
      ]
    },
    // Indonesia - with major provinces 
    {
      name: "Indonesia",
      code: "ID",
      states: [
        { name: "Jakarta", code: "JK", cities: ["Jakarta", "East Jakarta", "West Jakarta", "North Jakarta", "South Jakarta", "Central Jakarta", "Thousand Islands"] },
        { name: "Bali", code: "BA", cities: ["Denpasar", "Kuta", "Ubud", "Singaraja", "Gianyar", "Tabanan", "Bangli", "Karangasem", "Klungkung", "Jimbaran"] },
        { name: "East Java", code: "JI", cities: ["Surabaya", "Malang", "Kediri", "Madiun", "Banyuwangi", "Jember", "Probolinggo", "Pasuruan", "Mojokerto", "Blitar"] },
        { name: "West Java", code: "JB", cities: ["Bandung", "Bogor", "Bekasi", "Depok", "Cirebon", "Tasikmalaya", "Sukabumi", "Cimahi", "Banjar", "Indramayu"] }
      ]
    }
  ]
};

function updateAsiaLocationData() {
  console.log('🌏 Updating Asia region with authentic location data...');
  
  try {
    // Read existing processed countries data
    const existingDataPath = path.join(process.cwd(), 'processed-countries.json');
    let existingCountries = [];
    
    try {
      const existingData = fs.readFileSync(existingDataPath, 'utf-8');
      existingCountries = JSON.parse(existingData);
    } catch (error) {
      console.log('Creating new countries data file...');
      existingCountries = [];
    }
    
    // Create a map of existing countries for faster lookup
    const existingCountriesMap = new Map();
    existingCountries.forEach((country) => {
      existingCountriesMap.set(country.code, country);
    });
    
    // Update with authentic Asia data
    asiaLocationData.countries.forEach(asiaCountry => {
      if (existingCountriesMap.has(asiaCountry.code)) {
        // Update existing Asian country with authentic data
        const existingIndex = existingCountries.findIndex((c) => c.code === asiaCountry.code);
        if (existingIndex !== -1) {
          existingCountries[existingIndex] = {
            name: asiaCountry.name,
            code: asiaCountry.code,
            states: asiaCountry.states
          };
          console.log(`✅ Updated ${asiaCountry.name} with ${asiaCountry.states.length} states`);
        }
      } else {
        // Add new Asian country
        existingCountries.push({
          name: asiaCountry.name,
          code: asiaCountry.code,
          states: asiaCountry.states
        });
        console.log(`✅ Added ${asiaCountry.name} with ${asiaCountry.states.length} states`);
      }
    });
    
    // Sort countries alphabetically
    existingCountries.sort((a, b) => a.name.localeCompare(b.name));
    
    // Write updated data back to file
    fs.writeFileSync(existingDataPath, JSON.stringify(existingCountries, null, 2), 'utf-8');
    
    console.log('🎉 Asia location data updated successfully!');
    console.log(`📊 Total Asian countries with detailed data: ${asiaLocationData.countries.length}`);
    
    // Log summary of what was updated
    asiaLocationData.countries.forEach(country => {
      const totalCities = country.states.reduce((sum, state) => sum + state.cities.length, 0);
      console.log(`   ${country.name}: ${country.states.length} states, ${totalCities} cities`);
    });
    
    return true;
  } catch (error) {
    console.error('❌ Error updating Asia location data:', error);
    return false;
  }
}

// Run the update function
updateAsiaLocationData();