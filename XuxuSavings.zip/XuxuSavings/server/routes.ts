import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from "fs";
import { insertUserSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { turboEmailService } from "./turbo-email-service";

// Configure multer for file uploads
const uploadsDir = path.join(process.cwd(), "uploads");

// Create uploads directory if it doesn't exist
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage2 = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (_req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname);
    cb(null, file.fieldname + "-" + uniqueSuffix + ext);
  },
});

const upload = multer({
  storage: storage2,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (_req, file, cb) => {
    const allowedTypes = ["image/jpeg", "image/png", "application/pdf"];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type. Only JPG, PNG, and PDF files are allowed.") as any);
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Add basic security headers
  app.use((req: any, res: any, next: any) => {
    // Add security headers
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  // Check for duplicate fields endpoint
  app.post("/api/check-duplicate", async (req, res) => {
    try {
      const { fieldName, value } = req.body;
      
      if (!fieldName || !value) {
        return res.status(400).json({ 
          isDuplicate: false, 
          message: "Field name and value are required" 
        });
      }

      const isDuplicate = await storage.checkDuplicateField(fieldName, value);
      
      res.json({ 
        isDuplicate,
        fieldName,
        value,
        message: isDuplicate ? `${fieldName} already exists` : `${fieldName} is available`
      });
    } catch (error) {
      console.error("Duplicate check error:", error);
      res.status(500).json({ 
        isDuplicate: false, 
        message: "Error checking for duplicates" 
      });
    }
  });

  // Test email endpoint
  app.post("/api/test-email", async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ message: "Email address required" });
      }

      console.log(`📧 Testing email delivery to: ${email}`);
      const emailSent = await turboEmailService.sendRegistrationEmail({
        userEmail: email,
        password: "TestPassword123",
        firstName: "Test",
        lastName: "User"
      });

      res.json({
        success: emailSent,
        message: emailSent 
          ? `Test email sent successfully to ${email}` 
          : "Failed to send test email"
      });
    } catch (error) {
      console.error("Test email error:", error);
      res.status(500).json({ message: "Email test failed" });
    }
  });

  // Email confirmation endpoint - works with both paths
  app.get(["/confirm-email", "/api/confirm-email"], async (req, res) => {
    const { token, email } = req.query;
    
    // Validate the token and email parameters
    if (!token || !email) {
      return res.status(400).send(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Invalid Confirmation Link - Xuxu</title>
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            body { font-family: Arial, sans-serif; text-align: center; padding: 50px; background: #f5f5f5; }
            .error-container { background: white; padding: 40px; border-radius: 10px; max-width: 500px; margin: 0 auto; }
            .error-title { color: #e74c3c; font-size: 24px; margin-bottom: 20px; }
            .back-button { background: #07434f; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block; margin-top: 20px; }
          </style>
        </head>
        <body>
          <div class="error-container">
            <h1 class="error-title">❌ Invalid Confirmation Link</h1>
            <p>This confirmation link appears to be invalid or incomplete. Please check your email for the correct link or contact support if you continue to have issues.</p>
            <a href="/" class="back-button">Return to Xuxu</a>
          </div>
        </body>
        </html>
      `);
    }

    console.log(`📧 Email confirmation attempted for: ${email} with token: ${token}`);
    
    // Here you would typically validate the token against your database
    // For now, we'll show success for any valid token/email combination
    
    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Email Confirmed - Xuxu</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #07434f, #0a5660);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
          }
          .popup-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s ease-out;
          }
          .popup-container {
            background: white;
            border-radius: 20px;
            padding: 40px;
            max-width: 500px;
            width: 90%;
            text-align: center;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            transform: scale(0.8);
            animation: popIn 0.5s ease-out forwards;
          }
          @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
          }
          @keyframes popIn {
            from { transform: scale(0.8); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
          }
          .success-icon {
            font-size: 80px;
            color: #28a745;
            margin-bottom: 20px;
            animation: bounce 1s ease-out;
          }
          @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
            40% { transform: translateY(-10px); }
            60% { transform: translateY(-5px); }
          }
          .success-title {
            color: #07434f;
            font-size: 32px;
            font-weight: 600;
            margin-bottom: 15px;
          }
          .success-message {
            color: #666;
            font-size: 18px;
            line-height: 1.6;
            margin-bottom: 25px;
          }
          .email-display {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            padding: 15px;
            border-radius: 10px;
            margin: 25px 0;
            font-weight: 600;
            color: #07434f;
            border: 2px solid #dee2e6;
          }
          .features {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin: 25px 0;
            text-align: left;
          }
          .features h4 {
            color: #07434f;
            margin-bottom: 15px;
            text-align: center;
          }
          .features ul {
            list-style: none;
            padding: 0;
          }
          .features li {
            padding: 8px 0;
            color: #555;
          }
          .features li:before {
            content: "✓ ";
            color: #28a745;
            font-weight: bold;
            margin-right: 8px;
          }
          .button-container {
            margin-top: 30px;
          }
          .return-button {
            display: inline-block;
            background: linear-gradient(135deg, #07434f, #0a5660);
            color: white;
            padding: 15px 35px;
            text-decoration: none;
            border-radius: 50px;
            font-weight: 600;
            font-size: 16px;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(7, 67, 79, 0.3);
          }
          .return-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(7, 67, 79, 0.4);
            background: linear-gradient(135deg, #0a5660, #07434f);
          }
          .confetti {
            position: absolute;
            width: 10px;
            height: 10px;
            background: #ffd700;
            animation: confetti-fall 3s linear infinite;
          }
          @keyframes confetti-fall {
            0% { transform: translateY(-100vh) rotate(0deg); opacity: 1; }
            100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
          }
          .xuxu-logo {
            color: #07434f;
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
          }
        </style>
      </head>
      <body>
        <div class="popup-overlay">
          <div class="popup-container">
            <div class="xuxu-logo">🏦 XUXU</div>
            <div class="success-icon">🎉</div>
            <h1 class="success-title">Email Confirmed!</h1>
            <p class="success-message">
              Congratulations! Your email has been successfully verified and your Xuxu account is now fully activated.
            </p>
            <div class="email-display">${email}</div>
            
            <div class="features">
              <h4>🚀 What's Next?</h4>
              <ul>
                <li>Join or create savings groups</li>
                <li>Set your financial goals</li>
                <li>Track your contributions</li>
                <li>Connect with like-minded savers</li>
                <li>Start your wealth-building journey</li>
              </ul>
            </div>
            
            <div class="button-container">
              <a href="/" class="return-button">Return to Xuxu 🏠</a>
            </div>
          </div>
        </div>

        <script>
          // Add confetti animation
          function createConfetti() {
            const colors = ['#ffd700', '#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4'];
            for (let i = 0; i < 50; i++) {
              const confetti = document.createElement('div');
              confetti.className = 'confetti';
              confetti.style.left = Math.random() * 100 + '%';
              confetti.style.background = colors[Math.floor(Math.random() * colors.length)];
              confetti.style.animationDelay = Math.random() * 3 + 's';
              confetti.style.animationDuration = (Math.random() * 3 + 2) + 's';
              document.body.appendChild(confetti);
              
              setTimeout(() => {
                confetti.remove();
              }, 5000);
            }
          }
          
          // Trigger confetti on load
          window.addEventListener('load', createConfetti);
          
          // Auto-redirect after 10 seconds with countdown
          let countdown = 10;
          const button = document.querySelector('.return-button');
          const originalText = button.textContent;
          
          const timer = setInterval(() => {
            countdown--;
            button.textContent = \`\${originalText} (\${countdown}s)\`;
            
            if (countdown <= 0) {
              clearInterval(timer);
              window.location.href = '/';
            }
          }, 1000);
          
          // Clear timer if user clicks button
          button.addEventListener('click', () => {
            clearInterval(timer);
          });
        </script>
      </body>
      </html>
    `);
  });

  // User registration endpoint
  app.post("/api/register", upload.fields([
    { name: "idDocument", maxCount: 1 }
  ]), async (req, res) => {
    try {
      console.log("🚀 REGISTRATION ENDPOINT HIT");
      console.log("📝 Request body:", JSON.stringify(req.body, null, 2));
      console.log("📁 Files uploaded:", req.files ? Object.keys(req.files).join(", ") : "No files");
      
      // Parse and validate request body
      console.log("🔍 Parsing user data with schema...");
      
      // Selfie functionality temporarily disabled - always set to null
      // Build user data object without optional fields that might be undefined
      const baseUserData = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        phoneNumber: req.body.phoneNumber,
        dateOfBirth: req.body.dateOfBirth,
        gender: req.body.gender,
        region: req.body.region,
        country: req.body.country,
        state: req.body.state,
        city: req.body.city,
        address1: req.body.address1,
        password: req.body.password,
      };

      // Add optional fields only if they exist
      if (req.body.middleName) {
        (baseUserData as any).middleName = req.body.middleName;
      }
      if (req.body.address2) {
        (baseUserData as any).address2 = req.body.address2;
      }
      if (req.body.idType) {
        (baseUserData as any).idType = req.body.idType;
      }
      if (req.files && (req.files as any)['idDocument']) {
        (baseUserData as any).idDocumentPath = (req.files as any)['idDocument'][0].path;
      }

      console.log("📊 Base user data prepared:", JSON.stringify(baseUserData, null, 2));

      const userData = insertUserSchema.parse(baseUserData);
      console.log("✅ Schema validation passed");

      // Create user in storage
      console.log("💾 Creating user in database...");
      console.log("📝 Validated user data:", JSON.stringify(userData, null, 2));
      
      const user = await storage.createUser(userData);
      console.log("✅ User created successfully with ID:", user.id);
      console.log("📋 Created user details:", JSON.stringify(user, null, 2));

      // Send authentication email asynchronously (non-blocking)
      console.log("📧 Sending registration confirmation email...");
      turboEmailService.sendRegistrationEmail({
        userEmail: userData.email,
        password: userData.password,
        firstName: userData.firstName,
        lastName: userData.lastName
      }).then((emailSent) => {
        if (emailSent) {
          console.log(`✅ Authentication email sent successfully to: ${userData.email}`);
        } else {
          console.log(`⚠️  Warning: Email could not be sent to: ${userData.email}`);
        }
      }).catch((error) => {
        console.log(`⚠️  Email sending failed for: ${userData.email}`, error);
      });

      // Return success response immediately
      res.status(201).json({
        message: "User registered successfully",
        userId: user.id,
        emailSent: true,
        emailMessage: "Registration successful! Please check your email for confirmation."
      });
    } catch (error) {
      // Handle validation errors
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
        return;
      }

      // Handle other errors
      console.error("Registration error:", error);
      console.error("Error stack:", error instanceof Error ? error.stack : 'No stack trace');
      console.error("Error details:", JSON.stringify(error, null, 2));
      res.status(500).json({ 
        message: "An error occurred during registration", 
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });



  const httpServer = createServer(app);

  return httpServer;
}
