import nodemailer from 'nodemailer';
import { randomBytes } from 'crypto';

interface EmailData {
  userEmail: string;
  password: string;
  firstName: string;
  lastName: string;
}

interface QueueItem {
  data: EmailData;
  resolve: (value: boolean) => void;
  reject: (reason?: any) => void;
}

export class TurboEmailService {
  private transporter: any;
  private emailQueue: QueueItem[] = [];
  private isProcessing = false;
  
  constructor() {
    // Ultra-fast email configuration with connection pooling
    this.transporter = nodemailer.createTransport({
      service: 'gmail',
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      connectionTimeout: 5000, // 5 seconds
      greetingTimeout: 3000, // 3 seconds
      socketTimeout: 10000, // 10 seconds
      pool: true, // Enable connection pooling
      maxConnections: 5, // Maximum 5 connections
      maxMessages: 100, // 100 messages per connection
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      },
      tls: {
        rejectUnauthorized: false
      }
    });
  }

  generateConfirmationToken(): string {
    return randomBytes(16).toString('hex'); // Shorter token for speed
  }

  async sendRegistrationEmail(data: EmailData): Promise<boolean> {
    return new Promise((resolve, reject) => {
      // Add to queue for batch processing
      this.emailQueue.push({ data, resolve, reject });
      
      if (!this.isProcessing) {
        this.processEmailQueue();
      }
    });
  }

  private async processEmailQueue(): Promise<void> {
    if (this.isProcessing || this.emailQueue.length === 0) return;
    
    this.isProcessing = true;
    
    while (this.emailQueue.length > 0) {
      const batch = this.emailQueue.splice(0, 3); // Process 3 emails at once
      
      await Promise.allSettled(
        batch.map(async ({ data, resolve, reject }) => {
          try {
            const result = await this.sendSingleEmail(data);
            resolve(result);
          } catch (error) {
            reject(error);
          }
        })
      );
    }
    
    this.isProcessing = false;
  }

  private async sendSingleEmail(data: EmailData): Promise<boolean> {
    try {
      const confirmationToken = this.generateConfirmationToken();
      const baseUrl = 'https://9724f777-70bf-4e9c-8735-97bd6fa3745c.spock.prod.repl.run';
      const confirmationLink = `${baseUrl}/confirm-email?token=${confirmationToken}&email=${encodeURIComponent(data.userEmail)}`;
      
      // Optimized HTML template - minified for speed
      const htmlContent = this.generateOptimizedHTML(data, confirmationLink);
      
      const mailOptions = {
        from: {
          name: 'Xuxu Team',
          address: process.env.EMAIL_USER || 'xuxuthrift@gmail.com'
        },
        to: data.userEmail,
        subject: '🎉 Welcome to Xuxu - Account Created!',
        html: htmlContent,
        text: this.generateTextContent(data, confirmationLink),
        priority: 'high'
      };

      await this.transporter.sendMail(mailOptions);
      console.log(`✅ Turbo email sent to: ${data.userEmail}`);
      return true;
    } catch (error) {
      console.error('📧 Turbo email error:', error);
      return false;
    }
  }

  private generateOptimizedHTML(data: EmailData, confirmationLink: string): string {
    return `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Welcome to Xuxu</title><style>body{font-family:Arial,sans-serif;margin:0;padding:0;background:#f4f4f4}.container{max-width:600px;margin:20px auto;background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 0 20px rgba(0,0,0,0.1)}.header{background:linear-gradient(135deg,#07434f,#0a5660);color:#fff;padding:30px;text-align:center}.header h1{margin:0;font-size:24px}.content{padding:30px}.button{display:inline-block;background:#07434f;color:#ffffff !important;padding:15px 30px;text-decoration:none;border-radius:5px;margin:20px 0;font-weight:bold}.button:visited{color:#ffffff !important}.button:hover{color:#ffffff !important}.footer{background:#f8f9fa;padding:20px;text-align:center;color:#666;font-size:14px}</style></head><body><div class="container"><div class="header"><h1>🎉 Welcome to Xuxu!</h1><p>Your Group Savings Platform</p></div><div class="content"><h2>Hello ${data.firstName} ${data.lastName}!</h2><p>Your Xuxu account has been successfully created! 🚀</p><div style="background:#f8f9fa;padding:15px;border-radius:5px;margin:20px 0"><strong>Your Account Details:</strong><br>Email: ${data.userEmail}<br>Password: ${data.password}</div><p>Click the button below to confirm your email and activate your account:</p><a href="${confirmationLink}" class="button">Confirm Email Address</a><p><strong>What's next?</strong></p><ul><li>Join or create savings groups</li><li>Set your financial goals</li><li>Track your contributions</li><li>Connect with like-minded savers</li></ul></div><div class="footer"><p>© 2024 Xuxu - Group Savings Platform</p><p>This email was sent to ${data.userEmail}</p></div></div></body></html>`;
  }

  private generateTextContent(data: EmailData, confirmationLink: string): string {
    return `Welcome to Xuxu - Group Savings Platform!

Hello ${data.firstName} ${data.lastName},

Your Xuxu account has been successfully created!

Your Account Details:
Email: ${data.userEmail}
Password: ${data.password}

To complete your registration, please visit:
${confirmationLink}

What's next?
- Join or create savings groups
- Set your financial goals
- Track your contributions
- Connect with like-minded savers

Thank you for choosing Xuxu!

© 2024 Xuxu - Group Savings Platform`;
  }

  // Health check for email service
  async healthCheck(): Promise<boolean> {
    try {
      await this.transporter.verify();
      return true;
    } catch (error) {
      console.error('Email service health check failed:', error);
      return false;
    }
  }
}

export const turboEmailService = new TurboEmailService();