// Comprehensive authentic Middle East location data
// This contains real countries, states/provinces, and major cities across the Middle East

export const middleEastLocationData = {
  countries: [
    {
      name: "United Arab Emirates",
      code: "AE",
      states: [
        {
          name: "Dubai",
          code: "DU",
          cities: ["Dubai", "Deira", "Bur Dubai", "Jumeirah", "Dubai Marina", "Downtown Dubai", "Business Bay", "Al Barsha", "Karama", "Satwa"]
        },
        {
          name: "Abu Dhabi",
          code: "AZ",
          cities: ["Abu Dhabi", "Al Ain", "Zayed City", "Khalifa City", "Ruwais", "Liwa", "Madinat Zayed", "Ghayathi", "Mirfa", "Sila"]
        },
        {
          name: "Sharjah",
          code: "SH",
          cities: ["Sharjah", "Khor Fakkan", "Kalba", "Dibba Al-Hisn", "Mleiha", "Al Dhaid", "Al Madam", "Al Hamriyah", "Muwailih", "Al Qasimia"]
        },
        {
          name: "Ajman",
          code: "AJ",
          cities: ["Ajman", "Masfout", "Manama", "Al Jurf", "Al Rawda", "Al Rashidiya", "Al Tallah", "Al Hamidiyah", "Al Bustan", "Al Jerf"]
        },
        {
          name: "Ras Al Khaimah",
          code: "RK",
          cities: ["Ras Al Khaimah", "Digdaga", "Al Jazirah Al Hamra", "Al Rams", "Dhayah", "Ghalilah", "Khatt", "Masafi", "Shaam", "Wadi Bih"]
        },
        {
          name: "Fujairah",
          code: "FU",
          cities: ["Fujairah", "Dibba Al-Fujairah", "Kalba", "Khor Fakkan", "Al Bidyah", "Al Fujairah", "Al Hayl", "Al Siji", "Masafi", "Qidfa"]
        },
        {
          name: "Umm Al Quwain",
          code: "UQ",
          cities: ["Umm Al Quwain", "Al Dur", "Al Ramlah", "Falaj Al Mualla", "Umm Al Quwain Marina", "Al Salam City", "Al Humra", "Al Khor", "Al Maydaq", "Al Seneyah"]
        }
      ]
    },
    {
      name: "Saudi Arabia",
      code: "SA",
      states: [
        {
          name: "Riyadh Province",
          code: "01",
          cities: ["Riyadh", "King Khalid International Airport", "Olaya", "Al Malaz", "Diplomatic Quarter", "King Fahd District", "Al Nakheel", "Al Wurud", "Hittin", "Al Andalus"]
        },
        {
          name: "Makkah Province",
          code: "02",
          cities: ["Mecca", "Jeddah", "Medina", "Taif", "Yanbu", "Rabigh", "Al Jumum", "Khulais", "Bahra", "Thuwal"]
        },
        {
          name: "Eastern Province",
          code: "04",
          cities: ["Dammam", "Dhahran", "Khobar", "Jubail", "Hofuf", "Qatif", "Ras Tanura", "Safwa", "Saihat", "Tarout"]
        },
        {
          name: "Asir Province",
          code: "14",
          cities: ["Abha", "Khamis Mushait", "Najran", "Bisha", "Muhayil", "Sarat Abidah", "Ahad Rafidah", "Tanomah", "Namas", "Bareq"]
        },
        {
          name: "Tabuk Province",
          code: "07",
          cities: ["Tabuk", "Duba", "Al Wajh", "Tayma", "Haql", "Al Bad", "Umluj", "Sharma", "Bir Ibn Hirmas", "Dhuba"]
        },
        {
          name: "Northern Borders Province",
          code: "08",
          cities: ["Arar", "Turaif", "Rafha", "Al Uwayqilah", "Hazm Al Jalamid", "Jumah", "Badr", "Al Suwair", "Umm Qasr", "Linah"]
        },
        {
          name: "Jazan Province",
          code: "09",
          cities: ["Jazan", "Sabya", "Abu Arish", "Samtah", "Ahad Al Masarihah", "Baish", "Fifa", "Al Dair", "Harub", "Al Khafji"]
        },
        {
          name: "Al Madinah Province",
          code: "03",
          cities: ["Medina", "Yanbu", "Al Ula", "Khaybar", "Badr", "Mahd Al Dhahab", "Al Hanakiyah", "Wadi Al Fara", "Al Suwarqiyah", "Tayma"]
        },
        {
          name: "Al Qassim Province",
          code: "05",
          cities: ["Buraydah", "Unayzah", "Ar Rass", "Al Mithnab", "Al Bukayriyah", "Badai", "Riyadh Al Khabra", "Uyun Al Jiwa", "Dhariyah", "Al Shammasiyah"]
        },
        {
          name: "Hail Province",
          code: "06",
          cities: ["Hail", "Baqaa", "Al Ghazalah", "Ash Shinan", "As Sulaymi", "Al Kahfah", "Umm Al Qulban", "Ash Shamli", "Samira", "Mawqaq"]
        },
        {
          name: "Al Bahah Province",
          code: "11",
          cities: ["Al Bahah", "Baljurashi", "Al Mandaq", "Al Mikhwah", "Al Aqiq", "Qilwah", "Al Hajrah", "Sabt Al Alayah", "Bani Hassan", "Ghamed Al Zinad"]
        },
        {
          name: "Al Jawf Province",
          code: "12",
          cities: ["Sakaka", "Qurayyat", "Tabarjal", "Suwayr", "Al Hazm", "Manwah", "Zallum", "Al Qaar", "Ithra", "Al Isawiyah"]
        }
      ]
    },
    {
      name: "Qatar",
      code: "QA",
      states: [
        {
          name: "Doha Municipality",
          code: "DA",
          cities: ["Doha", "West Bay", "The Pearl", "Lusail", "Al Sadd", "Katara", "Souq Waqif", "Corniche", "Education City", "Msheireb"]
        },
        {
          name: "Al Rayyan Municipality",
          code: "RA", 
          cities: ["Al Rayyan", "Al Gharafa", "Al Aziziyah", "Abu Hamour", "Al Waab", "Al Thumama", "Umm Al Afaei", "Al Sailiya", "Al Shagub", "Rawdat Al Hamama"]
        },
        {
          name: "Al Wakrah Municipality",
          code: "WA",
          cities: ["Al Wakrah", "Mesaieed", "Al Wukair", "Al Kharaitiyat", "Um Al Hawta", "Al Egla", "Jeryan Jenaihat", "Al Mashaf", "Sealine Beach", "Al Kharrara"]
        },
        {
          name: "Al Khor Municipality", 
          code: "KH",
          cities: ["Al Khor", "Al Thakhira", "Al Kheesa", "Simaisma", "Ras Laffan", "Al Ghuwariyah", "Al Jumaliyah", "Purple Island", "Al Dhaayen", "Fuwayrit"]
        },
        {
          name: "Al Shamal Municipality",
          code: "MS",
          cities: ["Madinat ash Shamal", "Al Ruwais", "Ash Shamal", "Fuwairit", "Ras Rakan", "Al Ghuwariyah", "Zubara", "Umm Qarn", "Ain Mohammed", "Al Arish"]
        },
        {
          name: "Al Daayen Municipality",
          code: "DA",
          cities: ["Lusail", "Al Kheesa", "Al Egla", "Umm Salal Mohammed", "Umm Salal Ali", "Al Kharaitiyat", "Jeryan Jenaihat", "Al Mashaf", "Simaisma", "Al Thakhira"]
        },
        {
          name: "Umm Salal Municipality",
          code: "US",
          cities: ["Umm Salal Mohammed", "Umm Salal Ali", "Al Kheesa", "Al Thumama", "Al Kharaitiyat", "Jeryan Jenaihat", "Al Egla", "Al Mashaf", "Izghawa", "Al Khibriya"]
        },
        {
          name: "Al Shahaniya Municipality",
          code: "SH",
          cities: ["Al Shahaniya", "Dukhan", "Al Jumayliyah", "Zekreet", "Al Kharrara", "Rawdat Rashed", "Al Nasraniya", "Al Utouriya", "Salwa", "Al Arish"]
        }
      ]
    },
    {
      name: "Palestine",
      code: "PS",
      states: [
        {
          name: "West Bank",
          code: "WB",
          cities: ["Ramallah", "Bethlehem", "Hebron", "Nablus", "Jenin", "Tulkarm", "Qalqilya", "Salfit", "Tubas", "Jericho"]
        },
        {
          name: "Gaza Strip", 
          code: "GZ",
          cities: ["Gaza", "Khan Yunis", "Rafah", "Deir al-Balah", "Jabalia", "Beit Lahia", "Beit Hanoun", "Al-Maghazi", "Al-Bureij", "Al-Nuseirat"]
        },
        {
          name: "Jerusalem",
          code: "JE", 
          cities: ["East Jerusalem", "Old City", "Sheikh Jarrah", "Silwan", "At-Tur", "Wadi al-Joz", "Ras al-Amud", "Sur Baher", "Jabal al-Mukaber", "Beit Hanina"]
        }
      ]
    },
    {
      name: "Syria",
      code: "SY",
      states: [
        {
          name: "Damascus Governorate",
          code: "DI",
          cities: ["Damascus", "Douma", "Harasta", "Daraya", "Qudsaya", "Jaramana", "Saqba", "Kafr Batna", "Arbin", "Zamalka"]
        },
        {
          name: "Aleppo Governorate",
          code: "HL",
          cities: ["Aleppo", "Azaz", "Al-Bab", "Afrin", "Jarablus", "Manbij", "Marea", "Jindires", "Tell Rifaat", "Atarib"]
        },
        {
          name: "Homs Governorate", 
          code: "HO",
          cities: ["Homs", "Palmyra", "Qusayr", "Rastan", "Talkalakh", "Al-Mukharram", "Tadmur", "Furqlus", "Shin", "Hawsh Hammad"]
        },
        {
          name: "Hama Governorate",
          code: "HA",
          cities: ["Hama", "Salamiyah", "Suqaylabiyah", "Mahardah", "Masyaf", "Kafr Zita", "Morek", "Halfaya", "Taybat al-Imam", "Karnaz"]
        },
        {
          name: "Latakia Governorate",
          code: "LA", 
          cities: ["Latakia", "Jableh", "Qardaha", "Al-Haffa", "Kasab", "Ain al-Bayda", "Ras al-Bassit", "Burj Islam", "Dweir Ruslan", "Mushta al-Helou"]
        },
        {
          name: "Idlib Governorate",
          code: "ID",
          cities: ["Idlib", "Jisr al-Shughur", "Ariha", "Maarat al-Numan", "Salqin", "Darkush", "Harim", "Kafr Takharim", "Saraqib", "Binnish"]
        },
        {
          name: "Tartus Governorate",
          code: "TA",
          cities: ["Tartus", "Banias", "Safita", "Dreikish", "Al-Shaykh Badr", "Arwad", "Mashta al-Helou", "Qadmus", "Khawabi", "Hammam Wasel"]
        },
        {
          name: "Daraa Governorate",
          code: "DR",
          cities: ["Daraa", "Izra", "Jasim", "Nawa", "Sanamein", "Al-Harrak", "Bosra", "Inkhil", "Al-Msifra", "Tafas"]
        },
        {
          name: "As-Suwayda Governorate",
          code: "SW",
          cities: ["As-Suwayda", "Shahba", "Salkhad", "Qanawat", "Shaqqa", "Malah", "Ariqah", "Bakka", "Hibbariyah", "Imtan"]
        },
        {
          name: "Quneitra Governorate",
          code: "QU",
          cities: ["Quneitra", "Khan Arnabah", "Fiq", "Al-Baath", "Madinat al-Baath", "Jubata al-Khashab", "Beer Ajam", "Hadar", "Ufania", "Kudna"]
        },
        {
          name: "Deir ez-Zor Governorate",
          code: "DY",
          cities: ["Deir ez-Zor", "Al-Mayadin", "Al-Bukamal", "Hajin", "Al-Ashara", "Khasham", "Mahkan", "Jadid Aqidat", "Sur", "Tabni"]
        },
        {
          name: "Ar-Raqqah Governorate", 
          code: "RA",
          cities: ["Ar-Raqqah", "Tell Abiad", "Suluk", "Ain Issa", "Karama", "Maadan", "Tabqa", "Al-Thawrah", "Kasra", "Jurneyyeh"]
        },
        {
          name: "Al-Hasakah Governorate",
          code: "HA",
          cities: ["Al-Hasakah", "Qamishli", "Ras al-Ain", "Al-Malikiyah", "Amuda", "Darbasiyah", "Al-Qahtaniyah", "Al-Muabbada", "Al-Arisha", "Jawadiyah"]
        },
        {
          name: "Rif Dimashq Governorate",
          code: "RD", 
          cities: ["Douma", "Zabadani", "Qatana", "An-Nabk", "Yabroud", "Rankous", "Madaya", "Bloudan", "Serghaya", "Maaloula"]
        }
      ]
    },
    {
      name: "Turkey",
      code: "TR",
      states: [
        {
          name: "Istanbul Province",
          code: "34",
          cities: ["Istanbul", "Beyoglu", "Kadikoy", "Besiktas", "Sisli", "Uskudar", "Fatih", "Bakirkoy", "Zeytinburnu", "Gaziosmanpasa"]
        },
        {
          name: "Ankara Province",
          code: "06",
          cities: ["Ankara", "Cankaya", "Kecioren", "Yenimahalle", "Mamak", "Etimesgut", "Sincan", "Pursaklar", "Altindag", "Golbasi"]
        },
        {
          name: "Izmir Province",
          code: "35", 
          cities: ["Izmir", "Bornova", "Konak", "Karsiyaka", "Buca", "Gaziemir", "Balcova", "Cigli", "Bayrakli", "Narlidere"]
        },
        {
          name: "Bursa Province",
          code: "16",
          cities: ["Bursa", "Osmangazi", "Nilufer", "Yildirim", "Gursu", "Kestel", "Mudanya", "Gemlik", "Inegol", "Orhaneli"]
        },
        {
          name: "Antalya Province",
          code: "07",
          cities: ["Antalya", "Alanya", "Manavgat", "Kas", "Side", "Kemer", "Kalkan", "Finike", "Demre", "Elmali"]
        },
        {
          name: "Adana Province",
          code: "01",
          cities: ["Adana", "Seyhan", "Yuregir", "Cukurova", "Sarıcam", "Tarsus", "Pozanti", "Kozan", "Ceyhan", "Karatas"]
        },
        {
          name: "Konya Province",
          code: "42",
          cities: ["Konya", "Selcuklu", "Meram", "Karatay", "Eregli", "Aksehir", "Beysehir", "Cihanbeyli", "Kulu", "Ilgin"]
        },
        {
          name: "Gaziantep Province",
          code: "27",
          cities: ["Gaziantep", "Sahinbey", "Sehitkamil", "Oguzeli", "Nizip", "Islahiye", "Karkamis", "Nurdagi", "Yavuzeli", "Araban"]
        },
        {
          name: "Kayseri Province",
          code: "38",
          cities: ["Kayseri", "Melikgazi", "Kocasinan", "Talas", "Develi", "Yahyali", "Pinarbasi", "Sarioglan", "Tomarza", "Akkisla"]
        },
        {
          name: "Mersin Province",
          code: "33",
          cities: ["Mersin", "Tarsus", "Silifke", "Erdemli", "Mut", "Anamur", "Bozyazi", "Camlidere", "Gulnar", "Mezitli"]
        }
      ]
    },
    {
      name: "Yemen",
      code: "YE",
      states: [
        {
          name: "Sana'a Governorate",
          code: "SA",
          cities: ["Sana'a", "Al Rawdah", "Az Zubayr", "Bani al Harith", "Nihm", "Sanhan", "Jihanah", "Hamdan", "Bani Dhabyan", "Bani Hushaysh"]
        },
        {
          name: "Aden Governorate",
          code: "AD", 
          cities: ["Aden", "Crater", "Mualla", "Tawahi", "Khormaksar", "Dar Sad", "Al Buraiqa", "Ash Sheikh Uthman", "Al Mansoura", "Sirah"]
        },
        {
          name: "Taiz Governorate",
          code: "TA",
          cities: ["Taiz", "Turbah", "Al Mawasit", "Sabir al Mawadim", "Salh", "Dimnat Khadir", "Al Wazi'iyah", "Hayfan", "Maqbanah", "Jabal Habashy"]
        },
        {
          name: "Hodeidah Governorate",
          code: "HU",
          cities: ["Hodeidah", "Bajil", "Zabid", "Al Luhayyah", "Az Zaydiyah", "Bayt al Faqih", "Al Jarahi", "Al Mansuriyah", "Ad Durayhimi", "Hays"]
        },
        {
          name: "Ibb Governorate",
          code: "IB",
          cities: ["Ibb", "Yarim", "Jiblah", "Ba'dan", "Far' al Udayn", "Al Udayn", "Hubaysh", "Al Mashannah", "As Sayyani", "Dhi as Sufal"]
        },
        {
          name: "Dhamar Governorate",
          code: "DH",
          cities: ["Dhamar", "Radaa", "Utmah", "Jahran", "Mabar", "Al Hada", "Wusab as Safil", "Mayfa'ah Anss", "Ans", "Dhamar City"]
        },
        {
          name: "Hadramout Governorate",
          code: "HD",
          cities: ["Mukalla", "Say'un", "Shibam", "Tarim", "Al Qatn", "Thamud", "Doan", "Yabuth", "Al Abr", "Qusay'ir"]
        },
        {
          name: "Shabwah Governorate",
          code: "SH",
          cities: ["Ataq", "Bayhan", "Marib", "Usaylan", "Arma", "Habban", "Mayfa'a", "Rudum", "Ain", "Jardan"]
        },
        {
          name: "Sa'ada Governorate",
          code: "SD",
          cities: ["Sa'ada", "Haydan", "Razih", "Al Safra", "Kitaf wa al Boqe'e", "Sahar", "Ghamr", "Majz", "Saqayn", "Baqim"]
        },
        {
          name: "Marib Governorate",
          code: "MA",
          cities: ["Marib", "Sirwah", "Rahabah", "Harib", "Mahliyah", "Jubah", "Bidbadah", "Raghwan", "Majzar", "Marib al Wadi"]
        }
      ]
    },
    {
      name: "Kuwait",
      code: "KW",
      states: [
        {
          name: "Al Asimah",
          code: "KU",
          cities: ["Kuwait City", "Salmiya", "Hawalli", "Farwaniya", "Jahra", "Ahmadi", "Fahaheel", "Mangaf", "Fintas", "Mahboula"]
        },
        {
          name: "Hawalli",
          code: "HA",
          cities: ["Hawalli", "Salmiya", "Rumaithiya", "Bayan", "Mishref", "Salwa", "Jabriya", "Surra", "Shaab", "Maidan Hawalli"]
        }
      ]
    },
    {
      name: "Bahrain",
      code: "BH",
      states: [
        {
          name: "Capital Governorate",
          code: "13",
          cities: ["Manama", "Muharraq", "Riffa", "Hamad Town", "Isa Town", "Sitra", "Jidhafs", "Budaiya", "Zallaq", "Tubli"]
        },
        {
          name: "Muharraq Governorate",
          code: "15",
          cities: ["Muharraq", "Hidd", "Arad", "Dair", "Galali", "Samaheej", "Busaiteen", "Halat Bu Maher", "Qalali", "Halat Seltah"]
        }
      ]
    },
    {
      name: "Oman",
      code: "OM",
      states: [
        {
          name: "Muscat Governorate",
          code: "MA",
          cities: ["Muscat", "Seeb", "Mutrah", "Bawshar", "Al Amerat", "Quriyat", "Ruwi", "Shatti Al Qurum", "Al Khuwair", "Al Ghubra"]
        },
        {
          name: "Dhofar Governorate",
          code: "ZU",
          cities: ["Salalah", "Mirbat", "Taqah", "Sadah", "Raysut", "Thumrait", "Masirah", "Duqm", "Haima", "Mahout"]
        },
        {
          name: "Al Batinah North Governorate",
          code: "BS",
          cities: ["Sohar", "Shinas", "Liwa", "Saham", "Al Khaburah", "As Suwiq", "Nakhal", "Wadi Al Maawil", "Al Awabi", "Ar Rustaq"]
        }
      ]
    },
    {
      name: "Jordan",
      code: "JO",
      states: [
        {
          name: "Amman Governorate",
          code: "AM",
          cities: ["Amman", "Zarqa", "Russeifa", "Qweismeh", "Wadi As-Seir", "Tilal Ali", "Marj Al Hamam", "Naour", "Muqabalain", "Um Qsair"]
        },
        {
          name: "Irbid Governorate",
          code: "IR",
          cities: ["Irbid", "Ramtha", "Ajloun", "Mafraq", "Bani Kinanah", "Koura", "Jerash", "Taybeh", "Al Sarih", "Sama Al Rousan"]
        },
        {
          name: "Zarqa Governorate",
          code: "AZ",
          cities: ["Zarqa", "Russeifa", "Hashemite University", "Dulayl", "Azraq", "Hallabat", "Dhuleil", "Mafraq", "Safawi", "Al Ruwaished"]
        }
      ]
    },
    {
      name: "Lebanon",
      code: "LB",
      states: [
        {
          name: "Beirut Governorate",
          code: "BA",
          cities: ["Beirut", "Ras Beirut", "Achrafieh", "Hamra", "Verdun", "Ain Mreisseh", "Mazraa", "Mousseitbeh", "Saifi", "Medawar"]
        },
        {
          name: "Mount Lebanon Governorate",
          code: "JL",
          cities: ["Jounieh", "Byblos", "Baabda", "Aley", "Metn", "Keserwan", "Chouf", "Bikfaya", "Broummana", "Antelias"]
        },
        {
          name: "North Governorate",
          code: "AS",
          cities: ["Tripoli", "Zgharta", "Batroun", "Bsharri", "Koura", "Miniyeh-Danniyeh", "Akkar", "Halba", "Qoubaiyat", "Chekka"]
        }
      ]
    },
    {
      name: "Iraq",
      code: "IQ",
      states: [
        {
          name: "Baghdad Governorate",
          code: "BG",
          cities: ["Baghdad", "Sadr City", "Kadhimiya", "Adhamiyah", "Karrada", "Mansour", "Rusafa", "Karkh", "New Baghdad", "Huriya"]
        },
        {
          name: "Basra Governorate",
          code: "BA",
          cities: ["Basra", "Az Zubayr", "Abu Al Khaseeb", "Al Qurna", "Al Midaina", "Shatt Al Arab", "Al Faw", "Tanuma", "Safwan", "Umm Qasr"]
        },
        {
          name: "Erbil Governorate",
          code: "AR",
          cities: ["Erbil", "Shaqlawa", "Koya", "Makhmur", "Mergasur", "Soran", "Choman", "Rawanduz", "Rania", "Salahuddin"]
        }
      ]
    },
    {
      name: "Iran",
      code: "IR",
      states: [
        {
          name: "Tehran Province",
          code: "23",
          cities: ["Tehran", "Karaj", "Eslamshahr", "Ray", "Varamin", "Shahriar", "Robat Karim", "Baharestan", "Malard", "Nazarabad"]
        },
        {
          name: "Isfahan Province",
          code: "10",
          cities: ["Isfahan", "Kashan", "Khomeini Shahr", "Najafabad", "Shahin Shahr", "Mobarakeh", "Falavarjan", "Lenjan", "Borkhar", "Ardestan"]
        },
        {
          name: "Fars Province",
          code: "14",
          cities: ["Shiraz", "Marvdasht", "Jahrom", "Firouzabad", "Larestan", "Neyriz", "Estahban", "Fasa", "Darab", "Lamerd"]
        }
      ]
    },
    {
      name: "Turkey",
      code: "TR",
      states: [
        {
          name: "Istanbul Province",
          code: "34",
          cities: ["Istanbul", "Beyoğlu", "Fatih", "Beşiktaş", "Kadıköy", "Üsküdar", "Şişli", "Bakırköy", "Zeytinburnu", "Pendik"]
        },
        {
          name: "Ankara Province",
          code: "06",
          cities: ["Ankara", "Çankaya", "Keçiören", "Yenimahalle", "Mamak", "Sincan", "Etimesgut", "Gölbaşı", "Pursaklar", "Altındağ"]
        },
        {
          name: "Izmir Province",
          code: "35",
          cities: ["Izmir", "Konak", "Bornova", "Buca", "Karşıyaka", "Bayraklı", "Gaziemir", "Balçova", "Çiğli", "Güzelbahçe"]
        }
      ]
    },
    {
      name: "Israel",
      code: "IL",
      states: [
        {
          name: "Jerusalem District",
          code: "JM",
          cities: ["Jerusalem", "Bethlehem", "Beit Shemesh", "Maale Adumim", "Modi'in-Maccabim-Re'ut", "Gush Etzion", "Abu Ghosh", "Ein Karem", "Mevaseret Zion", "Har Adar"]
        },
        {
          name: "Tel Aviv District",
          code: "TA",
          cities: ["Tel Aviv", "Ramat Gan", "Petah Tikva", "Holon", "Bnei Brak", "Bat Yam", "Givatayim", "Herzliya", "Kfar Saba", "Ra'anana"]
        },
        {
          name: "Central District",
          code: "M",
          cities: ["Rishon LeZion", "Ashdod", "Rehovot", "Lod", "Ramla", "Modi'in", "Shoham", "Kiryat Malakhi", "Gedera", "Yavne"]
        }
      ]
    },
    {
      name: "Syria",
      code: "SY",
      states: [
        {
          name: "Damascus Governorate",
          code: "DI",
          cities: ["Damascus", "Jaramana", "Sahnaya", "Harasta", "Douma", "Daraya", "Qatana", "Zabadani", "Madaya", "Bludan"]
        },
        {
          name: "Aleppo Governorate",
          code: "HL",
          cities: ["Aleppo", "Manbij", "Afrin", "Azaz", "Al-Bab", "Jarablus", "Marea", "Tell Rifaat", "Jindires", "Rajo"]
        },
        {
          name: "Homs Governorate",
          code: "HM",
          cities: ["Homs", "Palmyra", "Talkalakh", "Al-Qusayr", "Tadmur", "Maheen", "Sadad", "Fairouzeh", "Taldou", "Houla"]
        }
      ]
    },
    {
      name: "Yemen",
      code: "YE",
      states: [
        {
          name: "Sana'a Governorate",
          code: "SN",
          cities: ["Sana'a", "Al Safia", "Arhab", "Bani Matar", "Hamdan", "Jihanah", "Khawlan", "Manakhah", "Nihm", "Sanhan"]
        },
        {
          name: "Aden Governorate",
          code: "AD",
          cities: ["Aden", "Crater", "Khormaksar", "Mualla", "Sheikh Othman", "Mansoura", "Dar Saad", "Al Bureiqa", "Sirah", "Tawahi"]
        },
        {
          name: "Taiz Governorate",
          code: "TA",
          cities: ["Taiz", "Turbah", "Haifan", "Maqbanah", "Mawza", "Mashra'a Wa Hadnan", "Al Misrakh", "Jabal Habashy", "Sama", "Dimnat Khadir"]
        }
      ]
    },
    {
      name: "Cyprus",
      code: "CY",
      states: [
        {
          name: "Nicosia District",
          code: "04",
          cities: ["Nicosia", "Lakatamia", "Strovolos", "Aglandjia", "Engomi", "Kaimakli", "Pallouriotissa", "Anthoupolis", "Latsia", "Geri"]
        },
        {
          name: "Limassol District",
          code: "05",
          cities: ["Limassol", "Germasogeia", "Agios Athanasios", "Mesa Geitonia", "Zakaki", "Polemidia", "Kolossi", "Erimi", "Episkopi", "Paramytha"]
        },
        {
          name: "Larnaca District",
          code: "06",
          cities: ["Larnaca", "Aradippou", "Livadia", "Dromolaxia", "Meneou", "Kiti", "Pervolia", "Kellia", "Tersefanou", "Anglisides"]
        }
      ]
    }
  ]
};