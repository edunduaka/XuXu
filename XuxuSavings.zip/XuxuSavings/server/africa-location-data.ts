// Comprehensive authentic Africa location data
// This contains real countries, states/provinces, and major cities across Africa

export const africaLocationData = {
  countries: [
    {
      name: "Nigeria",
      code: "NG",
      states: [
        {
          name: "Abia",
          code: "AB",
          cities: ["Umuahia", "Aba", "Ohafia", "Arochukwu", "Bende", "Uzuakoli", "Isuikwuato", "Umunneochi", "Ukwa", "Ikwuano"]
        },
        {
          name: "Adamawa",
          code: "AD",
          cities: ["Yola", "Mubi", "Jimeta", "Ganye", "Numan", "Mayo-Belwa", "Gombi", "Hong", "Madagali", "Shelleng"]
        },
        {
          name: "Akwa Ibom",
          code: "AK",
          cities: ["Uyo", "Eket", "Ikot Ekpene", "Oron", "Abak", "Ikot Abasi", "Etinan", "Ibiono-Ibom", "Mkpat-Enin", "Eastern Obolo"]
        },
        {
          name: "Anambra",
          code: "AN",
          cities: ["Awka", "Onitsha", "Nnewi", "Ekwulobia", "Aguata", "Ihiala", "Ogidi", "Abagana", "Umunze", "Ozubulu"]
        },
        {
          name: "Bauchi",
          code: "BA",
          cities: ["Bauchi", "Azare", "Misau", "Jama'are", "Katagum", "Dass", "Tafawa Balewa", "Itas", "Toro", "Alkaleri"]
        },
        {
          name: "Bayelsa",
          code: "BY",
          cities: ["Yenagoa", "Brass", "Nembe", "Ogbia", "Sagbama", "Southern Ijaw", "Ekeremor", "Kolokuma/Opokuma", "Brass Island", "Akassa"]
        },
        {
          name: "Benue",
          code: "BE",
          cities: ["Makurdi", "Otukpo", "Gboko", "Vandeikya", "Katsina-Ala", "Zaki Biam", "Oju", "Agatu", "Ushongo", "Ukum"]
        },
        {
          name: "Borno",
          code: "BO",
          cities: ["Maiduguri", "Bama", "Biu", "Dikwa", "Gwoza", "Kukawa", "Monguno", "Damboa", "Gubio", "Konduga"]
        },
        {
          name: "Cross River",
          code: "CR",
          cities: ["Calabar", "Ikom", "Ogoja", "Obudu", "Akamkpa", "Ugep", "Obubra", "Okuni", "Akpabuyo", "Odukpani"]
        },
        {
          name: "Delta",
          code: "DE",
          cities: ["Asaba", "Warri", "Sapele", "Ughelli", "Agbor", "Burutu", "Oleh", "Ozoro", "Issele-Uku", "Kwale"]
        },
        {
          name: "Ebonyi",
          code: "EB",
          cities: ["Abakaliki", "Afikpo", "Onueke", "Ishiagu", "Uburu", "Ezza", "Onicha", "Ohaukwu", "Ivo", "Ikwo"]
        },
        {
          name: "Edo",
          code: "ED",
          cities: ["Benin City", "Auchi", "Ekpoma", "Uromi", "Sabongida-Ora", "Igarra", "Irrua", "Fugar", "Abudu", "Ubiaja"]
        },
        {
          name: "Ekiti",
          code: "EK",
          cities: ["Ado Ekiti", "Ikere", "Ikole", "Ijero", "Oye", "Ido", "Emure", "Efon", "Ilawe", "Ise/Orun"]
        },
        {
          name: "Enugu",
          code: "EN",
          cities: ["Enugu", "Nsukka", "Oji River", "Awgu", "Udi", "Agbani", "Awka", "Nike", "Ninth Mile Corner", "Uwani"]
        },
        {
          name: "Abuja Federal Capital Territory",
          code: "FC",
          cities: ["Abuja", "Garki", "Wuse", "Maitama", "Asokoro", "Gwarinpa", "Kubwa", "Nyanya", "Karu", "Gwagwalada"]
        },
        {
          name: "Gombe",
          code: "GO",
          cities: ["Gombe", "Billiri", "Kaltungo", "Bajoga", "Kumo", "Dukku", "Nafada", "Akko", "Funakaye", "Shongom"]
        },
        {
          name: "Imo",
          code: "IM",
          cities: ["Owerri", "Okigwe", "Orlu", "Mbaise", "Mbano", "Mbieri", "Oguta", "Nkwerre", "Ohaji/Egbema", "Aboh Mbaise"]
        },
        {
          name: "Jigawa",
          code: "JI",
          cities: ["Dutse", "Hadejia", "Birnin Kudu", "Gumel", "Kazaure", "Ringim", "Babura", "Kafin Hausa", "Kiyawa", "Auyo"]
        },
        {
          name: "Kaduna",
          code: "KD",
          cities: ["Kaduna", "Zaria", "Kafanchan", "Kagoro", "Birnin Gwari", "Makarfi", "Sabon Gari", "Ikara", "Kachia", "Kauru"]
        },
        {
          name: "Kano",
          code: "KN",
          cities: ["Kano", "Fagge", "Dala", "Gwale", "Tarauni", "Nassarawa", "Ungogo", "Kumbotso", "Warawa", "Kiru"]
        },
        {
          name: "Katsina",
          code: "KT",
          cities: ["Katsina", "Funtua", "Daura", "Malumfashi", "Dutsin-Ma", "Kankia", "Mani", "Mashi", "Bakori", "Jibia"]
        },
        {
          name: "Kebbi",
          code: "KE",
          cities: ["Birnin Kebbi", "Argungu", "Yauri", "Zuru", "Jega", "Koko", "Dandi", "Kalgo", "Bunza", "Bagudo"]
        },
        {
          name: "Kogi",
          code: "KO",
          cities: ["Lokoja", "Okene", "Kabba", "Idah", "Ankpa", "Dekina", "Ajaokuta", "Ogori", "Koton Karfe", "Ejule"]
        },
        {
          name: "Kwara",
          code: "KW",
          cities: ["Ilorin", "Offa", "Pategi", "Kaiama", "Omu-Aran", "Jebba", "Lafiagi", "Erin-Ile", "Erinle", "Ajasse-Ipo"]
        },
        {
          name: "Lagos",
          code: "LA",
          cities: ["Lagos", "Ikeja", "Surulere", "Victoria Island", "Ikoyi", "Apapa", "Mushin", "Alimosho", "Agege", "Ifako-Ijaiye"]
        },
        {
          name: "Nasarawa",
          code: "NA",
          cities: ["Lafia", "Keffi", "Akwanga", "Nasarawa", "Wamba", "Keana", "Doma", "Awe", "Toto", "Kokona"]
        },
        {
          name: "Niger",
          code: "NI",
          cities: ["Minna", "Bida", "Kontagora", "Suleja", "Mokwa", "Agaie", "Lapai", "Rijau", "Wushishi", "Kagara"]
        },
        {
          name: "Ogun",
          code: "OG",
          cities: ["Abeokuta", "Sagamu", "Ijebu Ode", "Ilaro", "Ago-Iwoye", "Ota", "Ifo", "Iperu", "Ado-Odo", "Owode"]
        },
        {
          name: "Ondo",
          code: "ON",
          cities: ["Akure", "Ondo", "Owo", "Ikare", "Ilaje", "Okitipupa", "Idanre", "Ore", "Ile-Oluji", "Igbokoda"]
        },
        {
          name: "Osun",
          code: "OS",
          cities: ["Osogbo", "Ile-Ife", "Ilesa", "Ede", "Iwo", "Ejigbo", "Ikire", "Ikirun", "Ila Orangun", "Ijebu-Jesa"]
        },
        {
          name: "Oyo",
          code: "OY",
          cities: ["Ibadan", "Ogbomoso", "Oyo", "Iseyin", "Iwo", "Shaki", "Igboho", "Eruwa", "Lalupon", "Kishi"]
        },
        {
          name: "Plateau",
          code: "PL",
          cities: ["Jos", "Bukuru", "Pankshin", "Shendam", "Langtang", "Barkin Ladi", "Mangu", "Bassa", "Bokkos", "Riyom"]
        },
        {
          name: "Rivers",
          code: "RI",
          cities: ["Port Harcourt", "Obio-Akpor", "Okrika", "Oyigbo", "Ogu–Bolo", "Eleme", "Tai", "Gokana", "Khana", "Degema"]
        },
        {
          name: "Sokoto",
          code: "SO",
          cities: ["Sokoto", "Tambuwal", "Gwadabawa", "Illela", "Wurno", "Rabah", "Binji", "Goronyo", "Silame", "Kebbe"]
        },
        {
          name: "Taraba",
          code: "TA",
          cities: ["Jalingo", "Wukari", "Bali", "Ibi", "Takum", "Donga", "Zing", "Lau", "Yorro", "Ardo Kola"]
        },
        {
          name: "Yobe",
          code: "YO",
          cities: ["Damaturu", "Potiskum", "Gashua", "Nguru", "Geidam", "Buni Yadi", "Nangere", "Yusufari", "Jakusko", "Karasuwa"]
        },
        {
          name: "Zamfara",
          code: "ZA",
          cities: ["Gusau", "Kaura Namoda", "Anka", "Talata Mafara", "Maru", "Bungudu", "Tsafe", "Gummi", "Bukkuyum", "Bakura"]
        }
      ]
    },
    {
      name: "South Africa",
      code: "ZA",
      states: [
        {
          name: "Gauteng",
          code: "GT",
          cities: ["Johannesburg", "Pretoria", "Soweto", "Ekurhuleni", "Benoni", "Boksburg", "Germiston", "Kempton Park", "Brakpan", "Springs"]
        },
        {
          name: "Western Cape",
          code: "WC",
          cities: ["Cape Town", "Stellenbosch", "Paarl", "George", "Worcester", "Mossel Bay", "Hermanus", "Swellendam", "Oudtshoorn", "Caledon"]
        },
        {
          name: "KwaZulu-Natal",
          code: "KZN",
          cities: ["Durban", "Pietermaritzburg", "Newcastle", "Pinetown", "Chatsworth", "Umlazi", "Port Shepstone", "Ladysmith", "Dundee", "Estcourt"]
        }
      ]
    },
    {
      name: "Kenya",
      code: "KE",
      states: [
        {
          name: "Nairobi",
          code: "30",
          cities: ["Nairobi", "Westlands", "Kasarani", "Embakasi", "Makadara", "Kamukunji", "Starehe", "Langata", "Dagoretti", "Kibra"]
        },
        {
          name: "Mombasa",
          code: "28",
          cities: ["Mombasa", "Likoni", "Changamwe", "Jomba", "Kisauni", "Nyali", "Bamburi", "Shanzu", "Mikindani", "Magongo"]
        },
        {
          name: "Central",
          code: "11",
          cities: ["Nyeri", "Thika", "Murang'a", "Kiambu", "Kirinyaga", "Nyandarua", "Gatundu", "Limuru", "Ruiru", "Kikuyu"]
        }
      ]
    },
    {
      name: "Ghana",
      code: "GH",
      states: [
        {
          name: "Greater Accra",
          code: "AA",
          cities: ["Accra", "Tema", "Madina", "Adenta", "Kasoa", "Teshie", "Nungua", "La", "Osu", "Dansoman"]
        },
        {
          name: "Ashanti",
          code: "AH",
          cities: ["Kumasi", "Obuasi", "Ejisu", "Bekwai", "Mampong", "Konongo", "Offinso", "Agogo", "Tepa", "Juaso"]
        },
        {
          name: "Western",
          code: "WP",
          cities: ["Sekondi-Takoradi", "Tarkwa", "Axim", "Prestea", "Elmina", "Cape Coast", "Winneba", "Dunkwa", "Bogoso", "Elubo"]
        }
      ]
    },
    {
      name: "Egypt",
      code: "EG",
      states: [
        {
          name: "Cairo",
          code: "C",
          cities: ["Cairo", "Giza", "Shubra El Kheima", "Port Said", "Suez", "Luxor", "al-Mahallah al-Kubra", "Mansoura", "Tanta", "Asyut"]
        },
        {
          name: "Alexandria",
          code: "ALX",
          cities: ["Alexandria", "Damanhur", "Kafr el-Dawwar", "Rashid", "Edku", "Abu Qir", "Idku", "Mahmudiyah", "Sidi Barrani", "Marsa Matruh"]
        },
        {
          name: "Giza",
          code: "GZ",
          cities: ["Giza", "6th of October City", "Sheikh Zayed City", "Badrashin", "Abu Rawash", "Kerdasa", "Ausim", "Saqqara", "Mit Rahina", "Al Badrashein"]
        }
      ]
    },
    {
      name: "Morocco",
      code: "MA",
      states: [
        {
          name: "Casablanca-Settat",
          code: "06",
          cities: ["Casablanca", "Settat", "Berrechid", "Benslimane", "Mohammedia", "El Jadida", "Azemmour", "Sidi Bennour", "Khouribga", "Oued Zem"]
        },
        {
          name: "Rabat-Salé-Kénitra",
          code: "04",
          cities: ["Rabat", "Salé", "Kénitra", "Khemisset", "Sidi Kacem", "Sidi Slimane", "Temara", "Skhirat", "Tiflet", "Rommani"]
        },
        {
          name: "Marrakesh-Safi",
          code: "07",
          cities: ["Marrakesh", "Safi", "Essaouira", "Kelaa des Sraghna", "Youssoufia", "Chichaoua", "Al Haouz", "Rehamna", "Tamanar", "Oulad Teima"]
        }
      ]
    },
    {
      name: "Ethiopia",
      code: "ET",
      states: [
        {
          name: "Addis Ababa",
          code: "AA",
          cities: ["Addis Ababa", "Gulele", "Arada", "Kirkos", "Lideta", "Nifas Silk-Lafto", "Kolfe Keranio", "Akaky Kaliti", "Bole", "Yeka"]
        },
        {
          name: "Oromia",
          code: "OR",
          cities: ["Adama", "Jimma", "Bishoftu", "Shashamane", "Nekemte", "Harar", "Dire Dawa", "Sebeta", "Mojo", "Ziway"]
        },
        {
          name: "Amhara",
          code: "AM",
          cities: ["Bahir Dar", "Gondar", "Dessie", "Debre Markos", "Kombolcha", "Debre Birhan", "Woldia", "Lalibela", "Finote Selam", "Weldiya"]
        }
      ]
    },
    {
      name: "Uganda",
      code: "UG",
      states: [
        {
          name: "Central Region",
          code: "C",
          cities: ["Kampala", "Entebbe", "Mukono", "Jinja", "Masaka", "Mbarara", "Wakiso", "Mpigi", "Luwero", "Rakai"]
        },
        {
          name: "Eastern Region",
          code: "E",
          cities: ["Jinja", "Mbale", "Soroti", "Tororo", "Busia", "Iganga", "Kamuli", "Pallisa", "Kumi", "Kapchorwa"]
        },
        {
          name: "Western Region",
          code: "W",
          cities: ["Mbarara", "Fort Portal", "Kasese", "Kabale", "Rukungiri", "Bushenyi", "Hoima", "Masindi", "Bundibugyo", "Kyenjojo"]
        }
      ]
    },
    {
      name: "Tanzania",
      code: "TZ",
      states: [
        {
          name: "Dar es Salaam",
          code: "02",
          cities: ["Dar es Salaam", "Kinondoni", "Ilala", "Temeke", "Ubungo", "Kigamboni"]
        },
        {
          name: "Mwanza",
          code: "18",
          cities: ["Mwanza", "Ilemela", "Nyamagana", "Sengerema", "Kwimba", "Misungwi", "Magu", "Buchosa", "Bunda", "Serengeti"]
        },
        {
          name: "Arusha",
          code: "01",
          cities: ["Arusha", "Moshi", "Karatu", "Monduli", "Ngorongoro", "Longido", "Siha", "Hai", "Rombo", "Same"]
        }
      ]
    },
    {
      name: "Algeria",
      code: "DZ",
      states: [
        {
          name: "Algiers",
          code: "16",
          cities: ["Algiers", "Bab El Oued", "Casbah", "Birtouta", "Zeralda", "Cheraga", "Dely Ibrahim", "El Achour", "Ouled Fayet", "Draria"]
        },
        {
          name: "Oran",
          code: "31",
          cities: ["Oran", "Es Senia", "Bir El Djir", "Hassi Bounif", "Sidi Chami", "Hassi Mefsoukh", "Bethioua", "Boufatis", "Gdyel", "Marsat El Hadjadj"]
        },
        {
          name: "Constantine",
          code: "25",
          cities: ["Constantine", "Ali Mendjeli", "Hamma Bouziane", "Didouche Mourad", "El Khroub", "Ain Abid", "Ouled Rahmoune", "Messaoud Boudjeriou", "Ibn Ziad", "Zighoud Youcef"]
        }
      ]
    }
  ]
};