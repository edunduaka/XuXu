// Free email service for sending authentication emails
// Uses Nodemailer with Gmail's free SMTP service

import nodemailer from 'nodemailer';
import { randomBytes } from 'crypto';

interface EmailData {
  userEmail: string;
  password: string;
  firstName: string;
  lastName: string;
}

export class EmailService {
  private transporter: any;
  
  constructor() {
    // Enhanced email configuration with better delivery
    this.transporter = nodemailer.createTransport({
      service: 'gmail',
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      connectionTimeout: 10000, // 10 seconds
      greetingTimeout: 5000, // 5 seconds
      socketTimeout: 15000, // 15 seconds
      auth: {
        user: process.env.EMAIL_USER || 'xuxuthrift@gmail.com',
        pass: process.env.EMAIL_PASS || 'xuxu2024'
      },
      tls: {
        rejectUnauthorized: false
      }
    });
  }

  generateConfirmationToken(): string {
    return randomBytes(32).toString('hex');
  }

  async sendRegistrationEmail(data: EmailData): Promise<boolean> {
    try {
      const confirmationToken = this.generateConfirmationToken();
      const baseUrl = 'https://9724f777-70bf-4e9c-8735-97bd6fa3745c.spock.prod.repl.run';
      const confirmationLink = `${baseUrl}/confirm-email?token=${confirmationToken}&email=${encodeURIComponent(data.userEmail)}`;
      
      // Add timeout wrapper to prevent hanging
      const emailPromise = this.sendEmailWithTimeout(data, confirmationLink, confirmationToken);
      return await emailPromise;
    } catch (error) {
      console.error('📧 Registration email error:', error);
      return false; // Return false but don't block registration
    }
  }

  private async sendEmailWithTimeout(data: EmailData, confirmationLink: string, confirmationToken: string): Promise<boolean> {
    return new Promise(async (resolve) => {
      // Set timeout to prevent hanging
      const timeout = setTimeout(() => {
        console.log('📧 Email sending timed out, continuing with registration...');
        resolve(false);
      }, 20000); // 20 second timeout

      try {
        const htmlContent = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Welcome to Xuxu - Registration Confirmation</title>
          <style>
            body {
              font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
              line-height: 1.6;
              color: #333;
              background-color: #f4f4f4;
              margin: 0;
              padding: 0;
            }
            .container {
              max-width: 600px;
              margin: 20px auto;
              background: white;
              border-radius: 10px;
              box-shadow: 0 0 20px rgba(0,0,0,0.1);
              overflow: hidden;
            }
            .header {
              background: linear-gradient(135deg, #07434f, #0a5660);
              color: white;
              padding: 30px;
              text-align: center;
            }
            .header h1 {
              margin: 0;
              font-size: 28px;
              font-weight: 300;
            }
            .content {
              padding: 40px 30px;
            }
            .welcome-text {
              font-size: 18px;
              color: #07434f;
              margin-bottom: 20px;
            }
            .credentials-box {
              background: #f8f9fa;
              border-left: 4px solid #07434f;
              padding: 20px;
              margin: 20px 0;
              border-radius: 5px;
            }
            .credential-item {
              margin: 10px 0;
              padding: 8px 0;
              border-bottom: 1px solid #e0e0e0;
            }
            .credential-label {
              font-weight: bold;
              color: #07434f;
              display: inline-block;
              width: 120px;
            }
            .credential-value {
              color: #333;
              font-family: 'Courier New', monospace;
              background: white;
              padding: 4px 8px;
              border-radius: 3px;
              border: 1px solid #ddd;
            }
            .confirm-button {
              display: inline-block;
              background: linear-gradient(135deg, #07434f, #0a5660);
              color: #ffffff !important;
              padding: 15px 30px;
              text-decoration: none;
              border-radius: 5px;
              font-weight: bold;
              margin: 20px 0;
              transition: transform 0.2s;
            }
            .confirm-button:hover {
              transform: translateY(-2px);
              color: #ffffff !important;
            }
            .confirm-button:visited {
              color: #ffffff !important;
            }
            .footer {
              background: #f8f9fa;
              padding: 20px 30px;
              text-align: center;
              color: #666;
              font-size: 14px;
            }
            .security-note {
              background: #fff3cd;
              border: 1px solid #ffeaa7;
              padding: 15px;
              border-radius: 5px;
              margin: 20px 0;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🎉 Welcome to Xuxu!</h1>
              <p>Your Group Savings Platform</p>
            </div>
            
            <div class="content">
              <div class="welcome-text">
                Hello <strong>${data.firstName} ${data.lastName}</strong>,
              </div>
              
              <p>Congratulations! Your Xuxu account has been successfully created. You're now part of our community focused on collaborative group savings and financial growth.</p>
              
              <div class="credentials-box">
                <h3 style="margin-top: 0; color: #07434f;">📋 Your Account Details</h3>
                <div class="credential-item">
                  <span class="credential-label">User ID:</span>
                  <span class="credential-value">${data.userEmail}</span>
                </div>
                <div class="credential-item">
                  <span class="credential-label">Password:</span>
                  <span class="credential-value">${data.password}</span>
                </div>
              </div>
              
              <div class="security-note">
                <strong>🔒 Security Reminder:</strong> Please keep your credentials secure and consider changing your password after your first login.
              </div>
              
              <p>To complete your registration and activate your account, please click the confirmation button below:</p>
              
              <div style="text-align: center;">
                <a href="${confirmationLink}" class="confirm-button">
                  ✅ Confirm Your Email Address
                </a>
              </div>
              
              <p><strong>What's next?</strong></p>
              <ul>
                <li>🏦 Join or create savings groups</li>
                <li>💰 Set your financial goals</li>
                <li>📊 Track your contributions</li>
                <li>🤝 Connect with like-minded savers</li>
              </ul>
              
              <p>If you have any questions, our support team is here to help you succeed in your savings journey.</p>
            </div>
            
            <div class="footer">
              <p>© 2024 Xuxu - Group Savings Platform</p>
              <p>This email was sent to ${data.userEmail}</p>
              <p>If you didn't create this account, please ignore this email.</p>
            </div>
          </div>
        </body>
        </html>
      `;

      const textContent = `
        Welcome to Xuxu - Group Savings Platform!
        
        Hello ${data.firstName} ${data.lastName},
        
        Congratulations! Your Xuxu account has been successfully created.
        
        Your Account Details:
        User ID: ${data.userEmail}
        Password: ${data.password}
        
        To complete your registration, please visit:
        ${confirmationLink}
        
        What's next?
        - Join or create savings groups
        - Set your financial goals
        - Track your contributions
        - Connect with like-minded savers
        
        © 2024 Xuxu - Group Savings Platform
      `;

      const mailOptions = {
        from: '"Xuxu Platform" <xuxuthrift@gmail.com>',
        to: data.userEmail,
        subject: '🎉 Welcome to Xuxu - Confirm Your Registration',
        text: textContent,
        html: htmlContent,
        replyTo: 'xuxuthrift@gmail.com'
      };

      await this.transporter.sendMail(mailOptions);
      console.log(`✅ Registration email sent successfully to: ${data.userEmail}`);
      return true;

    } catch (error) {
      console.error('❌ Failed to send registration email:', error);
      return false;
    }
  }
}

export const emailService = new EmailService();