import React, { Suspense } from "react";
import { createRoot } from "react-dom/client";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import "./index.css";

// Lazy load the main App for faster initial loading
const App = React.lazy(() => import("./App"));

// Performance-optimized loading spinner
const LoadingSpinner = () => (
  <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-[#07434f] to-[#0a5661]">
    <div className="flex flex-col items-center space-y-4">
      <div className="w-12 h-12 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
      <p className="text-white text-sm font-medium">Loading Xuxu...</p>
    </div>
  </div>
);

// Preload critical components in the background
const preloadComponents = () => {
  import("./components/registration/RegistrationForm");
  import("./pages/registration");
};

// Start preloading after a short delay
setTimeout(preloadComponents, 100);

// Global error handler to catch and suppress browser extension errors
window.addEventListener('error', (event) => {
  if (event.error?.message?.includes('UserReport') || 
      event.filename?.includes('chrome-extension') ||
      event.filename?.includes('moz-extension')) {
    console.warn('Suppressed browser extension error:', event.error?.message);
    event.preventDefault();
    return false;
  }
});

// Handle unhandled promise rejections from extensions
window.addEventListener('unhandledrejection', (event) => {
  if (event.reason?.message?.includes('UserReport') ||
      event.reason?.stack?.includes('chrome-extension') ||
      event.reason?.stack?.includes('moz-extension')) {
    console.warn('Suppressed browser extension promise rejection:', event.reason?.message);
    event.preventDefault();
    return false;
  }
});

const root = createRoot(document.getElementById("root")!);
root.render(
  <QueryClientProvider client={queryClient}>
    <Suspense fallback={<LoadingSpinner />}>
      <App />
    </Suspense>
  </QueryClientProvider>
);
