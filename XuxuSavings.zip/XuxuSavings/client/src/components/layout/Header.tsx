import { useState } from "react";
import { Link } from "wouter";
import xuxuLogo from "@/assets/xuxu-logo.png";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header className="bg-white shadow-sm relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <img 
            src={xuxuLogo} 
            alt="Xuxu" 
            className="h-10 w-auto object-contain"
          />
        </div>
        
        {/* Desktop Navigation */}
        <div className="hidden sm:flex items-center space-x-4">
          <Link href="#" className="text-neutral-500 hover:text-[#07434f] transition">
            Help
          </Link>
          <Link href="#" className="text-neutral-500 hover:text-[#07434f] transition">
            Login
          </Link>
          <Link
            href="/"
            className="bg-[#07434f] text-white px-4 py-2 rounded-lg hover:bg-[#07434f]/90 transition"
          >
            Register
          </Link>
        </div>
        
        {/* Mobile Menu Button */}
        <div className="sm:hidden">
          <button 
            type="button" 
            className="text-neutral-500 p-2 rounded-lg hover:bg-gray-100 transition-colors touch-action-manipulation"
            onClick={toggleMobileMenu}
            aria-label="Toggle mobile menu"
          >
            {isMobileMenuOpen ? (
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-x">
                <path d="M18 6 6 18" />
                <path d="m6 6 12 12" />
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-menu">
                <line x1="4" x2="20" y1="12" y2="12" />
                <line x1="4" x2="20" y1="6" y2="6" />
                <line x1="4" x2="20" y1="18" y2="18" />
              </svg>
            )}
          </button>
        </div>
      </div>
      
      {/* Mobile Navigation Menu */}
      {isMobileMenuOpen && (
        <div className="sm:hidden absolute top-full left-0 right-0 bg-white shadow-lg border-t z-50">
          <div className="px-4 py-4 space-y-3">
            <Link 
              href="#" 
              className="block text-neutral-500 hover:text-[#07434f] transition py-3 px-4 rounded-lg hover:bg-gray-50 touch-action-manipulation"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Help
            </Link>
            <Link 
              href="#" 
              className="block text-neutral-500 hover:text-[#07434f] transition py-3 px-4 rounded-lg hover:bg-gray-50 touch-action-manipulation"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Login
            </Link>
            <Link
              href="/"
              className="block bg-[#07434f] text-white px-4 py-3 rounded-lg hover:bg-[#07434f]/90 transition text-center touch-action-manipulation"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Register
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
