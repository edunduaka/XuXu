import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle2, XCircle, AlertCircle, Loader2 } from "lucide-react";
import { KYCValidationResult } from "@/lib/kyc-validation";

interface KYCValidationPopupProps {
  isOpen: boolean;
  onClose: () => void;
  onContinue: () => void;
  validationResult: KYCValidationResult | null;
  isValidating: boolean;
}

export default function KYCValidationPopup({ 
  isOpen, 
  onClose, 
  onContinue, 
  validationResult, 
  isValidating 
}: KYCValidationPopupProps) {
  const getStatusIcon = () => {
    if (isValidating) {
      return <Loader2 className="w-16 h-16 text-blue-500 animate-spin mx-auto" />;
    }
    
    if (!validationResult) return null;
    
    if (validationResult.success) {
      return <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto" />;
    } else {
      return <XCircle className="w-16 h-16 text-red-500 mx-auto" />;
    }
  };

  const getStatusTitle = () => {
    if (isValidating) return "Validating Your Identity...";
    if (!validationResult) return "";
    return validationResult.success ? "KYC Validation Successful!" : "KYC Validation Failed";
  };

  const getStatusMessage = () => {
    if (isValidating) {
      return "Please wait while we verify your identity documents and personal information. This may take a few moments.";
    }
    return validationResult?.message || "";
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.9) return "text-green-600";
    if (confidence >= 0.7) return "text-yellow-600";
    return "text-red-600";
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md mx-auto">
        <DialogHeader>
          <DialogTitle className="text-center text-xl font-semibold text-[#07434f]">
            {getStatusTitle()}
          </DialogTitle>
        </DialogHeader>
        
        <div className="py-6 space-y-6">
          {getStatusIcon()}
          
          <div className="text-center space-y-4">
            <p className="text-gray-600">
              {getStatusMessage()}
            </p>
            
            {validationResult && !isValidating && (
              <div className="space-y-4">
                <div className="bg-gray-50 p-4 rounded-lg space-y-3">
                  <h4 className="font-medium text-[#07434f]">Validation Details:</h4>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Document Verification:</span>
                      <span className={validationResult.details.documentVerification ? "text-green-600" : "text-red-600"}>
                        {validationResult.details.documentVerification ? "✓ Passed" : "✗ Failed"}
                      </span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>Government ID Check:</span>
                      <span className={validationResult.details.governmentIdVerification ? "text-green-600" : "text-red-600"}>
                        {validationResult.details.governmentIdVerification ? "✓ Passed" : "✗ Failed"}
                      </span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>Biometric Authentication:</span>
                      <span className={validationResult.details.biometricAuthentication ? "text-green-600" : "text-red-600"}>
                        {validationResult.details.biometricAuthentication ? "✓ Passed" : "✗ Failed"}
                      </span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>AML Check:</span>
                      <span className={validationResult.details.amlCheck ? "text-green-600" : "text-red-600"}>
                        {validationResult.details.amlCheck ? "✓ Passed" : "✗ Failed"}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex justify-between pt-2 border-t">
                    <span className="font-medium">Match Confidence:</span>
                    <span className={`font-medium ${getConfidenceColor(validationResult.confidence)}`}>
                      {Math.round(validationResult.confidence * 100)}%
                    </span>
                  </div>
                </div>
                
                {validationResult.matchedFields.length > 0 && (
                  <div className="bg-green-50 p-3 rounded-lg">
                    <p className="text-sm font-medium text-green-800 mb-1">Matched Fields:</p>
                    <p className="text-sm text-green-700">
                      {validationResult.matchedFields.map(field => {
                        const fieldNames: { [key: string]: string } = {
                          firstName: "First Name",
                          lastName: "Last Name", 
                          dateOfBirth: "Date of Birth",
                          gender: "Gender"
                        };
                        return fieldNames[field] || field;
                      }).join(", ")}
                    </p>
                  </div>
                )}
                
                {validationResult.unmatchedFields.length > 0 && (
                  <div className="bg-red-50 p-3 rounded-lg">
                    <p className="text-sm font-medium text-red-800 mb-1">Unmatched Fields:</p>
                    <p className="text-sm text-red-700">
                      {validationResult.unmatchedFields.map(field => {
                        const fieldNames: { [key: string]: string } = {
                          firstName: "First Name",
                          lastName: "Last Name", 
                          dateOfBirth: "Date of Birth",
                          gender: "Gender"
                        };
                        return fieldNames[field] || field;
                      }).join(", ")}
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
          
          <div className="flex gap-3 pt-4">
            {isValidating ? (
              <Button 
                disabled 
                className="w-full bg-gray-400 cursor-not-allowed"
              >
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Validating...
              </Button>
            ) : validationResult?.success ? (
              <Button 
                onClick={onContinue}
                className="w-full bg-[#07434f] hover:bg-[#07434f]/90 text-white"
              >
                Continue to Password Setup
              </Button>
            ) : (
              <>
                <Button 
                  onClick={onClose}
                  variant="outline"
                  className="flex-1"
                >
                  Try Again
                </Button>
                <Button 
                  onClick={onContinue}
                  className="flex-1 bg-[#07434f] hover:bg-[#07434f]/90 text-white"
                >
                  Continue to Password Setup
                </Button>
              </>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}