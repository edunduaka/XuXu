import { useEffect, useState } from "react";
import { CheckCircle, Home, Mail, Shield, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface EmailConfirmationSuccessProps {
  isOpen: boolean;
  userEmail: string;
  onRedirectHome: () => void;
}

export default function EmailConfirmationSuccess({ 
  isOpen, 
  userEmail, 
  onRedirectHome 
}: EmailConfirmationSuccessProps) {
  const [countdown, setCountdown] = useState(5);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setIsVisible(true);
      
      // Start countdown for auto-redirect
      const countdownInterval = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(countdownInterval);
            onRedirectHome();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(countdownInterval);
    }
  }, [isOpen, onRedirectHome]);

  if (!isOpen) return null;

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm transition-all duration-500 ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
      <Card className={`mx-4 w-full max-w-md transform transition-all duration-700 ${isVisible ? 'scale-100 translate-y-0' : 'scale-95 translate-y-4'}`}>
        <CardContent className="p-8 text-center">
          {/* Success Animation */}
          <div className="relative mb-6">
            <div className="mx-auto h-24 w-24 rounded-full bg-gradient-to-r from-green-400 to-green-600 flex items-center justify-center">
              <CheckCircle className="h-12 w-12 text-white animate-bounce" />
            </div>
            <div className="absolute -top-2 -right-2">
              <Sparkles className="h-8 w-8 text-yellow-400 animate-pulse" />
            </div>
          </div>

          {/* Success Message */}
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Email Confirmed Successfully! 🎉
          </h2>
          
          <p className="text-gray-600 mb-6">
            Your Xuxu account has been activated and secured with enterprise-level encryption.
          </p>

          {/* Email Info */}
          <div className="bg-gradient-to-r from-[#07434f]/10 to-[#0a5661]/10 rounded-lg p-4 mb-6">
            <div className="flex items-center justify-center space-x-2 text-[#07434f]">
              <Mail className="h-5 w-5" />
              <span className="font-medium">{userEmail}</span>
            </div>
          </div>

          {/* Security Features */}
          <div className="grid grid-cols-2 gap-3 mb-6">
            <div className="bg-green-50 rounded-lg p-3">
              <Shield className="h-6 w-6 text-green-600 mx-auto mb-1" />
              <p className="text-xs text-green-700 font-medium">Data Encrypted</p>
            </div>
            <div className="bg-blue-50 rounded-lg p-3">
              <CheckCircle className="h-6 w-6 text-blue-600 mx-auto mb-1" />
              <p className="text-xs text-blue-700 font-medium">Account Verified</p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <Button 
              onClick={onRedirectHome}
              className="w-full bg-gradient-to-r from-[#07434f] to-[#0a5661] hover:from-[#0a5661] hover:to-[#07434f] text-white"
            >
              <Home className="h-4 w-4 mr-2" />
              Continue to Xuxu Home
            </Button>
            
            <p className="text-sm text-gray-500">
              Redirecting automatically in {countdown} seconds...
            </p>
          </div>

          {/* Welcome Message */}
          <div className="mt-6 p-4 bg-gradient-to-r from-[#07434f]/5 to-[#0a5661]/5 rounded-lg">
            <p className="text-sm text-gray-700">
              Welcome to <span className="font-bold text-[#07434f]">Xuxu</span> - Your secure group savings platform!
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}