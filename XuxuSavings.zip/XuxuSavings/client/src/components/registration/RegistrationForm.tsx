import { useState, useEffect, useRef, memo, useMemo, useCallback, lazy, Suspense } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { UploadCloud, ArrowLeft, ArrowRight, CheckCircle2, X, Camera, Lock, Eye, EyeOff } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { countries } from "@/lib/utils/countries";
import { getAllCountries, getAllStatesByCountry, getAllCitiesByState } from "@/lib/utils/comprehensive-world-locations";
import { getCountriesByRegion } from "@/lib/utils/regions";
import { 
  useSpeedyImageCompression, 
  useRapidDebounce, 
  useQuickLocationCache, 
  useVirtualDropdown, 
  useFormSpeedPersistence, 
  useComponentSpeedLoader,
  useCriticalPreloader,
  useSpeedMonitor
} from "@/lib/speed-optimizer";
import { registrationSchema } from "@/lib/validations/registration";
// Lazy load heavy components for better performance
const FacialVerification = lazy(() => import("./FacialVerification"));
const KYCValidationPopup = lazy(() => import("./KYCValidationPopup"));
import { PhoneInput } from "@/components/ui/phone-input";
import { kycValidator, KYCValidationResult } from "@/lib/kyc-validation";

type FormData = z.infer<typeof registrationSchema>;

// Loading skeleton for heavy components
const ComponentLoader = () => (
  <div className="animate-pulse bg-neutral-200 rounded-lg h-12 w-full"></div>
);

interface RegistrationFormProps {
  currentStep: number;
  setCurrentStep: (step: number) => void;
}

const RegistrationForm = memo(function RegistrationForm({ currentStep, setCurrentStep }: RegistrationFormProps) {
  const [location, setLocation] = useLocation();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedCountry, setSelectedCountry] = useState<string>("");
  const [selectedState, setSelectedState] = useState<string>("");
  const [selectedDay, setSelectedDay] = useState<string>("");
  const [selectedMonth, setSelectedMonth] = useState<string>("");
  const [selectedYear, setSelectedYear] = useState<string>("");
  
  // Performance optimizations
  const { compressImage } = useSpeedyImageCompression();
  const { saveFormData, loadFormData, clearFormData } = useFormSpeedPersistence('registration-form');
  const { preloadComponent } = useComponentSpeedLoader();
  useCriticalPreloader(); // Preload critical assets
  
  // KYC Validation states
  const [showKYCPopup, setShowKYCPopup] = useState<boolean>(false);
  const [isValidatingKYC, setIsValidatingKYC] = useState<boolean>(false);
  const [kycValidationResult, setKycValidationResult] = useState<KYCValidationResult | null>(null);
  
  // Password visibility states
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState<boolean>(false);
  

  const firstNameRef = useRef<HTMLInputElement>(null);
  const regionSelectRef = useRef<HTMLButtonElement>(null);
  const { toast } = useToast();

  // Duplicate detection states
  const [duplicateChecks, setDuplicateChecks] = useState<{[key: string]: boolean}>({});
  const [duplicateMessages, setDuplicateMessages] = useState<{[key: string]: string}>({});

  // Simple debounce utility
  const debounce = (func: Function, delay: number) => {
    let timeoutId: NodeJS.Timeout;
    return (...args: any[]) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => func.apply(null, args), delay);
    };
  };

  // Duplicate checking function with debounce
  const checkForDuplicates = useCallback(
    debounce(async (fieldName: string, value: string) => {
      if (!value || value.length < 2) {
        setDuplicateChecks(prev => ({ ...prev, [fieldName]: false }));
        setDuplicateMessages(prev => ({ ...prev, [fieldName]: '' }));
        return;
      }

      try {
        const response = await fetch('/api/check-duplicate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ fieldName, value })
        });
        
        const result = await response.json();
        
        if (result.isDuplicate) {
          setDuplicateChecks(prev => ({ ...prev, [fieldName]: true }));
          setDuplicateMessages(prev => ({ 
            ...prev, 
            [fieldName]: getActionPromptMessage(fieldName, value)
          }));
        } else {
          setDuplicateChecks(prev => ({ ...prev, [fieldName]: false }));
          setDuplicateMessages(prev => ({ ...prev, [fieldName]: '' }));
        }
      } catch (error) {
        console.error('Error checking duplicates:', error);
      }
    }, 500),
    []
  );

  // Generate action prompt messages
  const getActionPromptMessage = (fieldName: string, value: string): string => {
    switch (fieldName) {
      case 'email':
        return `⚠️ This email (${value}) is already registered. Try logging in instead or use a different email.`;
      case 'phoneNumber':
        return `⚠️ This phone number is already registered. Try logging in instead or use a different number.`;
      case 'firstName':
        return `⚠️ Someone with this first name already exists. Please verify your spelling or use your full name.`;
      case 'lastName':
        return `⚠️ Someone with this last name already exists. Please verify your spelling or use your full name.`;
      default:
        return `⚠️ This ${fieldName} already exists in our system. Please verify or try a different value.`;
    }
  };
  
  const form = useForm<FormData>({
    resolver: zodResolver(registrationSchema),
    mode: "onSubmit", // Only validate on submit, not on change
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phoneNumber: "",
      dateOfBirth: "",
      gender: "male",
  
      region: undefined,
      country: "",
      state: "",
      city: "",
      address1: "",
      address2: "",
      idType: undefined,
      acceptTerms: false,
      password: "",
      confirmPassword: "",
    },
  });

  // Memoize expensive location data calculations for better performance
  const availableCountries = useMemo(() => {
    const regionValue = form.watch("region");
    if (!regionValue) return [];
    const countries = getCountriesByRegion(regionValue);
    console.log(`✅ Region "${regionValue}" loaded with ${countries.length} countries`);
    return countries;
  }, [form.watch("region")]);

  const availableStates = useMemo(() => {
    if (!selectedCountry) return [];
    const states = getAllStatesByCountry(selectedCountry);
    console.log(`✅ Country "${selectedCountry}" loaded with ${states.length} states`);
    return states;
  }, [selectedCountry]);

  const availableCities = useMemo(() => {
    if (!selectedCountry || !selectedState) return [];
    const cities = getAllCitiesByState(selectedCountry, selectedState);
    console.log(`✅ State "${selectedState}" in "${selectedCountry}" loaded with ${cities.length} cities`);
    return cities;
  }, [selectedCountry, selectedState]);

  // This ensures the component displays the correct step
  useEffect(() => {
    // Update form state when currentStep changes from parent
    console.log(`Current step updated to: ${currentStep}`);
    
    // Auto-focus on First Name field when Personal Information page loads
    if (currentStep === 0 && firstNameRef.current) {
      setTimeout(() => {
        firstNameRef.current?.focus();
      }, 100);
    }
    
    // Auto-focus on Region dropdown when Location Information page loads
    if (currentStep === 1 && regionSelectRef.current) {
      setTimeout(() => {
        regionSelectRef.current?.focus();
      }, 100);
    }
  }, [currentStep]);

  // Sync local state with form values for dynamic dropdowns
  useEffect(() => {
    const subscription = form.watch((value) => {
      if (value.country !== selectedCountry) {
        setSelectedCountry(value.country || "");
      }
      if (value.state !== selectedState) {
        setSelectedState(value.state || "");
      }
    });
    return () => subscription.unsubscribe();
  }, [form, selectedCountry, selectedState]);
  


  const steps = [
    {
      id: "personal",
      title: "Personal Information",
      fields: ["firstName", "middleName", "lastName", "email", "phoneNumber", "dateOfBirth", "gender"],
    },
    {
      id: "location",
      title: "Location Information",
      fields: ["region", "country", "state", "city", "address1", "address2"],
    },
    {
      id: "identity",
      title: "Identity Verification",
      fields: ["acceptTerms"],
    },
    {
      id: "password",
      title: "Password Setup",
      fields: ["password", "confirmPassword"],
    },
    {
      id: "success",
      title: "Registration Successful",
      fields: [],
    },
  ];

  const [isSubmitting, setIsSubmitting] = useState(false);

  const mutation = useMutation({
    mutationFn: async (data: FormData) => {
      if (isSubmitting) {
        console.log("⚠️ Duplicate submission blocked - already processing");
        throw new Error("Submission already in progress");
      }
      
      setIsSubmitting(true);
      console.log("🚀 FORM SUBMISSION INITIATED (First submission)");
      console.log("📊 Raw form data:", data);
      console.log("🔍 Key field values:");
      console.log("  - Gender:", data.gender);
      console.log("  - Date of Birth:", data.dateOfBirth);
      console.log("  - ID Type:", data.idType);
      console.log("  - Password:", data.password ? "***PROVIDED***" : "MISSING");
      console.log("📝 Form validation state:", form.formState.errors);
      
      const formData = new FormData();
      
      // Add all form fields to FormData - send exact format expected by database
      console.log("🔧 Converting object data to FormData...");
      Object.entries(data).forEach(([key, value]) => {
        // Skip form-only fields that shouldn't be sent to the database
        if (key === "acceptTerms" || key === "confirmPassword") {
          console.log(`  ⏭️ Skipping ${key} (form-only field)`);
          return;
        }
        
        // Convert all values to strings for FormData (database expects them)
        const stringValue = value !== undefined && value !== null ? String(value) : "";
        console.log(`  ✅ Adding ${key}: ${stringValue}`);
        formData.append(key, stringValue);
      });
      
      // Add files if they exist
      if (selectedFile) {
        formData.append("idDocument", selectedFile);
      }
      
      console.log("📤 Submitting FormData to API");
      console.log("🔗 API endpoint: POST /api/register");
      console.log("🌐 About to make fetch request...");
      console.log("📋 FormData contents:");
      const formDataEntries = Array.from(formData.entries());
      formDataEntries.forEach(([key, value]) => {
        console.log(`  ${key}: ${value}`);
      });
      
      try {
        const response = await fetch("/api/register", {
          method: "POST",
          body: formData,
          credentials: "include",
        });
        
        console.log("📡 Fetch response received:", response.status, response.statusText);
        console.log("📡 Response headers:", Object.fromEntries(response.headers.entries()));
        
        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(`Registration failed: ${response.status} ${errorText}`);
        }
        
        const result = await response.json();
        console.log("✅ Registration successful:", result);
        return result;
      } catch (error) {
        console.error("❌ Registration failed:", error);
        throw error;
      }
    },
    onSuccess: () => {
      setIsSubmitting(false);
      // Go directly to success step (now step 4 after removing KYC validation)
      setCurrentStep(4); // Move to final success step
    },
    onError: (error) => {
      setIsSubmitting(false);
      toast({
        title: "Registration failed",
        description: error.message || "Please try again later",
        variant: "destructive",
      });
    },
  });

  // KYC Validation function
  const performKYCValidation = async () => {
    const formData = form.getValues();
    
    if (!selectedFile) {
      toast({
        title: "ID Document Required",
        description: "Please upload your ID document before validation.",
        variant: "destructive",
      });
      return;
    }

    setIsValidatingKYC(true);
    setShowKYCPopup(true);

    try {
      // Convert selected file to base64 for API
      const reader = new FileReader();
      const documentImage = await new Promise<string>((resolve) => {
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(selectedFile);
      });

      // Skip KYC validation for now since APIs aren't configured yet
      // This allows users to register without external validation barriers
      const validationResult = {
        success: true,
        confidence: 1.0,
        matchedFields: ['firstName', 'lastName', 'dateOfBirth', 'gender'],
        unmatchedFields: [],
        message: 'Registration proceeding without KYC validation',
        details: {
          documentVerification: true,
          governmentIdVerification: true,
          biometricAuthentication: true,
          amlCheck: true
        }
      };
      
      setKycValidationResult(validationResult);
      setIsValidatingKYC(false);

    } catch (error) {
      setIsValidatingKYC(false);
      setKycValidationResult({
        success: false,
        confidence: 0,
        matchedFields: [],
        unmatchedFields: ['firstName', 'lastName', 'dateOfBirth', 'gender'],
        message: 'KYC validation failed due to technical error. Please try again.',
        details: {
          documentVerification: false,
          governmentIdVerification: false,
          biometricAuthentication: false,
          amlCheck: false
        }
      });
      
      toast({
        title: "Validation Error",
        description: "Unable to validate your documents. Please try again.",
        variant: "destructive",
      });
    }
  };

  const nextStep = async () => {
    try {
      // Validate current step fields first - exclude password fields if not on password step
      const currentFields = steps[currentStep].fields;
      let fieldsToValidate = currentFields;
      
      // If not on password step, don't validate password fields to prevent premature errors
      if (currentStep !== 3) {
        fieldsToValidate = currentFields.filter(field => !['password', 'confirmPassword'].includes(field));
      }
      
      if (fieldsToValidate.length > 0) {
        const isValid = await form.trigger(fieldsToValidate as any);
        
        if (!isValid) {
          toast({
            title: "Please check the form",
            description: "Please fill in all required fields correctly before proceeding.",
            variant: "destructive",
          });
          return;
        }
      }

      // Handle form submission on password step (step 3)
      if (currentStep === 3) {
        handlePasswordSubmission(form.getValues());
        return;
      }
      
      // Normal step progression for all other steps
      if (currentStep < steps.length - 1) {
        console.log(`Moving from step ${currentStep} to step ${currentStep + 1}`);
        setCurrentStep(currentStep + 1);
      }
    } catch (error) {
      console.error("Error moving to next step:", error);
      toast({
        title: "An error occurred",
        description: "There was a problem moving to the next step.",
        variant: "destructive",
      });
    }
  };

  const prevStep = () => {
    setCurrentStep(Math.max(0, currentStep - 1));
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    
    // Validate file size and type
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Maximum file size is 5MB",
          variant: "destructive",
        });
        return;
      }
      
      const validTypes = ["image/jpeg", "image/png", "application/pdf"];
      if (!validTypes.includes(file.type)) {
        toast({
          title: "Invalid file type",
          description: "Please upload a PDF, JPG, or PNG file",
          variant: "destructive",
        });
        return;
      }
      
      // Compress images for faster uploads
      if (file.type.startsWith('image/')) {
        try {
          const compressedFile = await compressImage(file);
          setSelectedFile(compressedFile);
          
          if (compressedFile.size < file.size) {
            toast({
              title: "Image optimized",
              description: `File size reduced by ${Math.round((1 - compressedFile.size / file.size) * 100)}%`,
            });
          }
        } catch (error) {
          setSelectedFile(file); // Fallback to original file
        }
      } else {
        setSelectedFile(file);
      }
    }
  };

  const handlePasswordSubmission = async (values: FormData) => {
    console.log("🚀 Password step form submission triggered");
    console.log("📊 Current form values:", JSON.stringify(values, null, 2));
    
    // Validate password requirements
    if (!values.password || values.password.trim() === "") {
      console.log("❌ Password validation failed: empty password");
      toast({
        title: "Password Required",
        description: "Please enter a password to complete registration.",
        variant: "destructive",
      });
      return;
    }
    
    // Check password strength
    if (values.password.length < 8) {
      console.log("❌ Password validation failed: too short");
      toast({
        title: "Password Too Short",
        description: "Password must be at least 8 characters long.",
        variant: "destructive",
      });
      return;
    }
    
    // Check password complexity
    const hasUppercase = /[A-Z]/.test(values.password);
    const hasLowercase = /[a-z]/.test(values.password);
    const hasNumber = /\d/.test(values.password);
    const hasSpecialChar = /[@$!%*?&]/.test(values.password);
    
    if (!hasUppercase || !hasLowercase || !hasNumber || !hasSpecialChar) {
      console.log("❌ Password validation failed: complexity requirements not met");
      toast({
        title: "Password Too Weak",
        description: "Password must contain uppercase, lowercase, number, and special character.",
        variant: "destructive",
      });
      return;
    }
    
    // Check if passwords match
    if (values.password !== values.confirmPassword) {
      console.log("❌ Password validation failed: passwords don't match");
      toast({
        title: "Passwords Don't Match",
        description: "Please make sure your passwords match.",
        variant: "destructive",
      });
      return;
    }
    
    // Submit to server
    console.log("✅ Password validation passed, submitting to server...");
    console.log("🔄 Calling mutation.mutate with validated data");
    mutation.mutate(values);
  };

  const removeFile = () => {
    setSelectedFile(null);
    // Reset file input
    const fileInput = document.getElementById("idDocument") as HTMLInputElement;
    if (fileInput) {
      fileInput.value = "";
    }
  };



  return (
    <div>
      {currentStep < 6 ? (
        <Card className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6">
          <h2 className="text-xl font-semibold page-header-info mb-6">
            {steps[currentStep].title}
          </h2>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(nextStep)} className="space-y-6">
              {/* Step 1: Personal Information */}
              {currentStep === 0 && (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="form-label-personal">
                            First Name <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input
                              ref={firstNameRef}
                              placeholder="Enter your first name"
                              value={field.value}
                              onChange={(e) => {
                                field.onChange(e);
                                checkForDuplicates('firstName', e.target.value);
                              }}
                              onBlur={field.onBlur}
                              name={field.name}
                              className="w-full px-4 py-3 rounded-lg"
                            />
                          </FormControl>
                          {duplicateMessages.firstName && (
                            <div className="mt-2 p-3 bg-orange-50 border border-orange-200 rounded-lg">
                              <p className="text-sm text-orange-700">{duplicateMessages.firstName}</p>
                            </div>
                          )}
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="middleName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="form-label-personal">
                            Middle Name <span className="text-gray-500 text-sm font-normal">(Optional)</span>
                          </FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Middle name (optional)"
                              {...field}
                              className="w-full px-4 py-3 rounded-lg"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="form-label-personal">
                            Last Name <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Enter your last name"
                              value={field.value}
                              onChange={(e) => {
                                field.onChange(e);
                                checkForDuplicates('lastName', e.target.value);
                              }}
                              onBlur={field.onBlur}
                              name={field.name}
                              className="w-full px-4 py-3 rounded-lg"
                            />
                          </FormControl>
                          {duplicateMessages.lastName && (
                            <div className="mt-2 p-3 bg-orange-50 border border-orange-200 rounded-lg">
                              <p className="text-sm text-orange-700">{duplicateMessages.lastName}</p>
                            </div>
                          )}
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="dateOfBirth"
                      render={({ field }) => {
                        const days = Array.from({ length: 31 }, (_, i) => (i + 1).toString());
                        const months = [
                          { value: "1", label: "January" },
                          { value: "2", label: "February" },
                          { value: "3", label: "March" },
                          { value: "4", label: "April" },
                          { value: "5", label: "May" },
                          { value: "6", label: "June" },
                          { value: "7", label: "July" },
                          { value: "8", label: "August" },
                          { value: "9", label: "September" },
                          { value: "10", label: "October" },
                          { value: "11", label: "November" },
                          { value: "12", label: "December" }
                        ];
                        const currentYearInt = new Date().getFullYear();
                        const years = Array.from({ length: 100 }, (_, i) => (currentYearInt - i).toString());

                        const updateDate = () => {
                          if (selectedDay && selectedMonth && selectedYear) {
                            const date = new Date(parseInt(selectedYear), parseInt(selectedMonth) - 1, parseInt(selectedDay));
                            if (!isNaN(date.getTime())) {
                              field.onChange(date.toISOString().split('T')[0]);
                            }
                          }
                        };

                        const handleDayChange = (value: string) => {
                          setSelectedDay(value);
                          if (selectedMonth && selectedYear) {
                            const date = new Date(parseInt(selectedYear), parseInt(selectedMonth) - 1, parseInt(value));
                            if (!isNaN(date.getTime())) {
                              field.onChange(date.toISOString().split('T')[0]);
                            }
                          }
                        };

                        const handleMonthChange = (value: string) => {
                          setSelectedMonth(value);
                          if (selectedDay && selectedYear) {
                            const date = new Date(parseInt(selectedYear), parseInt(value) - 1, parseInt(selectedDay));
                            if (!isNaN(date.getTime())) {
                              field.onChange(date.toISOString().split('T')[0]);
                            }
                          }
                        };

                        const handleYearChange = (value: string) => {
                          setSelectedYear(value);
                          if (selectedDay && selectedMonth) {
                            const date = new Date(parseInt(value), parseInt(selectedMonth) - 1, parseInt(selectedDay));
                            if (!isNaN(date.getTime())) {
                              field.onChange(date.toISOString().split('T')[0]);
                            }
                          }
                        };

                        return (
                          <FormItem>
                            <FormLabel className="form-label-personal">
                              Date of Birth <span className="text-red-500">*</span>
                            </FormLabel>
                            <div className="grid grid-cols-3 gap-3">
                              <Select
                                value={selectedDay}
                                onValueChange={handleDayChange}
                              >
                                <FormControl>
                                  <SelectTrigger className="px-4 py-3 rounded-lg">
                                    <SelectValue placeholder="Day" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {days.map((day) => (
                                    <SelectItem key={day} value={day}>
                                      {day}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              
                              <Select
                                value={selectedMonth}
                                onValueChange={handleMonthChange}
                              >
                                <FormControl>
                                  <SelectTrigger className="px-4 py-3 rounded-lg">
                                    <SelectValue placeholder="Month" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {months.map((month) => (
                                    <SelectItem key={month.value} value={month.value}>
                                      {month.label}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              
                              <Select
                                value={selectedYear}
                                onValueChange={handleYearChange}
                              >
                                <FormControl>
                                  <SelectTrigger className="px-4 py-3 rounded-lg">
                                    <SelectValue placeholder="Year" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {years.map((year) => (
                                    <SelectItem key={year} value={year}>
                                      {year}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                            <FormMessage />
                          </FormItem>
                        );
                      }}
                    />
                    
                    <FormField
                      control={form.control}
                      name="gender"
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormLabel className="form-label-personal">
                            Gender <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex space-x-4 mt-2"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="male" id="male" />
                                <label htmlFor="male" className="text-neutral-700">
                                  Male
                                </label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="female" id="female" />
                                <label htmlFor="female" className="text-neutral-700">
                                  Female
                                </label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="form-label-personal">
                            Email Address <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input
                              type="email"
                              placeholder="Enter your email address"
                              value={field.value}
                              onChange={(e) => {
                                field.onChange(e);
                                checkForDuplicates('email', e.target.value);
                              }}
                              onBlur={field.onBlur}
                              name={field.name}
                              className="w-full px-4 py-3 rounded-lg"
                            />
                          </FormControl>
                          {duplicateMessages.email && (
                            <div className="mt-2 p-3 bg-orange-50 border border-orange-200 rounded-lg">
                              <p className="text-sm text-orange-700">{duplicateMessages.email}</p>
                            </div>
                          )}
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="phoneNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="form-label-personal">
                            Phone Number <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <PhoneInput
                              value={field.value}
                              onChange={(value) => {
                                field.onChange(value);
                                checkForDuplicates('phoneNumber', value);
                              }}
                              placeholder="Enter phone number"
                              className="w-full"
                              error={!!form.formState.errors.phoneNumber}
                            />
                          </FormControl>
                          {duplicateMessages.phoneNumber && (
                            <div className="mt-2 p-3 bg-orange-50 border border-orange-200 rounded-lg">
                              <p className="text-sm text-orange-700">{duplicateMessages.phoneNumber}</p>
                            </div>
                          )}
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  {/* Selfie Capture Section - Temporarily Disabled */}
                  <div className="mt-6 border-t pt-4">
                    <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                      <h3 className="text-lg font-medium mb-2 text-gray-600">Selfie Verification</h3>
                      <p className="text-sm text-gray-500">
                        Selfie verification is temporarily disabled. You can complete your registration and add this verification later from your account settings.
                      </p>
                    </div>
                  </div>
                </>
              )}
              
              {/* This step is now displayed based on the currentStep prop from the parent */}
              
              {/* Step 2: Location Information */}
              {currentStep === 1 && (
                <>
                  {/* 1st Row: Region, Country of Residence */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="region"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="form-label-location">Region</FormLabel>
                          <Select
                            onValueChange={(value) => {
                              field.onChange(value);
                              // Reset country, state and city when region changes
                              setSelectedCountry("");
                              setSelectedState("");
                              form.setValue("country", "");
                              form.setValue("state", "");
                              form.setValue("city", "");
                            }}
                            value={field.value}
                          >
                            <FormControl>
                              <SelectTrigger ref={regionSelectRef} className="w-fit min-w-[180px] max-w-[200px] px-4 py-3 rounded-lg">
                                <SelectValue placeholder="Select your region" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Africa">Africa</SelectItem>
                              <SelectItem value="Asia">Asia</SelectItem>
                              <SelectItem value="Europe">Europe</SelectItem>
                              <SelectItem value="Middle East">Middle East</SelectItem>
                              <SelectItem value="North America">North America</SelectItem>
                              <SelectItem value="South America">South America</SelectItem>
                              <SelectItem value="Oceania">Oceania</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="country"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="form-label-location">
                            Country of Residence <span className="text-red-500">*</span>
                          </FormLabel>
                          <Select
                            onValueChange={(value) => {
                              field.onChange(value);
                              setSelectedCountry(value);
                              // Reset state and city when country changes
                              setSelectedState("");
                              form.setValue("state", "");
                              form.setValue("city", "");
                            }}
                            value={field.value}
                          >
                            <FormControl>
                              <SelectTrigger className="w-fit min-w-[220px] max-w-[300px] px-4 py-3 rounded-lg">
                                <SelectValue placeholder="Select your country" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {availableCountries.map((country) => (
                                <SelectItem key={country} value={country}>
                                  {country}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  {/* 2nd Row: State, City */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="state"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="form-label-location">State/Province</FormLabel>
                          <Select
                            onValueChange={(value) => {
                              field.onChange(value);
                              setSelectedState(value);
                              // Reset city when state changes
                              form.setValue("city", "");
                            }}
                            value={field.value}
                            disabled={!selectedCountry && !form.getValues("country")}
                          >
                            <FormControl>
                              <SelectTrigger className="w-fit min-w-[200px] max-w-[280px] px-4 py-3 rounded-lg">
                                <SelectValue placeholder={
                                  selectedCountry || form.getValues("country") 
                                    ? "Select your state/province" 
                                    : "First select a country"
                                } />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {availableStates.map((state) => (
                                <SelectItem key={state} value={state}>
                                  {state}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="city"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="form-label-location">City</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            value={field.value}
                            disabled={!selectedState && !form.getValues("state")}
                          >
                            <FormControl>
                              <SelectTrigger className="w-fit min-w-[180px] max-w-[250px] px-4 py-3 rounded-lg">
                                <SelectValue placeholder={
                                  selectedState || form.getValues("state")
                                    ? "Select your city" 
                                    : "First select a state/province"
                                } />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {availableCities.map((city) => (
                                <SelectItem key={city} value={city}>
                                  {city}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  {/* 3rd Row: Address Line 1 */}
                  <FormField
                    control={form.control}
                    name="address1"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="form-label-location">Address Line 1</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Enter your street address"
                            {...field}
                            className="w-full px-4 py-3 rounded-lg"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="address2"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="form-label-location">Address Line 2 (Optional)</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Apartment, suite, unit, building, floor, etc."
                            {...field}
                            className="w-full px-4 py-3 rounded-lg"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </>
              )}
              
              {/* Step 3: Identity Verification */}
              {currentStep === 2 && (
                <>
                  <FormField
                    control={form.control}
                    name="idType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="form-label-identity">ID Type</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger className="w-full px-4 py-3 rounded-lg">
                              <SelectValue placeholder="Select ID type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="international_passport">International Passport</SelectItem>
                            <SelectItem value="drivers_license">Driver's License</SelectItem>
                            <SelectItem value="government_id">Government Issued ID</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="space-y-3">
                    <FormLabel className="form-label-identity">Upload ID Document (Optional)</FormLabel>
                    <div
                      className="border-2 border-dashed border-neutral-300 rounded-lg p-6 text-center hover:border-primary transition cursor-pointer"
                      onClick={() => document.getElementById("idDocument")?.click()}
                    >
                      <input
                        type="file"
                        id="idDocument"
                        className="hidden"
                        accept="image/*, application/pdf"
                        onChange={handleFileChange}
                      />
                      <div className="space-y-2">
                        <UploadCloud className="h-8 w-8 mx-auto text-neutral-400" />
                        <p className="text-neutral-600">Click to upload or drag and drop</p>
                        <p className="text-sm text-neutral-500">PDF, JPG, or PNG (Max. 5MB)</p>
                      </div>
                    </div>
                    {selectedFile && (
                      <div className="mt-4 p-3 bg-neutral-50 rounded-lg flex items-center">
                        <div className="text-2xl text-primary mr-3">
                          {selectedFile.type.includes("pdf") ? (
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="lucide lucide-file-text"
                            >
                              <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                              <polyline points="14 2 14 8 20 8" />
                              <line x1="16" x2="8" y1="13" y2="13" />
                              <line x1="16" x2="8" y1="17" y2="17" />
                              <line x1="10" x2="8" y1="9" y2="9" />
                            </svg>
                          ) : (
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="lucide lucide-image"
                            >
                              <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
                              <circle cx="8.5" cy="8.5" r="1.5" />
                              <path d="m21 15-5-5L5 21" />
                            </svg>
                          )}
                        </div>
                        <span className="text-sm text-neutral-700">
                          {selectedFile.name}
                        </span>
                        <button
                          type="button"
                          className="ml-auto text-neutral-500 hover:text-neutral-700"
                          onClick={(e) => {
                            e.stopPropagation();
                            removeFile();
                          }}
                        >
                          <X size={16} />
                        </button>
                      </div>
                    )}
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="acceptTerms"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 mt-4">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>
                            I agree to the terms of service and privacy policy
                          </FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                </>
              )}
              
              {/* Step 5: KYC Validation - DISABLED FOR NOW */}
              {false && currentStep === 4 && (
                <div className="text-center">
                  <p className="text-gray-500">KYC processing temporarily disabled</p>
                </div>
              )}
              
              {/* Step 4: Password Setup */}
              {currentStep === 3 && (
                <>
                  <div className="text-center mb-8">
                    <div className="mb-6 inline-flex items-center justify-center w-16 h-16 rounded-full bg-[#07434f]/10 text-[#07434f]">
                      <Lock className="h-8 w-8" />
                    </div>
                    <h3 className="text-xl font-semibold text-[#07434f] mb-3">
                      Set Your Password
                    </h3>
                    <p className="text-neutral-600">
                      Create a secure password to protect your Xuxu account.
                    </p>
                  </div>

                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="form-label-password">Password</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Input
                              type={showPassword ? "text" : "password"}
                              placeholder="Enter your password"
                              {...field}
                              className="w-full px-4 py-3 pr-12 rounded-lg"
                              onChange={field.onChange}
                            />
                            <button
                              type="button"
                              onClick={() => setShowPassword(!showPassword)}
                              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-neutral-500 hover:text-[#07434f] transition-colors"
                            >
                              {showPassword ? (
                                <EyeOff className="h-5 w-5" />
                              ) : (
                                <Eye className="h-5 w-5" />
                              )}
                            </button>
                          </div>
                        </FormControl>
                        <FormDescription className="text-sm text-neutral-500">
                          Password must be at least 8 characters with uppercase, lowercase, number, and special character.
                        </FormDescription>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="form-label-password">Confirm Password</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Input
                              type={showConfirmPassword ? "text" : "password"}
                              placeholder="Confirm your password"
                              {...field}
                              className="w-full px-4 py-3 pr-12 rounded-lg"
                              onChange={field.onChange}
                            />
                            <button
                              type="button"
                              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-neutral-500 hover:text-[#07434f] transition-colors"
                            >
                              {showConfirmPassword ? (
                                <EyeOff className="h-5 w-5" />
                              ) : (
                                <Eye className="h-5 w-5" />
                              )}
                            </button>
                          </div>
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </>
              )}

              {/* Required Field Explanations */}
              <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
                <div className="flex items-center mb-3">
                  <span className="text-red-500 text-lg mr-2">*</span>
                  <h4 className="text-sm font-semibold text-gray-700">Required Field Information</h4>
                </div>
                <div className="text-xs text-gray-600 space-y-1">
                  <p>• <strong>Name:</strong> First and last name (minimum 2 characters each)</p>
                  <p>• <strong>Email:</strong> Valid email address for account verification</p>
                  <p>• <strong>Phone:</strong> Full phone number with country code (minimum 6 digits)</p>
                  <p>• <strong>Age:</strong> Must be 18 years or older to register</p>
                  <p>• <strong>Identity:</strong> ID verification is optional and can be completed later</p>
                  <p>• <strong>Address:</strong> Complete address (minimum 5 characters)</p>
                  <p>• <strong>Password:</strong> 8+ characters with uppercase, lowercase, number, and special character</p>
                </div>
              </div>
              
              <div className="pt-4 flex justify-between">
                {currentStep > 0 && (
                  <Button
                    type="button"
                    onClick={prevStep}
                    className="flex items-center bg-[#07434f] hover:bg-[#07434f]/90 text-white"
                  >
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Previous Step
                  </Button>
                )}
                
                <div className={currentStep === 0 ? "ml-auto" : ""}>
                  {currentStep < 2 ? (
                    <Button
                      type="button" 
                      className="flex items-center bg-[#07434f] hover:bg-[#07434f]/90 text-white"
                      onClick={nextStep}
                    >
                      Next Step
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  ) : currentStep === 2 ? (
                    <Button
                      type="button"
                      className="flex items-center bg-[#07434f] hover:bg-[#07434f]/90 text-white"
                      onClick={nextStep}
                    >
                      Continue to Password Setup
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  ) : currentStep === 3 ? (
                    <Button
                      type="submit"
                      className="flex items-center bg-[#07434f] hover:bg-[#07434f]/90 text-white"
                      disabled={mutation.isPending}
                    >
                      {mutation.isPending ? "Submitting..." : "Complete Registration"}
                      <CheckCircle2 className="ml-2 h-4 w-4" />
                    </Button>
                  ) : null}
                </div>
              </div>
            </form>
          </Form>
          
          {/* KYC Validation Popup - DISABLED FOR NOW */}
          {false && (
            <KYCValidationPopup
              isOpen={showKYCPopup}
              onClose={() => setShowKYCPopup(false)}
              onContinue={() => {
                setShowKYCPopup(false);
                setCurrentStep(4); // Move to KYC validation step
              }}
              validationResult={kycValidationResult}
              isValidating={isValidatingKYC}
            />
          )}
        </Card>
      ) : currentStep === 4 ? (
        <Card className="bg-white rounded-xl shadow-sm border border-neutral-200 p-8 text-center">
          <div className="mb-6 inline-flex items-center justify-center w-20 h-20 rounded-full bg-[#07434f] text-white">
            <CheckCircle2 className="h-10 w-10" />
          </div>
          <h2 className="text-2xl font-bold text-neutral-800 mb-3">🎉 Registration Successful!</h2>
          <p className="text-neutral-600 mb-6">
            Your Xuxu account has been created successfully and is ready for group savings!
          </p>
          
          {/* Email Authentication Information */}
          <div className="bg-gradient-to-r from-[#07434f]/10 to-[#0a5660]/10 rounded-lg p-6 mb-6 text-left">
            <div className="flex items-center mb-4">
              <div className="w-8 h-8 bg-[#07434f] rounded-full flex items-center justify-center mr-3">
                <span className="text-white text-sm">📧</span>
              </div>
              <h3 className="text-lg font-semibold text-[#07434f]">Authentication Email Sent</h3>
            </div>
            
            <div className="space-y-3 text-sm text-neutral-700">
              <p>We've sent a confirmation email to <strong>{form.getValues("email")}</strong> containing:</p>
              
              <div className="bg-white rounded-md p-4 space-y-2 border border-neutral-200">
                <div className="flex items-center">
                  <span className="w-2 h-2 bg-[#07434f] rounded-full mr-3"></span>
                  <span><strong>User ID:</strong> {form.getValues("email")}</span>
                </div>
                <div className="flex items-center">
                  <span className="w-2 h-2 bg-[#07434f] rounded-full mr-3"></span>
                  <span><strong>Password:</strong> Your chosen password</span>
                </div>
                <div className="flex items-center">
                  <span className="w-2 h-2 bg-[#07434f] rounded-full mr-3"></span>
                  <span><strong>Confirmation Link:</strong> Click to activate your account</span>
                </div>
              </div>
              
              <p className="text-white font-medium">
                📨 Please check your email and click the confirmation link to complete activation!
              </p>
            </div>
          </div>

          {/* Next Steps */}
          <div className="bg-neutral-50 rounded-lg p-6 mb-6 text-left">
            <h3 className="text-lg font-semibold text-neutral-800 mb-3">🚀 What's Next?</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
              <div className="flex items-center">
                <span className="text-[#07434f] mr-2">🏦</span>
                <span>Join or create savings groups</span>
              </div>
              <div className="flex items-center">
                <span className="text-[#07434f] mr-2">💰</span>
                <span>Set your financial goals</span>
              </div>
              <div className="flex items-center">
                <span className="text-[#07434f] mr-2">📊</span>
                <span>Track your contributions</span>
              </div>
              <div className="flex items-center">
                <span className="text-[#07434f] mr-2">🤝</span>
                <span>Connect with savers</span>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Button 
              className="px-6 py-3 bg-[#07434f] hover:bg-[#0a5660] text-white"
              onClick={() => setLocation('/dashboard')}
            >
              Go to Dashboard
            </Button>
            <Button variant="outline" className="px-6 py-3 border-[#07434f] text-[#07434f] hover:bg-[#07434f] hover:text-white">
              Set Up Profile
            </Button>
          </div>
        </Card>
      ) : null}
    </div>
  );
});

export default RegistrationForm;
