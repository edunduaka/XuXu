export default function Testimonials() {
  const testimonials = [
    {
      name: "Sarah Johnson",
      location: "Lagos, Nigeria",
      rating: 5,
      testimonial:
        "Xuxu has transformed how our women's cooperative manages our savings. Easy to use and completely transparent!",
      image:
        "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120&q=80",
    },
    {
      name: "Li Wei",
      location: "Beijing, China",
      rating: 5,
      testimonial:
        "Xuxu helps our savings group achieve perfect fund management. The security features give us complete confidence in our group savings.",
      image:
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120&q=80",
    },
  ];

  return (
    <div className="mt-12">
      <h2 className="text-2xl font-bold text-[#07434f] text-center mb-8">
        Trusted by Savers Across the World
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {testimonials.map((testimonial, index) => (
          <div
            key={index}
            className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6"
          >
            <div className="flex items-center mb-4">
              <img
                src={testimonial.image}
                alt={`Testimonial from ${testimonial.name}`}
                className="w-12 h-12 rounded-full object-cover mr-4"
              />
              <div>
                <h4 className="font-medium text-[#07434f]">
                  {testimonial.name}
                </h4>
                <p className="text-sm text-neutral-500">{testimonial.location}</p>
              </div>
              <div className="ml-auto flex text-[#07434f]">
                {Array.from({ length: Math.floor(testimonial.rating) }).map(
                  (_, i) => (
                    <svg
                      key={i}
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="currentColor"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="lucide lucide-star"
                    >
                      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                    </svg>
                  )
                )}
                {testimonial.rating % 1 > 0 && (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="lucide lucide-star-half"
                  >
                    <path d="M12 17.8 5.8 21 7 14.1 2 9.3l7-1L12 2" />
                  </svg>
                )}
              </div>
            </div>
            <p className="text-neutral-600">{testimonial.testimonial}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
