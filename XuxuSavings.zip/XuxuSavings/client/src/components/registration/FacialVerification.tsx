import React, { useCallback, useRef, useState } from "react";
import Webcam from "react-webcam";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, Camera } from "lucide-react";

interface FacialVerificationProps {
  onCapture: (imageSrc: string) => void;
}

const FacialVerification = ({ onCapture }: FacialVerificationProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const webcamRef = useRef<Webcam>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [message, setMessage] = useState("Position your face in the frame");
  const { toast } = useToast();

  // Capture photo
  const capturePhoto = useCallback(() => {
    if (webcamRef.current) {
      const imageSrc = webcamRef.current.getScreenshot();
      if (imageSrc) {
        setCapturedImage(imageSrc);
        setMessage("How does this photo look?");
      } else {
        toast({
          title: "Camera Error",
          description: "Unable to capture photo. Please try again.",
          variant: "destructive",
        });
      }
    }
  }, [webcamRef, toast]);

  // Retake photo
  const retakePhoto = () => {
    setCapturedImage(null);
    setMessage("Position your face in the frame");
  };

  // Use captured photo
  const confirmPhoto = () => {
    if (capturedImage) {
      onCapture(capturedImage);
      setIsOpen(false);
      setCapturedImage(null);
    }
  };

  // Video constraints
  const videoConstraints = {
    width: 400,
    height: 400,
    facingMode: "user"
  };

  return (
    <>
      <Button 
        type="button" 
        onClick={() => setIsOpen(true)}
        className="w-full md:w-auto flex items-center gap-2 bg-[#07434f] hover:bg-[#07434f]/90 text-white"
      >
        <Camera className="h-4 w-4" />
        <span>Take a Selfie</span>
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Take a Selfie</DialogTitle>
          </DialogHeader>
          
          <div className="flex flex-col items-center justify-center py-4">
            <Alert className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {message}
              </AlertDescription>
            </Alert>
            
            {!capturedImage ? (
              <div className="webcam-container relative">
                <Webcam
                  audio={false}
                  ref={webcamRef}
                  screenshotFormat="image/jpeg"
                  videoConstraints={videoConstraints}
                  className="rounded-md"
                  width={400}
                  height={400}
                />
                {/* Simple frame guide */}
                <div className="absolute top-0 left-0 w-full h-full flex items-center justify-center pointer-events-none z-20">
                  <div 
                    className="border-4 border-dashed rounded-full w-64 h-64 flex items-center justify-center"
                    style={{ borderColor: '#10b981' }}
                  >
                    <div className="text-center bg-black bg-opacity-50 p-2 rounded text-white text-sm">
                      Position your face inside this frame
                    </div>
                  </div>
                </div>
                <div className="mt-4 flex justify-center">
                  <Button 
                    type="button" 
                    onClick={capturePhoto}
                  >
                    Capture Photo
                  </Button>
                </div>
              </div>
            ) : (
              <div className="captured-image-container">
                <img src={capturedImage} alt="Captured selfie" className="rounded-md" width={400} />
                <div className="mt-4 flex space-x-2 justify-center">
                  <Button type="button" variant="outline" onClick={retakePhoto}>Retake</Button>
                  <Button type="button" onClick={confirmPhoto}>Use This Photo</Button>
                </div>
              </div>
            )}
          </div>

          <DialogFooter className="sm:justify-start">
            <Button type="button" variant="secondary" onClick={() => setIsOpen(false)}>
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default FacialVerification;