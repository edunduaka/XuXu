import React, { useCallback, useEffect, useRef, useState } from "react";
import Webcam from "react-webcam";
import * as faceapi from 'face-api.js';
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, AlertCircle } from "lucide-react";

// We'll use a CDN for the face-api models since local models might be challenging to set up
const MODEL_URL = 'https://justadudewhohacks.github.io/face-api.js/models';

interface EnhancedWebcamCaptureProps {
  onCapture: (imageSrc: string) => void;
}

const EnhancedWebcamCapture = ({ onCapture }: EnhancedWebcamCaptureProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const webcamRef = useRef<Webcam>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [modelsLoaded, setModelsLoaded] = useState(false);
  const [faceDetected, setFaceDetected] = useState(false);
  const [isGoodLighting, setIsGoodLighting] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [message, setMessage] = useState("Please position your face in the frame");

  // Load the face-api models
  useEffect(() => {
    const loadModels = async () => {
      try {
        setAnalyzing(true);
        // Check if models are already loaded
        if (!modelsLoaded) {
          setMessage("Loading face detection models...");
          await Promise.all([
            faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
            faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
            faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
            faceapi.nets.faceExpressionNet.loadFromUri(MODEL_URL)
          ]);
          setModelsLoaded(true);
          setMessage("Models loaded. Position your face in the frame");
        }
        setAnalyzing(false);
      } catch (error) {
        console.error("Error loading models:", error);
        setMessage("Unable to load face detection models. You can still take a selfie.");
        setAnalyzing(false);
      }
    };

    if (isOpen) {
      loadModels();
    }
  }, [isOpen, modelsLoaded]);

  // Run face detection when webcam is active
  useEffect(() => {
    let interval: number | null = null;

    if (isOpen && modelsLoaded && webcamRef.current && !capturedImage) {
      interval = window.setInterval(async () => {
        try {
          if (webcamRef.current && canvasRef.current) {
            const webcam = webcamRef.current.video;
            if (webcam && webcam.readyState === 4) {
              // Analyze frame for faces
              const detections = await faceapi.detectAllFaces(
                webcam, 
                new faceapi.TinyFaceDetectorOptions()
              ).withFaceLandmarks();

              // Check if a face is detected
              if (detections.length > 0) {
                setFaceDetected(true);
                
                // Clear canvas and draw detections
                const ctx = canvasRef.current.getContext('2d');
                if (ctx) {
                  canvasRef.current.width = webcam.videoWidth;
                  canvasRef.current.height = webcam.videoHeight;
                  
                  // Draw face detection results
                  faceapi.draw.drawDetections(canvasRef.current, detections);
                  faceapi.draw.drawFaceLandmarks(canvasRef.current, detections);

                  // Analyze lighting
                  const imageData = ctx.getImageData(0, 0, canvasRef.current.width, canvasRef.current.height);
                  const isWellLit = checkLighting(imageData.data);
                  setIsGoodLighting(isWellLit);
                  
                  if (isWellLit) {
                    setMessage("Perfect! You can take your selfie now");
                  } else {
                    setMessage("Please move to a better lit area");
                  }
                }
              } else {
                setFaceDetected(false);
                setMessage("No face detected. Please center your face in the frame");
              }
            }
          }
        } catch (error) {
          console.error("Error during face detection:", error);
        }
      }, 200);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isOpen, modelsLoaded, capturedImage]);

  // Check the lighting conditions
  const checkLighting = (pixelData: Uint8ClampedArray) => {
    let totalBrightness = 0;
    let pixelCount = 0;

    // Sample pixels to determine average brightness
    for (let i = 0; i < pixelData.length; i += 16) {
      const r = pixelData[i];
      const g = pixelData[i + 1];
      const b = pixelData[i + 2];
      
      // Calculate brightness (simple average method)
      const brightness = (r + g + b) / 3;
      totalBrightness += brightness;
      pixelCount++;
    }

    const avgBrightness = totalBrightness / pixelCount;
    
    // Consider well-lit if average brightness is between 80-220 (0-255 range)
    return avgBrightness > 80 && avgBrightness < 220;
  };

  const capture = useCallback(() => {
    if (webcamRef.current) {
      const imageSrc = webcamRef.current.getScreenshot();
      if (imageSrc) {
        setCapturedImage(imageSrc);
        setMessage("Selfie captured! How does it look?");
      } else {
        toast({
          title: "Webcam Error",
          description: "Unable to capture image from webcam. Please try again.",
          variant: "destructive",
        });
      }
    }
  }, [webcamRef]);

  const retake = () => {
    setCapturedImage(null);
    setMessage("Position your face in the frame");
  };

  const confirmCapture = () => {
    if (capturedImage) {
      onCapture(capturedImage);
      setIsOpen(false);
      setCapturedImage(null);
      toast({
        title: "Success!",
        description: "Selfie captured and verified successfully.",
      });
    }
  };

  const videoConstraints = {
    width: 400,
    height: 400,
    facingMode: "user"
  };

  return (
    <>
      <Button 
        type="button" 
        variant="outline" 
        onClick={() => setIsOpen(true)}
        className="w-full md:w-auto flex items-center gap-2"
      >
        <span>Take a Selfie</span>
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Take a Selfie in Good Lighting</DialogTitle>
          </DialogHeader>
          
          <div className="flex flex-col items-center justify-center py-4">
            {analyzing && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/50 z-10 rounded-md">
                <div className="flex flex-col items-center gap-2 text-white p-4">
                  <Loader2 className="h-8 w-8 animate-spin" />
                  <p>Loading face detection...</p>
                </div>
              </div>
            )}
            
            <Alert className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {message}
              </AlertDescription>
            </Alert>
            
            {!capturedImage ? (
              <div className="webcam-container relative">
                <Webcam
                  audio={false}
                  ref={webcamRef}
                  screenshotFormat="image/jpeg"
                  videoConstraints={videoConstraints}
                  className="rounded-md"
                  width={400}
                  height={400}
                />
                <canvas
                  ref={canvasRef}
                  className="absolute top-0 left-0 z-10"
                  style={{ width: '100%', height: '100%' }}
                />
                <div className="mt-4 flex justify-center">
                  <Button 
                    type="button" 
                    onClick={capture}
                    disabled={!modelsLoaded || (!faceDetected && modelsLoaded) || !isGoodLighting}
                  >
                    {!faceDetected && modelsLoaded ? "No Face Detected" : 
                     !isGoodLighting && faceDetected ? "Poor Lighting" : "Capture Photo"}
                  </Button>
                </div>
              </div>
            ) : (
              <div className="captured-image-container">
                <img src={capturedImage} alt="Captured selfie" className="rounded-md" width={400} />
                <div className="mt-4 flex space-x-2 justify-center">
                  <Button type="button" variant="outline" onClick={retake}>Retake</Button>
                  <Button type="button" onClick={confirmCapture}>Use This Photo</Button>
                </div>
              </div>
            )}
          </div>

          <DialogFooter className="sm:justify-start">
            <Button type="button" variant="secondary" onClick={() => setIsOpen(false)}>
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default EnhancedWebcamCapture;