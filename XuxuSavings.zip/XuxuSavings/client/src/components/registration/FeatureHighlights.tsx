export default function FeatureHighlights() {
  const features = [
    {
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-xl text-[#07434f]"
        >
          <path d="M3 5a9 9 0 0 1 9 9" />
          <path d="M3 9a5 5 0 0 1 5 5" />
          <circle cx="3" cy="13" r="1" />
          <path d="M13 13a9 9 0 0 0 9-9" />
          <path d="M17 9a5 5 0 0 0-5-5" />
          <circle cx="21" cy="4" r="1" />
        </svg>
      ),
      title: "Group Savings",
      description:
        "Create and join savings groups with friends, family, or colleagues to achieve goals together.",
      bgColor: "bg-teal-50",
    },
    {
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-xl text-[#07434f]"
        >
          <rect width="18" height="11" x="3" y="11" rx="2" ry="2" />
          <path d="M7 11V7a5 5 0 0 1 10 0v4" />
        </svg>
      ),
      title: "Secure Transactions",
      description:
        "All transactions are encrypted and secured with bank-level security protocols.",
      bgColor: "bg-teal-50",
    },
    {
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-xl text-[#07434f]"
        >
          <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
        </svg>
      ),
      title: "Financial Growth",
      description:
        "Track your savings growth and receive insights to improve your financial well-being.",
      bgColor: "bg-teal-50",
    },
  ];

  return (
    <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
      {features.map((feature, index) => (
        <div
          key={index}
          className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6"
        >
          <div
            className={`w-12 h-12 ${feature.bgColor} rounded-full flex items-center justify-center mb-4`}
          >
            {feature.icon}
          </div>
          <h3 className="text-lg font-semibold text-[#07434f] mb-2">
            {feature.title}
          </h3>
          <p className="text-neutral-600">{feature.description}</p>
        </div>
      ))}
    </div>
  );
}
