interface ProgressStepsProps {
  currentStep: number;
}

export default function ProgressSteps({ currentStep }: ProgressStepsProps) {
  const steps = ["Personal Info", "Location", "Identity", "Password", "Complete"];

  return (
    <>
      {/* Desktop progress indicators */}
      <div className="mb-8 hidden sm:block">
        <div className="flex items-center justify-between">
          {steps.map((step, index) => (
            <div key={index} className="flex items-center">
              <div className="flex flex-col items-center">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                    index <= currentStep
                      ? "bg-[#07434f] text-white"
                      : "bg-neutral-200 text-neutral-500"
                  }`}
                >
                  {index + 1}
                </div>
                <span
                  className={`mt-2 text-sm font-medium ${
                    index <= currentStep
                      ? "text-neutral-800"
                      : "text-neutral-500"
                  }`}
                >
                  {step}
                </span>
              </div>
              {index < steps.length - 1 && (
                <div
                  className={`h-2 flex-grow mx-2 ${
                    index < currentStep
                      ? "bg-[#07434f]"
                      : "bg-neutral-200"
                  }`}
                  style={{ width: "100px" }}
                />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Mobile progress indicator */}
      <div className="mb-6 sm:hidden">
        <div className="flex justify-between items-center">
          <span className="text-sm font-medium text-[#07434f]">
            Step {currentStep + 1} of {steps.length}
          </span>
          <span className="text-sm font-medium text-neutral-600">
            {steps[currentStep]}
          </span>
        </div>
        <div className="mt-2 w-full bg-neutral-200 rounded-full h-2">
          <div
            className="bg-[#07434f] h-2 rounded-full transition-all duration-300"
            style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
          ></div>
        </div>
      </div>
    </>
  );
}
