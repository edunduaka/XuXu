import React, { useCallback, useRef, useState } from "react";
import Webcam from "react-webcam";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";

interface WebcamCaptureProps {
  onCapture: (imageSrc: string) => void;
}

const WebcamCapture = ({ onCapture }: WebcamCaptureProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const webcamRef = useRef<Webcam>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);

  const capture = useCallback(() => {
    if (webcamRef.current) {
      const imageSrc = webcamRef.current.getScreenshot();
      if (imageSrc) {
        setCapturedImage(imageSrc);
      } else {
        toast({
          title: "Webcam Error",
          description: "Unable to capture image from webcam. Please try again.",
          variant: "destructive",
        });
      }
    }
  }, [webcamRef]);

  const retake = () => {
    setCapturedImage(null);
  };

  const confirmCapture = () => {
    if (capturedImage) {
      onCapture(capturedImage);
      setIsOpen(false);
      setCapturedImage(null);
      toast({
        title: "Success!",
        description: "Selfie captured successfully.",
      });
    }
  };

  const videoConstraints = {
    width: 320,
    height: 320,
    facingMode: "user"
  };

  return (
    <>
      <Button 
        type="button" 
        variant="outline" 
        onClick={() => setIsOpen(true)}
        className="w-full md:w-auto"
      >
        Take a Selfie
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Take a Selfie</DialogTitle>
          </DialogHeader>
          
          <div className="flex flex-col items-center justify-center py-4">
            {!capturedImage ? (
              <div className="webcam-container">
                <Webcam
                  audio={false}
                  ref={webcamRef}
                  screenshotFormat="image/jpeg"
                  videoConstraints={videoConstraints}
                  className="rounded-md"
                />
                <div className="mt-4">
                  <Button type="button" onClick={capture}>Capture Photo</Button>
                </div>
              </div>
            ) : (
              <div className="captured-image-container">
                <img src={capturedImage} alt="Captured selfie" className="rounded-md" />
                <div className="mt-4 flex space-x-2">
                  <Button type="button" variant="outline" onClick={retake}>Retake</Button>
                  <Button type="button" onClick={confirmCapture}>Use This Photo</Button>
                </div>
              </div>
            )}
          </div>

          <DialogFooter className="sm:justify-start">
            <Button type="button" variant="secondary" onClick={() => setIsOpen(false)}>
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default WebcamCapture;