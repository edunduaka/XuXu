import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import ProgressSteps from "@/components/registration/ProgressSteps";
import RegistrationForm from "@/components/registration/RegistrationForm";
import { useState, lazy, Suspense } from "react";

// Lazy load non-critical components for better performance
const FeatureHighlights = lazy(() => import("@/components/registration/FeatureHighlights"));
const Testimonials = lazy(() => import("@/components/registration/Testimonials"));

// Loading skeleton for lazy components
const ComponentSkeleton = () => (
  <div className="animate-pulse bg-neutral-200 rounded-lg h-48 mb-8"></div>
);

export default function Registration() {
  const [currentStep, setCurrentStep] = useState(0);

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col">
      <Header />
      
      <main className="flex-grow py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          {/* Registration Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold page-header-info">Create Your Xuxu Account</h1>
            <p className="mt-2 page-header-info">
              Join thousands of people saving and managing finances together
            </p>
          </div>
          
          {/* Progress Steps */}
          <ProgressSteps currentStep={currentStep} />
          
          {/* Registration Form */}
          <RegistrationForm 
            currentStep={currentStep}
            setCurrentStep={setCurrentStep}
          />
          
          {/* Feature Highlights */}
          <Suspense fallback={<ComponentSkeleton />}>
            <FeatureHighlights />
          </Suspense>
          
          {/* Testimonials */}
          <Suspense fallback={<ComponentSkeleton />}>
            <Testimonials />
          </Suspense>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
