import { useState } from "react";
import { Users, Plus, TrendingUp, Shield, Bell, Settings, CreditCard, Target } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("overview");

  const savingsGroups = [
    {
      id: 1,
      name: "Family Emergency Fund",
      members: 5,
      targetAmount: 50000,
      currentAmount: 32500,
      nextContribution: "2024-01-15",
      status: "active"
    },
    {
      id: 2,
      name: "Vacation Savings Circle",
      members: 8,
      targetAmount: 25000,
      currentAmount: 18750,
      nextContribution: "2024-01-20",
      status: "active"
    }
  ];

  const quickActions = [
    { icon: Plus, title: "Create New Group", description: "Start a new savings circle", color: "from-blue-500 to-blue-600" },
    { icon: Users, title: "Join a Group", description: "Find and join existing groups", color: "from-green-500 to-green-600" },
    { icon: CreditCard, title: "Make Contribution", description: "Add funds to your groups", color: "from-purple-500 to-purple-600" },
    { icon: Target, title: "Set Goals", description: "Define your savings targets", color: "from-orange-500 to-orange-600" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-[#07434f] to-[#0a5661] rounded-lg flex items-center justify-center">
                <Users className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-[#07434f]">Xuxu Dashboard</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm">
                <Bell className="h-4 w-4 mr-2" />
                Notifications
              </Button>
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Welcome to Your Xuxu Account!</h2>
          <p className="text-xl text-gray-600">Manage your group savings, track contributions, and achieve your financial goals.</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Groups</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-[#07434f]">2</div>
              <p className="text-xs text-muted-foreground">+1 new this month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Savings</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">$51,250</div>
              <p className="text-xs text-muted-foreground">+12% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Next Contribution</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">Jan 15</div>
              <p className="text-xs text-muted-foreground">Family Emergency Fund</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Security Score</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">A+</div>
              <p className="text-xs text-muted-foreground">Fully encrypted</p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Quick Actions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {quickActions.map((action, index) => (
              <Card key={index} className="cursor-pointer hover:scale-105 transition-transform duration-200">
                <CardHeader className="text-center">
                  <div className={`w-16 h-16 mx-auto rounded-full bg-gradient-to-r ${action.color} flex items-center justify-center mb-4`}>
                    <action.icon className="h-8 w-8 text-white" />
                  </div>
                  <CardTitle className="text-lg">{action.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-center">{action.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Active Savings Groups */}
        <div className="mb-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Your Savings Groups</h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {savingsGroups.map((group) => (
              <Card key={group.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl text-[#07434f]">{group.name}</CardTitle>
                      <CardDescription>{group.members} members</CardDescription>
                    </div>
                    <Badge className="bg-green-100 text-green-800">
                      {group.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Progress</span>
                        <span>${group.currentAmount.toLocaleString()} / ${group.targetAmount.toLocaleString()}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-gradient-to-r from-[#07434f] to-[#0a5661] h-2 rounded-full" 
                          style={{ width: `${(group.currentAmount / group.targetAmount) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Next contribution: {group.nextContribution}</span>
                      <Button size="sm" className="bg-gradient-to-r from-[#07434f] to-[#0a5661]">
                        View Details
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Security Features */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center text-2xl text-[#07434f]">
              <Shield className="h-6 w-6 mr-2" />
              Your Account Security
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 mx-auto bg-green-100 rounded-full flex items-center justify-center mb-4">
                  <Shield className="h-8 w-8 text-green-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Data Encryption</h4>
                <p className="text-sm text-gray-600">All your personal and financial data is protected with military-grade encryption.</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 mx-auto bg-blue-100 rounded-full flex items-center justify-center mb-4">
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Identity Verified</h4>
                <p className="text-sm text-gray-600">Your identity has been verified through our comprehensive KYC process.</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 mx-auto bg-purple-100 rounded-full flex items-center justify-center mb-4">
                  <TrendingUp className="h-8 w-8 text-purple-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Secure Transactions</h4>
                <p className="text-sm text-gray-600">All contributions and payouts are processed through secure, encrypted channels.</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Getting Started Guide */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-[#07434f]">Getting Started with Xuxu</CardTitle>
            <CardDescription>Complete these steps to maximize your savings potential</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm">✓</span>
                </div>
                <span className="text-gray-900">Create your secure account</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-6 h-6 bg-[#07434f] text-white rounded-full flex items-center justify-center">
                  <span className="text-white text-sm">2</span>
                </div>
                <span className="text-gray-900">Create your first savings group or join an existing one</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-6 h-6 bg-gray-300 rounded-full flex items-center justify-center">
                  <span className="text-gray-600 text-sm">3</span>
                </div>
                <span className="text-gray-600">Make your first contribution</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-6 h-6 bg-gray-300 rounded-full flex items-center justify-center">
                  <span className="text-gray-600 text-sm">4</span>
                </div>
                <span className="text-gray-600">Invite friends and family to join your group</span>
              </div>
            </div>
            <div className="mt-6">
              <Button className="bg-gradient-to-r from-[#07434f] to-[#0a5661] text-white">
                <Plus className="h-4 w-4 mr-2" />
                Create Your First Savings Group
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}