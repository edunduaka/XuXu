import { useState } from "react";
import { Users, Shield, TrendingUp, Globe, ArrowRight, Star, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Home() {
  const [activeFeature, setActiveFeature] = useState(0);

  const features = [
    {
      icon: Users,
      title: "Group Savings",
      description: "Create or join savings groups with friends, family, and trusted communities",
      color: "from-blue-500 to-blue-600"
    },
    {
      icon: Shield,
      title: "Bank-Level Security",
      description: "Your data is protected with military-grade encryption at rest and in transit",
      color: "from-green-500 to-green-600"
    },
    {
      icon: TrendingUp,
      title: "Smart Contributions",
      description: "Track your savings goals and watch your money grow with our intelligent system",
      color: "from-purple-500 to-purple-600"
    },
    {
      icon: Globe,
      title: "Global Reach",
      description: "Connect with savings groups across Africa, Middle East, and beyond",
      color: "from-orange-500 to-orange-600"
    }
  ];

  const testimonials = [
    {
      name: "Amara Johnson",
      location: "Lagos, Nigeria",
      message: "Xuxu has transformed how our community saves together. The security gives us peace of mind!",
      rating: 5
    },
    {
      name: "Omar Al-Hassan",
      location: "Dubai, UAE",
      message: "Finally, a platform that understands group savings culture. Simple, secure, and effective!",
      rating: 5
    },
    {
      name: "Sarah Ochieng",
      location: "Nairobi, Kenya",
      message: "The encryption and verification process made me trust Xuxu immediately. Highly recommended!",
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-[#07434f] to-[#0a5661] rounded-lg flex items-center justify-center">
                <Users className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-[#07434f]">Xuxu</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" className="text-[#07434f] border-[#07434f]">
                Sign In
              </Button>
              <Button className="bg-gradient-to-r from-[#07434f] to-[#0a5661] text-white">
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <Badge className="mb-6 bg-[#07434f]/10 text-[#07434f] border-[#07434f]/20">
            🎉 Welcome to your secure financial community!
          </Badge>
          
          <h2 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Your Journey to 
            <span className="bg-gradient-to-r from-[#07434f] to-[#0a5661] bg-clip-text text-transparent"> Financial Growth</span> Begins Here
          </h2>
          
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Join thousands of people building wealth together through secure group savings, 
            intelligent contributions, and community-driven financial goals.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button size="lg" className="bg-gradient-to-r from-[#07434f] to-[#0a5661] text-white px-8 py-3">
              <Users className="h-5 w-5 mr-2" />
              Start Your Savings Journey
              <ArrowRight className="h-5 w-5 ml-2" />
            </Button>
            <Button variant="outline" size="lg" className="text-[#07434f] border-[#07434f] px-8 py-3">
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-gray-900 mb-4">
              Why Choose Xuxu?
            </h3>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Experience the perfect blend of traditional group savings with modern security and technology
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card 
                key={index}
                className={`relative overflow-hidden cursor-pointer transition-all duration-300 hover:scale-105 ${
                  activeFeature === index ? 'ring-2 ring-[#07434f] shadow-lg' : ''
                }`}
                onMouseEnter={() => setActiveFeature(index)}
              >
                <CardHeader className="text-center">
                  <div className={`w-16 h-16 mx-auto rounded-full bg-gradient-to-r ${feature.color} flex items-center justify-center mb-4`}>
                    <feature.icon className="h-8 w-8 text-white" />
                  </div>
                  <CardTitle className="text-xl text-gray-900">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-center text-gray-600">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-[#07434f]/5 to-[#0a5661]/5">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-gray-900 mb-4">
              Trusted by Communities Worldwide
            </h3>
            <p className="text-xl text-gray-600">
              Join thousands who have transformed their savings journey with Xuxu
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-white shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-700 mb-4 italic">"{testimonial.message}"</p>
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-[#07434f] to-[#0a5661] rounded-full flex items-center justify-center text-white font-bold text-lg">
                      {testimonial.name.charAt(0)}
                    </div>
                    <div className="ml-3">
                      <p className="font-semibold text-gray-900">{testimonial.name}</p>
                      <p className="text-sm text-gray-600">{testimonial.location}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Security Badge Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-8 mb-8">
            <div className="flex items-center space-x-2">
              <Shield className="h-8 w-8 text-green-600" />
              <span className="text-lg font-semibold text-gray-900">Bank-Level Security</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-8 w-8 text-blue-600" />
              <span className="text-lg font-semibold text-gray-900">Verified Platform</span>
            </div>
          </div>
          <p className="text-gray-600">
            Your personal and financial data is protected with military-grade encryption, 
            ensuring complete privacy and security for all your transactions.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-r from-[#07434f] to-[#0a5661] rounded-lg flex items-center justify-center">
                  <Users className="h-6 w-6 text-white" />
                </div>
                <h1 className="text-2xl font-bold">Xuxu</h1>
              </div>
              <p className="text-gray-400 max-w-md">
                Empowering communities through secure group savings and intelligent financial collaboration.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Platform</h4>
              <ul className="space-y-2 text-gray-400">
                <li>How it Works</li>
                <li>Security</li>
                <li>Pricing</li>
                <li>Support</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li>About</li>
                <li>Privacy Policy</li>
                <li>Terms of Service</li>
                <li>Contact</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Xuxu - Group Savings Platform. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}