// Performance optimization utilities for Xuxu app
// Enhanced with lazy loading, caching, and speed optimizations

import { useMemo, useCallback, useState, useEffect } from 'react';

// Debounce function for input fields to improve performance
export const debounce = <T extends (...args: any[]) => any>(
  func: T,
  delay: number
): ((...args: Parameters<T>) => void) => {
  let timeoutId: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => func(...args), delay);
  };
};

// Memoized location data hook for better performance
export const useMemoizedLocationData = (selectedCountry: string, selectedState: string) => {
  return useMemo(() => {
    // Only calculate when dependencies change
    return {
      country: selectedCountry,
      state: selectedState,
      timestamp: Date.now()
    };
  }, [selectedCountry, selectedState]);
};

// Optimized image compression for file uploads
export const compressImage = async (file: File, maxWidth = 800, quality = 0.8): Promise<File> => {
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();
    
    img.onload = () => {
      // Calculate new dimensions
      const ratio = Math.min(maxWidth / img.width, maxWidth / img.height);
      canvas.width = img.width * ratio;
      canvas.height = img.height * ratio;
      
      // Draw compressed image
      ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
      
      canvas.toBlob((blob) => {
        if (blob) {
          const compressedFile = new File([blob], file.name, {
            type: file.type,
            lastModified: Date.now()
          });
          resolve(compressedFile);
        } else {
          resolve(file);
        }
      }, file.type, quality);
    };
    
    img.src = URL.createObjectURL(file);
  });
};

// Preload critical components
export const preloadComponent = (importFunc: () => Promise<any>) => {
  return importFunc();
};

// Intersection Observer hook for lazy loading
export const useIntersectionObserver = (
  ref: React.RefObject<Element>,
  options: IntersectionObserverInit = {}
) => {
  const callback = useCallback((entries: IntersectionObserverEntry[]) => {
    const [entry] = entries;
    return entry.isIntersecting;
  }, []);

  return useMemo(() => {
    if (ref.current) {
      const observer = new IntersectionObserver(callback, options);
      observer.observe(ref.current);
      return () => observer.disconnect();
    }
  }, [ref, callback, options]);
};

// Enhanced cache management for faster loading
export const createOptimizedCache = () => {
  const cache = new Map();
  const maxSize = 100;
  
  return {
    get: (key: string) => cache.get(key),
    set: (key: string, value: any) => {
      if (cache.size >= maxSize) {
        const firstKey = cache.keys().next().value;
        cache.delete(firstKey);
      }
      cache.set(key, value);
    },
    clear: () => cache.clear(),
    size: () => cache.size
  };
};

// Preload critical images and assets
export const preloadAssets = (urls: string[]) => {
  urls.forEach(url => {
    const link = document.createElement('link');
    link.rel = 'preload';
    link.as = 'image';
    link.href = url;
    document.head.appendChild(link);
  });
};

// Optimize bundle loading with dynamic imports
import { lazy } from 'react';
export const lazyLoadComponent = (importFunc: () => Promise<any>) => {
  return lazy(importFunc);
};

// Fast location data loader with caching
export const useFastLocationData = () => {
  const [locationCache] = useState(() => createOptimizedCache());
  
  const loadLocationData = useCallback(async (region: string) => {
    const cacheKey = `location-${region}`;
    
    // Check cache first
    if (locationCache.get(cacheKey)) {
      return locationCache.get(cacheKey);
    }
    
    // Load and cache the data
    try {
      const response = await fetch('/server/processed-countries.json');
      const data = await response.json();
      locationCache.set(cacheKey, data);
      return data;
    } catch (error) {
      console.error('Failed to load location data:', error);
      return [];
    }
  }, [locationCache]);
  
  return { loadLocationData, locationCache };
};

// Optimize form rendering with virtual scrolling
export const useVirtualizedList = (items: any[], itemHeight: number, containerHeight: number) => {
  const [scrollTop, setScrollTop] = useState(0);
  
  const visibleItems = useMemo(() => {
    const startIndex = Math.floor(scrollTop / itemHeight);
    const endIndex = Math.min(
      startIndex + Math.ceil(containerHeight / itemHeight) + 1,
      items.length
    );
    
    return items.slice(startIndex, endIndex).map((item, index) => ({
      ...item,
      index: startIndex + index
    }));
  }, [items, itemHeight, containerHeight, scrollTop]);
  
  return { visibleItems, setScrollTop };
};