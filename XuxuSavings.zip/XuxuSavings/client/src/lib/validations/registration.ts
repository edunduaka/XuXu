import { z } from "zod";

export const registrationSchema = z.object({
  firstName: z.string().min(2, {
    message: "First name must be at least 2 characters.",
  }),
  middleName: z.string().optional(),
  lastName: z.string().min(2, {
    message: "Last name must be at least 2 characters.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  phoneNumber: z.string({
    required_error: "Phone number is required",
  }).min(6, {
    message: "Please enter a valid phone number",
  }),
  dateOfBirth: z.string().refine((date) => {
    // Validate date and ensure user is at least 18 years old
    const today = new Date();
    const birthDate = new Date(date);
    const age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    // If birth month hasn't occurred yet this year or if it's the same month but birth day hasn't occurred yet
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      return age - 1 >= 18;
    }
    
    return age >= 18;
  }, {
    message: "You must be at least 18 years old to register.",
  }),
  gender: z.enum(["male", "female", "other"], {
    required_error: "Please select your gender.",
  }),

  region: z.enum(["Africa", "Asia", "Europe", "Middle East", "North America", "South America", "Oceania"], {
    required_error: "Please select your region.",
  }),
  country: z.string().min(1, {
    message: "Please select your country of residence.",
  }),
  state: z.string().min(1, {
    message: "Please enter your state.",
  }),
  city: z.string().min(1, {
    message: "Please enter your city.",
  }),
  address1: z.string().min(5, {
    message: "Address must be at least 5 characters.",
  }),
  address2: z.string().optional(),
  idType: z.enum(["international_passport", "drivers_license", "government_id"]).optional(),
  acceptTerms: z.boolean().refine((value) => value === true, {
    message: "You must accept the terms to continue.",
  }),
  password: z.string().optional(),
  confirmPassword: z.string().optional(),
});

export type RegistrationData = z.infer<typeof registrationSchema>;
