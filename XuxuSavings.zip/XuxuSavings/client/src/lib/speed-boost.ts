// Ultimate speed optimization system for Xuxu
import { useCallback, useEffect, useRef } from 'react';

// Lightning-fast image processing
export const useTurboImageOptimizer = () => {
  const processImage = useCallback(async (file: File): Promise<File> => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d')!;
    const img = new Image();
    
    return new Promise((resolve) => {
      img.onload = () => {
        // Ultra-fast compression (max 600px width for speed)
        const maxSize = 600;
        const ratio = Math.min(maxSize / img.width, maxSize / img.height);
        
        canvas.width = img.width * ratio;
        canvas.height = img.height * ratio;
        
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        
        canvas.toBlob((blob) => {
          if (blob) {
            resolve(new File([blob], file.name, { type: 'image/jpeg' }));
          }
        }, 'image/jpeg', 0.8);
      };
      
      img.src = URL.createObjectURL(file);
    });
  }, []);

  return { processImage };
};

// Super-fast data caching
export const useTurboCache = () => {
  const cache = useRef(new Map());

  const getCache = useCallback((key: string) => cache.current.get(key), []);
  const setCache = useCallback((key: string, value: any) => {
    cache.current.set(key, value);
  }, []);

  return { getCache, setCache };
};

// Instant form validation
export const useTurboValidation = () => {
  const validateInstant = useCallback((value: string, type: 'email' | 'phone' | 'name') => {
    switch (type) {
      case 'email':
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
      case 'phone':
        return value.length >= 10;
      case 'name':
        return value.trim().length >= 2;
      default:
        return true;
    }
  }, []);

  return { validateInstant };
};

// Pre-load critical resources for instant access
export const useTurboPreloader = () => {
  useEffect(() => {
    // Pre-load location data instantly
    const preload = async () => {
      try {
        await Promise.all([
          fetch('/server/africa-location-data.ts'),
          fetch('/server/middle-east-location-data.ts')
        ]);
      } catch (error) {
        // Silent fail for better UX
      }
    };

    // Start immediately for maximum speed
    preload();
  }, []);
};

// Turbo-charged debouncing
export const useTurboDebounce = (callback: Function, delay = 200) => {
  const timeoutRef = useRef<NodeJS.Timeout>();
  
  return useCallback((...args: any[]) => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => callback(...args), delay);
  }, [callback, delay]);
};