// Registration form performance optimizations
import { useCallback, useMemo, useState, useEffect } from 'react';

// Optimized location data with smart caching
export const useOptimizedLocationData = () => {
  const [locationCache, setLocationCache] = useState(new Map());

  const getCountriesByRegion = useCallback((region: string) => {
    const cacheKey = `region-${region}`;
    if (locationCache.has(cacheKey)) {
      return locationCache.get(cacheKey);
    }
    
    // Import and cache immediately
    import('./utils/comprehensive-world-locations').then(({ getCountriesByRegion }) => {
      const countries = getCountriesByRegion(region);
      setLocationCache(prev => new Map(prev).set(cacheKey, countries));
    });
    
    return [];
  }, [locationCache]);

  return { getCountriesByRegion };
};

// Super fast debounced input for smooth typing
export const useQuickDebounce = <T>(value: T, delay: number = 100): T => {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const handler = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);

  return debouncedValue;
};

// Progressive field loading for faster initial render
export const useSmartFieldLoading = () => {
  const [visibleFields, setVisibleFields] = useState(new Set(['firstName', 'lastName', 'email']));
  
  const showField = useCallback((field: string) => {
    return visibleFields.has(field);
  }, [visibleFields]);

  // Load fields progressively for smooth experience
  useEffect(() => {
    const loadMoreFields = () => {
      setVisibleFields(prev => new Set([
        ...prev,
        'region', 'country', 'state', 'city', 'dateOfBirth', 'gender', 'phoneNumber'
      ]));
    };

    const timer = setTimeout(loadMoreFields, 300);
    return () => clearTimeout(timer);
  }, []);

  return { showField };
};

// Lightning-fast image optimization
export const useImageCompression = () => {
  const compressImage = useCallback(async (file: File): Promise<File> => {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      
      img.onload = () => {
        // Smart compression for fast uploads
        const maxSize = 600;
        let { width, height } = img;
        
        if (width > height && width > maxSize) {
          height = (height * maxSize) / width;
          width = maxSize;
        } else if (height > maxSize) {
          width = (width * maxSize) / height;
          height = maxSize;
        }
        
        canvas.width = width;
        canvas.height = height;
        ctx?.drawImage(img, 0, 0, width, height);
        
        canvas.toBlob(
          (blob) => {
            if (blob) {
              resolve(new File([blob], file.name, {
                type: 'image/jpeg',
                lastModified: Date.now(),
              }));
            } else {
              resolve(file);
            }
          },
          'image/jpeg',
          0.75 // Optimized quality
        );
      };
      
      img.src = URL.createObjectURL(file);
    });
  }, []);

  return { compressImage };
};

// Smart form data persistence
export const useFormPersistence = () => {
  const saveFormData = useCallback((step: number, data: any) => {
    try {
      sessionStorage.setItem(`xuxu-form-${step}`, JSON.stringify(data));
    } catch (error) {
      // Graceful fallback
      console.info('Form data caching unavailable');
    }
  }, []);

  const loadFormData = useCallback((step: number) => {
    try {
      const saved = sessionStorage.getItem(`xuxu-form-${step}`);
      return saved ? JSON.parse(saved) : null;
    } catch (error) {
      return null;
    }
  }, []);

  const clearFormData = useCallback(() => {
    for (let i = 0; i < 5; i++) {
      sessionStorage.removeItem(`xuxu-form-${i}`);
    }
  }, []);

  return { saveFormData, loadFormData, clearFormData };
};

// Optimized dropdown virtualization for large lists
export const useVirtualDropdown = (items: string[], maxVisible: number = 50) => {
  const [startIndex, setStartIndex] = useState(0);
  
  const visibleItems = useMemo(() => {
    return items.slice(startIndex, startIndex + maxVisible);
  }, [items, startIndex, maxVisible]);

  const handleScroll = useCallback((scrollTop: number, itemHeight: number = 40) => {
    const newStartIndex = Math.floor(scrollTop / itemHeight);
    setStartIndex(Math.max(0, newStartIndex));
  }, []);

  return { visibleItems, handleScroll };
};

// Preload components for instant navigation
export const useComponentPreloading = () => {
  useEffect(() => {
    // Preload heavy components in the background
    const preloadComponents = async () => {
      try {
        await import('../components/registration/FacialVerification');
        await import('../components/registration/KYCValidationPopup');
        console.info('Components preloaded successfully');
      } catch (error) {
        // Silent fallback - components will load when needed
      }
    };

    const timer = setTimeout(preloadComponents, 1000);
    return () => clearTimeout(timer);
  }, []);
};

// Performance monitoring
export const usePerformanceTracking = () => {
  const trackFieldLoad = useCallback((fieldName: string) => {
    const now = performance.now();
    console.debug(`Field ${fieldName} loaded in ${now.toFixed(2)}ms`);
  }, []);

  const trackFormSubmission = useCallback(() => {
    const now = performance.now();
    console.debug(`Form submission initiated at ${now.toFixed(2)}ms`);
  }, []);

  return { trackFieldLoad, trackFormSubmission };
};