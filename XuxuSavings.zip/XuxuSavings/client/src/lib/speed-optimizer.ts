import { useCallback, useMemo, useRef, useEffect, useState, lazy } from "react";

// Ultra-fast image compression with quality optimization
export const useSpeedyImageCompression = () => {
  const compressImage = useCallback(async (file: File): Promise<File> => {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d')!;
      const img = new Image();
      
      img.onload = () => {
        // Calculate optimal dimensions (max 800px width/height)
        const maxSize = 800;
        let { width, height } = img;
        
        if (width > height && width > maxSize) {
          height = (height * maxSize) / width;
          width = maxSize;
        } else if (height > maxSize) {
          width = (width * maxSize) / height;
          height = maxSize;
        }
        
        canvas.width = width;
        canvas.height = height;
        
        // Draw with high quality settings
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, width, height);
        
        canvas.toBlob((blob) => {
          if (blob) {
            const compressedFile = new File([blob], file.name, {
              type: 'image/jpeg',
              lastModified: Date.now(),
            });
            resolve(compressedFile);
          } else {
            resolve(file);
          }
        }, 'image/jpeg', 0.85);
      };
      
      img.src = URL.createObjectURL(file);
    });
  }, []);

  return { compressImage };
};

// Lightning-fast debouncing for form inputs
export const useRapidDebounce = <T extends (...args: any[]) => any>(
  callback: T,
  delay = 150
) => {
  const timeoutRef = useRef<NodeJS.Timeout>();
  
  return useCallback((...args: Parameters<T>) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    timeoutRef.current = setTimeout(() => {
      callback(...args);
    }, delay);
  }, [callback, delay]);
};

// Instant location data caching
export const useQuickLocationCache = () => {
  const cacheRef = useRef(new Map<string, any>());
  
  const getCachedData = useCallback((key: string) => {
    return cacheRef.current.get(key);
  }, []);
  
  const setCachedData = useCallback((key: string, data: any) => {
    cacheRef.current.set(key, data);
  }, []);
  
  return { getCachedData, setCachedData };
};

// Fast component preloading
export const useComponentSpeedLoader = () => {
  const [preloadedComponents, setPreloadedComponents] = useState(new Set<string>());
  
  const preloadComponent = useCallback(async (componentName: string, importFn: () => Promise<any>) => {
    if (!preloadedComponents.has(componentName)) {
      try {
        await importFn();
        setPreloadedComponents(prev => new Set(Array.from(prev).concat(componentName)));
        console.info(`Component ${componentName} preloaded successfully`);
      } catch (error) {
        console.warn(`Failed to preload component ${componentName}:`, error);
      }
    }
  }, [preloadedComponents]);
  
  return { preloadComponent, isPreloaded: (name: string) => preloadedComponents.has(name) };
};

// High-speed form validation
export const useRapidValidation = () => {
  const validationCache = useRef(new Map<string, boolean>());
  
  const validateField = useCallback((fieldName: string, value: any, validator: (val: any) => boolean) => {
    const cacheKey = `${fieldName}-${JSON.stringify(value)}`;
    
    if (validationCache.current.has(cacheKey)) {
      return validationCache.current.get(cacheKey)!;
    }
    
    const isValid = validator(value);
    validationCache.current.set(cacheKey, isValid);
    
    return isValid;
  }, []);
  
  return { validateField };
};

// Optimized dropdown virtualization
export const useVirtualDropdown = (items: string[], maxVisible = 15) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [startIndex, setStartIndex] = useState(0);
  
  const filteredItems = useMemo(() => {
    if (!searchTerm) return items;
    return items.filter(item => 
      item.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [items, searchTerm]);
  
  const visibleItems = useMemo(() => {
    return filteredItems.slice(startIndex, startIndex + maxVisible);
  }, [filteredItems, startIndex, maxVisible]);
  
  const scrollToItem = useCallback((searchChar: string) => {
    const index = filteredItems.findIndex(item => 
      item.toLowerCase().startsWith(searchChar.toLowerCase())
    );
    if (index !== -1) {
      setStartIndex(Math.max(0, index - 2));
    }
  }, [filteredItems]);
  
  return {
    visibleItems,
    filteredItems,
    searchTerm,
    setSearchTerm,
    scrollToItem,
    totalCount: filteredItems.length
  };
};

// Memory-efficient form state persistence
export const useFormSpeedPersistence = (storageKey: string) => {
  const saveFormData = useCallback((data: any) => {
    try {
      sessionStorage.setItem(storageKey, JSON.stringify(data));
    } catch (error) {
      console.warn('Failed to save form data:', error);
    }
  }, [storageKey]);
  
  const loadFormData = useCallback(() => {
    try {
      const saved = sessionStorage.getItem(storageKey);
      return saved ? JSON.parse(saved) : null;
    } catch (error) {
      console.warn('Failed to load form data:', error);
      return null;
    }
  }, [storageKey]);
  
  const clearFormData = useCallback(() => {
    try {
      sessionStorage.removeItem(storageKey);
    } catch (error) {
      console.warn('Failed to clear form data:', error);
    }
  }, [storageKey]);
  
  return { saveFormData, loadFormData, clearFormData };
};

// Performance monitoring
export const useSpeedMonitor = () => {
  const [metrics, setMetrics] = useState({
    renderTime: 0,
    loadTime: 0,
    interactionTime: 0
  });
  
  const startTimer = useCallback((label: string) => {
    performance.mark(`${label}-start`);
  }, []);
  
  const endTimer = useCallback((label: string) => {
    performance.mark(`${label}-end`);
    performance.measure(label, `${label}-start`, `${label}-end`);
    
    const measure = performance.getEntriesByName(label)[0];
    setMetrics(prev => ({
      ...prev,
      [label]: measure.duration
    }));
  }, []);
  
  return { metrics, startTimer, endTimer };
};

// Critical resource preloader
export const useCriticalPreloader = () => {
  useEffect(() => {
    const preloadCriticalAssets = () => {
      // Preload critical CSS
      const link = document.createElement('link');
      link.rel = 'preload';
      link.href = '/src/index.css';
      link.as = 'style';
      document.head.appendChild(link);
      
      // Preload essential fonts
      if (document.fonts) {
        document.fonts.ready.then(() => {
          console.info('Fonts loaded successfully');
        });
      }
    };
    
    preloadCriticalAssets();
  }, []);
};

// Lazy component creator with error boundaries
export const createLazySpeedComponent = (importFn: () => Promise<any>) => {
  return lazy(importFn);
};