// Enhanced global location database with comprehensive coverage
export interface State {
  name: string;
  code: string;
  cities: string[];
}

export interface Country {
  name: string;
  code: string;
  region: string;
  states: State[];
}

export const worldwideLocationData: Country[] = [
  // NORTH AMERICA
  {
    name: "United States",
    code: "US",
    region: "North America",
    states: [
      { name: "Alabama", code: "AL", cities: ["Birmingham", "Montgomery", "Mobile", "Huntsville", "Tuscaloosa", "Hoover", "Dothan", "Auburn", "Decatur", "Madison"] },
      { name: "Alaska", code: "AK", cities: ["Anchorage", "Fairbanks", "Juneau", "Sitka", "Ketchikan", "Wasilla", "Kenai", "Kodiak", "Bethel", "Palmer"] },
      { name: "Arizona", code: "AZ", cities: ["Phoenix", "Tucson", "Mesa", "Chandler", "Scottsdale", "Glendale", "Gilbert", "Tempe", "Peoria", "Surprise"] },
      { name: "Arkansas", code: "AR", cities: ["Little Rock", "Fort Smith", "Fayetteville", "Springdale", "Jonesboro", "North Little Rock", "Conway", "Rogers", "Pine Bluff", "Bentonville"] },
      { name: "California", code: "CA", cities: ["Los Angeles", "San Diego", "San Jose", "San Francisco", "Fresno", "Sacramento", "Long Beach", "Oakland", "Bakersfield", "Anaheim"] },
      { name: "Colorado", code: "CO", cities: ["Denver", "Colorado Springs", "Aurora", "Fort Collins", "Lakewood", "Thornton", "Arvada", "Westminster", "Pueblo", "Centennial"] },
      { name: "Connecticut", code: "CT", cities: ["Bridgeport", "New Haven", "Hartford", "Stamford", "Waterbury", "Norwalk", "Danbury", "New Britain", "West Hartford", "Greenwich"] },
      { name: "Delaware", code: "DE", cities: ["Wilmington", "Dover", "Newark", "Middletown", "Smyrna", "Milford", "Seaford", "Georgetown", "Elsmere", "New Castle"] },
      { name: "Florida", code: "FL", cities: ["Jacksonville", "Miami", "Tampa", "Orlando", "St. Petersburg", "Hialeah", "Tallahassee", "Fort Lauderdale", "Port St. Lucie", "Cape Coral"] },
      { name: "Georgia", code: "GA", cities: ["Atlanta", "Columbus", "Augusta", "Savannah", "Athens", "Sandy Springs", "Roswell", "Macon", "Johns Creek", "Albany"] },
      { name: "Hawaii", code: "HI", cities: ["Honolulu", "East Honolulu", "Pearl City", "Hilo", "Kailua", "Waipahu", "Kaneohe", "Kailua-Kona", "Kahului", "Mililani"] },
      { name: "Idaho", code: "ID", cities: ["Boise", "Meridian", "Nampa", "Idaho Falls", "Pocatello", "Caldwell", "Coeur d'Alene", "Twin Falls", "Lewiston", "Post Falls"] },
      { name: "Illinois", code: "IL", cities: ["Chicago", "Aurora", "Springfield", "Peoria", "Rockford", "Elgin", "Joliet", "Naperville", "Belvidere", "Waukegan"] },
      { name: "Indiana", code: "IN", cities: ["Indianapolis", "Fort Wayne", "Evansville", "South Bend", "Carmel", "Bloomington", "Fishers", "Hammond", "Gary", "Muncie"] },
      { name: "Iowa", code: "IA", cities: ["Des Moines", "Cedar Rapids", "Davenport", "Sioux City", "Iowa City", "Waterloo", "Council Bluffs", "Ames", "West Des Moines", "Dubuque"] },
      { name: "Kansas", code: "KS", cities: ["Wichita", "Overland Park", "Kansas City", "Olathe", "Topeka", "Lawrence", "Shawnee", "Manhattan", "Lenexa", "Salina"] },
      { name: "Kentucky", code: "KY", cities: ["Louisville", "Lexington", "Bowling Green", "Owensboro", "Covington", "Hopkinsville", "Richmond", "Florence", "Georgetown", "Henderson"] },
      { name: "Louisiana", code: "LA", cities: ["New Orleans", "Baton Rouge", "Shreveport", "Lafayette", "Lake Charles", "Kenner", "Bossier City", "Monroe", "Alexandria", "Houma"] },
      { name: "Maine", code: "ME", cities: ["Portland", "Lewiston", "Bangor", "South Portland", "Auburn", "Biddeford", "Sanford", "Saco", "Augusta", "Westbrook"] },
      { name: "Maryland", code: "MD", cities: ["Baltimore", "Frederick", "Rockville", "Gaithersburg", "Bowie", "Annapolis", "Hagerstown", "Salisbury", "Greenbelt", "College Park"] },
      { name: "Massachusetts", code: "MA", cities: ["Boston", "Worcester", "Springfield", "Lowell", "Cambridge", "New Bedford", "Brockton", "Quincy", "Lynn", "Fall River"] },
      { name: "Michigan", code: "MI", cities: ["Detroit", "Grand Rapids", "Warren", "Sterling Heights", "Lansing", "Ann Arbor", "Flint", "Dearborn", "Livonia", "Troy"] },
      { name: "Minnesota", code: "MN", cities: ["Minneapolis", "Saint Paul", "Rochester", "Duluth", "Bloomington", "Brooklyn Park", "Plymouth", "Woodbury", "St. Cloud", "Eagan"] },
      { name: "Mississippi", code: "MS", cities: ["Jackson", "Gulfport", "Southaven", "Hattiesburg", "Biloxi", "Meridian", "Tupelo", "Greenville", "Columbus", "Clinton"] },
      { name: "Missouri", code: "MO", cities: ["Kansas City", "Saint Louis", "Springfield", "Independence", "Columbia", "Lee's Summit", "O'Fallon", "St. Joseph", "St. Charles", "Florissant"] },
      { name: "Montana", code: "MT", cities: ["Billings", "Missoula", "Great Falls", "Bozeman", "Butte", "Helena", "Kalispell", "Havre", "Anaconda", "Miles City"] },
      { name: "Nebraska", code: "NE", cities: ["Omaha", "Lincoln", "Bellevue", "Grand Island", "Kearney", "Fremont", "Hastings", "North Platte", "Norfolk", "Columbus"] },
      { name: "Nevada", code: "NV", cities: ["Las Vegas", "Henderson", "Reno", "North Las Vegas", "Sparks", "Carson City", "Fernley", "Elko", "Mesquite", "Boulder City"] },
      { name: "New Hampshire", code: "NH", cities: ["Manchester", "Nashua", "Concord", "Derry", "Rochester", "Salem", "Dover", "Merrimack", "Hudson", "Londonderry"] },
      { name: "New Jersey", code: "NJ", cities: ["Newark", "Jersey City", "Paterson", "Elizabeth", "Edison", "Woodbridge", "Lakewood", "Toms River", "Hamilton", "Trenton"] },
      { name: "New Mexico", code: "NM", cities: ["Albuquerque", "Las Cruces", "Rio Rancho", "Santa Fe", "Roswell", "Farmington", "Clovis", "Hobbs", "Alamogordo", "Carlsbad"] },
      { name: "New York", code: "NY", cities: ["New York City", "Buffalo", "Rochester", "Yonkers", "Syracuse", "Albany", "New Rochelle", "Mount Vernon", "Schenectady", "Utica"] },
      { name: "North Carolina", code: "NC", cities: ["Charlotte", "Raleigh", "Greensboro", "Durham", "Winston-Salem", "Fayetteville", "Cary", "Wilmington", "High Point", "Concord"] },
      { name: "North Dakota", code: "ND", cities: ["Fargo", "Bismarck", "Grand Forks", "Minot", "West Fargo", "Williston", "Dickinson", "Mandan", "Jamestown", "Wahpeton"] },
      { name: "Ohio", code: "OH", cities: ["Columbus", "Cleveland", "Cincinnati", "Toledo", "Akron", "Dayton", "Parma", "Canton", "Youngstown", "Lorain"] },
      { name: "Oklahoma", code: "OK", cities: ["Oklahoma City", "Tulsa", "Norman", "Broken Arrow", "Lawton", "Edmond", "Moore", "Midwest City", "Enid", "Stillwater"] },
      { name: "Oregon", code: "OR", cities: ["Portland", "Eugene", "Salem", "Gresham", "Hillsboro", "Bend", "Beaverton", "Medford", "Springfield", "Corvallis"] },
      { name: "Pennsylvania", code: "PA", cities: ["Philadelphia", "Pittsburgh", "Allentown", "Erie", "Reading", "Scranton", "Bethlehem", "Lancaster", "Harrisburg", "Altoona"] },
      { name: "Rhode Island", code: "RI", cities: ["Providence", "Cranston", "Warwick", "Pawtucket", "East Providence", "Woonsocket", "Newport", "Central Falls", "Westerly", "Portsmouth"] },
      { name: "South Carolina", code: "SC", cities: ["Charleston", "Columbia", "North Charleston", "Mount Pleasant", "Rock Hill", "Greenville", "Summerville", "Sumter", "Goose Creek", "Hilton Head Island"] },
      { name: "South Dakota", code: "SD", cities: ["Sioux Falls", "Rapid City", "Aberdeen", "Brookings", "Watertown", "Mitchell", "Yankton", "Pierre", "Huron", "Vermillion"] },
      { name: "Tennessee", code: "TN", cities: ["Nashville", "Memphis", "Knoxville", "Chattanooga", "Clarksville", "Murfreesboro", "Franklin", "Johnson City", "Bartlett", "Hendersonville"] },
      { name: "Texas", code: "TX", cities: ["Houston", "San Antonio", "Dallas", "Austin", "Fort Worth", "El Paso", "Arlington", "Corpus Christi", "Plano", "Lubbock"] },
      { name: "Utah", code: "UT", cities: ["Salt Lake City", "West Valley City", "Provo", "West Jordan", "Orem", "Sandy", "Ogden", "St. George", "Layton", "Millcreek"] },
      { name: "Vermont", code: "VT", cities: ["Burlington", "South Burlington", "Rutland", "Barre", "Montpelier", "Winooski", "St. Albans", "Newport", "Vergennes", "Brattleboro"] },
      { name: "Virginia", code: "VA", cities: ["Virginia Beach", "Chesapeake", "Norfolk", "Richmond", "Newport News", "Alexandria", "Portsmouth", "Hampton", "Suffolk", "Roanoke"] },
      { name: "Washington", code: "WA", cities: ["Seattle", "Spokane", "Tacoma", "Vancouver", "Bellevue", "Kent", "Everett", "Renton", "Yakima", "Federal Way"] },
      { name: "West Virginia", code: "WV", cities: ["Charleston", "Huntington", "Morgantown", "Parkersburg", "Wheeling", "Martinsburg", "Fairmont", "Beckley", "Clarksburg", "Lewisburg"] },
      { name: "Wisconsin", code: "WI", cities: ["Milwaukee", "Madison", "Green Bay", "Kenosha", "Racine", "Appleton", "Waukesha", "Eau Claire", "Oshkosh", "Janesville"] },
      { name: "Wyoming", code: "WY", cities: ["Cheyenne", "Casper", "Laramie", "Gillette", "Rock Springs", "Sheridan", "Green River", "Evanston", "Riverton", "Jackson"] }
    ]
  },
  
  // CANADA
  {
    name: "Canada",
    code: "CA",
    region: "North America",
    states: [
      { name: "Alberta", code: "AB", cities: ["Calgary", "Edmonton", "Red Deer", "Lethbridge", "Medicine Hat", "Grande Prairie", "Airdrie", "Spruce Grove", "Okotoks", "Camrose"] },
      { name: "British Columbia", code: "BC", cities: ["Vancouver", "Surrey", "Burnaby", "Richmond", "Abbotsford", "Coquitlam", "Kelowna", "Saanich", "Delta", "Kamloops"] },
      { name: "Manitoba", code: "MB", cities: ["Winnipeg", "Brandon", "Steinbach", "Thompson", "Portage la Prairie", "Winkler", "Selkirk", "Morden", "Dauphin", "The Pas"] },
      { name: "New Brunswick", code: "NB", cities: ["Saint John", "Moncton", "Fredericton", "Dieppe", "Riverview", "Edmundston", "Rothesay", "Quispamsis", "Bathurst", "Miramichi"] },
      { name: "Newfoundland and Labrador", code: "NL", cities: ["St. John's", "Conception Bay South", "Mount Pearl", "Corner Brook", "Grand Falls-Windsor", "Paradise", "Gander", "Happy Valley-Goose Bay", "Torbay", "Labrador City"] },
      { name: "Nova Scotia", code: "NS", cities: ["Halifax", "Cape Breton", "Dartmouth", "Sydney", "New Glasgow", "Glace Bay", "Yarmouth", "Kentville", "Amherst", "New Waterford"] },
      { name: "Ontario", code: "ON", cities: ["Toronto", "Ottawa", "Mississauga", "Brampton", "Hamilton", "London", "Markham", "Vaughan", "Kitchener", "Windsor"] },
      { name: "Prince Edward Island", code: "PE", cities: ["Charlottetown", "Summerside", "Stratford", "Cornwall", "Montague", "Kensington", "Souris", "Alberton", "Georgetown", "Borden-Carleton"] },
      { name: "Quebec", code: "QC", cities: ["Montreal", "Quebec City", "Laval", "Gatineau", "Longueuil", "Sherbrooke", "Saguenay", "Lévis", "Trois-Rivières", "Terrebonne"] },
      { name: "Saskatchewan", code: "SK", cities: ["Saskatoon", "Regina", "Prince Albert", "Moose Jaw", "Swift Current", "North Battleford", "Yorkton", "Estevan", "Weyburn", "Lloydminster"] }
    ]
  },

  // MEXICO
  {
    name: "Mexico",
    code: "MX",
    region: "North America",
    states: [
      { name: "Mexico City", code: "CDMX", cities: ["Mexico City", "Iztapalapa", "Ecatepec", "Guadalajara", "Puebla", "Tijuana", "León", "Juárez", "Torreón", "Querétaro"] },
      { name: "Jalisco", code: "JAL", cities: ["Guadalajara", "Zapopan", "Tlaquepaque", "Tonalá", "Puerto Vallarta", "Lagos de Moreno", "El Salto", "Tlajomulco", "Tepatitlán", "Ocotlán"] },
      { name: "Nuevo León", code: "NL", cities: ["Monterrey", "Guadalupe", "San Nicolás", "Apodaca", "General Escobedo", "Santa Catarina", "San Pedro Garza García", "Cadereyta", "García", "Juárez"] },
      { name: "Puebla", code: "PUE", cities: ["Puebla", "Tehuacán", "San Martín Texmelucan", "Atlixco", "San Pedro Cholula", "Amozoc", "Tecamachalco", "Cuautlancingo", "Huauchinango", "Zacatlán"] },
      { name: "Guanajuato", code: "GTO", cities: ["León", "Irapuato", "Celaya", "Salamanca", "Guanajuato", "San Miguel de Allende", "Dolores Hidalgo", "Silao", "Pénjamo", "San Francisco del Rincón"] },
      { name: "Veracruz", code: "VER", cities: ["Veracruz", "Xalapa", "Coatzacoalcos", "Córdoba", "Papantla", "Minatitlán", "Poza Rica", "Orizaba", "Boca del Río", "Tuxpan"] }
    ]
  },

  // GUATEMALA
  {
    name: "Guatemala",
    code: "GT",
    region: "North America",
    states: [
      { name: "Guatemala", code: "GT", cities: ["Guatemala City", "Mixco", "Villa Nueva", "Petapa", "San Juan Sacatepéquez", "Villa Canales", "Fraijanes", "Amatitlán", "Santa Catarina Pinula", "San José Pinula"] },
      { name: "Quetzaltenango", code: "QZ", cities: ["Quetzaltenango", "Salcajá", "San Carlos Sija", "Sibilia", "Cabricán", "Almolonga", "Cantel", "Huitán", "Zunil", "Colomba"] },
      { name: "Escuintla", code: "ES", cities: ["Escuintla", "Santa Lucía Cotzumalguapa", "Tiquisate", "La Democracia", "Siquinalá", "Masagua", "La Gomera", "Guanagazapa", "San José", "Iztapa"] }
    ]
  },

  // CUBA
  {
    name: "Cuba",
    code: "CU",
    region: "North America",
    states: [
      { name: "Havana", code: "03", cities: ["Havana", "Arroyo Naranjo", "Boyeros", "Centro Habana", "Cerro", "Cotorro", "Diez de Octubre", "Guanabacoa", "Habana del Este", "Habana Vieja"] },
      { name: "Santiago de Cuba", code: "13", cities: ["Santiago de Cuba", "Palma Soriano", "Contramaestre", "San Luis", "Segundo Frente", "Songo-La Maya", "Mella", "Tercer Frente", "Guamá"] },
      { name: "Camagüey", code: "09", cities: ["Camagüey", "Florida", "Nuevitas", "Guáimaro", "Sibanicú", "Minas", "Santa Cruz del Sur", "Vertientes", "Jimaguayú", "Najasa"] }
    ]
  },

  // COSTA RICA
  {
    name: "Costa Rica",
    code: "CR",
    region: "North America",
    states: [
      { name: "San José", code: "SJ", cities: ["San José", "Desamparados", "Puriscal", "Tarrazú", "Aserrí", "Mora", "Goicoechea", "Santa Ana", "Alajuelita", "Vázquez de Coronado"] },
      { name: "Alajuela", code: "A", cities: ["Alajuela", "San Ramón", "Grecia", "San Mateo", "Atenas", "Naranjo", "Palmares", "Poás", "Orotina", "San Carlos"] },
      { name: "Cartago", code: "C", cities: ["Cartago", "Paraíso", "La Unión", "Jiménez", "Turrialba", "Alvarado", "Oreamuno", "El Guarco", "Tres Ríos", "Juan Viñas"] }
    ]
  },

  // PANAMA
  {
    name: "Panama",
    code: "PA",
    region: "North America",
    states: [
      { name: "Panama", code: "8", cities: ["Panama City", "San Miguelito", "Tocumen", "Las Cumbres", "Pacora", "Pedregal", "Juan Díaz", "Parque Lefevre", "Río Abajo", "Betania"] },
      { name: "Colón", code: "3", cities: ["Colón", "Cristóbal", "Sabanitas", "Cativá", "Barrio Norte", "Barrio Sur", "Nueva Providencia", "Puerto Pilón", "Espinar", "Buena Vista"] },
      { name: "Chiriquí", code: "4", cities: ["David", "Boquete", "Bugaba", "Dolega", "Gualaca", "Remedios", "Renacimiento", "San Félix", "San Lorenzo", "Tolé"] }
    ]
  },

  // BELIZE
  {
    name: "Belize",
    code: "BZ",
    region: "North America",
    states: [
      { name: "Belize", code: "BZ", cities: ["Belize City", "Ladyville", "San Pedro", "Orange Walk", "San Ignacio", "Dangriga", "Placencia", "Punta Gorda", "Corozal", "Benque Viejo"] },
      { name: "Cayo", code: "CY", cities: ["San Ignacio", "Santa Elena", "Benque Viejo del Carmen", "Bullet Tree Falls", "Cristo Rey", "Spanish Lookout", "Valley of Peace", "Georgeville", "Unitedville"] },
      { name: "Orange Walk", code: "OW", cities: ["Orange Walk", "Carmelita", "San Carlos", "Trial Farm", "August Pine Ridge", "Blue Creek", "Guinea Grass", "Indian Creek", "Shipyard"] }
    ]
  },

  // EL SALVADOR
  {
    name: "El Salvador",
    code: "SV",
    region: "North America",
    states: [
      { name: "San Salvador", code: "SS", cities: ["San Salvador", "Soyapango", "Santa Tecla", "Mejicanos", "San Marcos", "Delgado", "Ilopango", "Tonacatepeque", "Ayutuxtepeque", "Cuscatancingo"] },
      { name: "La Libertad", code: "LI", cities: ["Santa Tecla", "Antiguo Cuscatlán", "La Libertad", "Colón", "Sacacoyo", "Teotepeque", "Comasagua", "Huizúcar", "Jayaque", "Jicalapa"] },
      { name: "San Miguel", code: "SM", cities: ["San Miguel", "Chinameca", "Chapeltique", "Quelepa", "Chirilagua", "Moncagua", "Nueva Guadalupe", "Lolotique", "San Luis de la Reina", "San Antonio"] }
    ]
  },

  // HONDURAS
  {
    name: "Honduras",
    code: "HN",
    region: "North America",
    states: [
      { name: "Francisco Morazán", code: "FM", cities: ["Tegucigalpa", "Comayagüela", "Villa Adela", "Kennedy", "Los Pinos", "Villanueva", "Talanga", "Valle de Ángeles", "Santa Lucía", "San Juan de Flores"] },
      { name: "Cortés", code: "CR", cities: ["San Pedro Sula", "Choloma", "La Lima", "Villanueva", "Puerto Cortés", "Omoa", "Pimienta", "Potrerillos", "San Antonio de Cortés", "San Francisco de Yojoa"] },
      { name: "Atlántida", code: "AT", cities: ["La Ceiba", "Tela", "El Progreso", "Jutiapa", "Arizona", "Esparta", "La Masica", "San Francisco", "Yoro", "El Porvenir"] }
    ]
  },

  // NICARAGUA
  {
    name: "Nicaragua",
    code: "NI",
    region: "North America",
    states: [
      { name: "Managua", code: "MN", cities: ["Managua", "Ciudad Sandino", "Tipitapa", "Villa El Carmen", "San Rafael del Sur", "Ticuantepe", "San Francisco Libre", "Mateare", "Villa Carlos Fonseca", "El Crucero"] },
      { name: "León", code: "LE", cities: ["León", "La Paz Centro", "Nagarote", "Quezalguaque", "Santa Rosa del Peñón", "Telica", "Larreynaga", "El Sauce", "Achuapa", "El Jicaral"] },
      { name: "Granada", code: "GR", cities: ["Granada", "Nandaime", "Diriomo", "Diriá", "Masaya", "Niquinohomo", "Masatepe", "Nandasmo", "Catarina", "San Juan de Oriente"] }
    ]
  },

  // DOMINICAN REPUBLIC
  {
    name: "Dominican Republic",
    code: "DO",
    region: "North America",
    states: [
      { name: "Distrito Nacional", code: "01", cities: ["Santo Domingo", "Ciudad Nueva", "Gascue", "Zona Colonial", "Bella Vista", "Naco", "Piantini", "Serrallés", "Mirador Sur", "Los Cacicazgos"] },
      { name: "Santiago", code: "25", cities: ["Santiago", "Moca", "San José de las Matas", "Villa González", "Puñal", "Sabana Iglesia", "Baitoa", "Tamboril", "Villa Bisonó", "Licey al Medio"] },
      { name: "La Altagracia", code: "11", cities: ["Higüey", "Punta Cana", "Bávaro", "La Otra Banda", "San Rafael del Yuma", "Verón", "Macao", "Nisibón", "Cabeza de Toro", "El Cortecito"] }
    ]
  },

  // HAITI
  {
    name: "Haiti",
    code: "HT",
    region: "North America",
    states: [
      { name: "Ouest", code: "OU", cities: ["Port-au-Prince", "Carrefour", "Delmas", "Pétion-Ville", "Kenscoff", "Gressier", "Léogâne", "Grand-Goâve", "Petit-Goâve", "Croix-des-Bouquets"] },
      { name: "Artibonite", code: "AR", cities: ["Gonaïves", "Saint-Marc", "Dessalines", "Petite-Rivière", "Verrettes", "La Chapelle", "Liancourt", "Marchand", "Desdunes", "Grande-Saline"] },
      { name: "Nord", code: "ND", cities: ["Cap-Haïtien", "Fort-Dauphin", "Quartier-Morin", "Limonade", "Acul-du-Nord", "Plaine-du-Nord", "Milot", "Dondon", "Saint-Raphaël", "Bahon"] }
    ]
  },

  // JAMAICA
  {
    name: "Jamaica",
    code: "JM",
    region: "North America",
    states: [
      { name: "Kingston", code: "01", cities: ["Kingston", "Spanish Town", "Portmore", "May Pen", "Old Harbour", "Linstead", "Port Royal", "Half Way Tree", "Constant Spring", "New Kingston"] },
      { name: "Saint Andrew", code: "02", cities: ["Half Way Tree", "Papine", "Liguanea", "Cross Roads", "Meadowbrook", "Mona", "Hope Pastures", "Barbican", "Manor Park", "Stony Hill"] },
      { name: "Saint Catherine", code: "13", cities: ["Spanish Town", "Portmore", "Old Harbour", "Linstead", "Bog Walk", "Riversdale", "Ewarton", "Above Rocks", "Angels", "Lluidas Vale"] }
    ]
  },

  // TRINIDAD AND TOBAGO
  {
    name: "Trinidad and Tobago",
    code: "TT",
    region: "North America",
    states: [
      { name: "Port of Spain", code: "POS", cities: ["Port of Spain", "San Fernando", "Chaguanas", "Arima", "Point Fortin", "Laventille", "St. James", "Woodbrook", "Belmont", "Maraval"] },
      { name: "San Fernando", code: "SFO", cities: ["San Fernando", "Marabella", "Gasparillo", "Pointe-à-Pierre", "Cipero", "Pleasantville", "Palmiste", "Union Hall", "Golconda", "Tarouba"] },
      { name: "Chaguanas", code: "CHA", cities: ["Chaguanas", "Charlieville", "Cunupia", "Longdenville", "Carapichaima", "Montrose", "Endeavour", "Edinburgh", "Felicity", "Carli Bay"] }
    ]
  },

  // EUROPE  
  {
    name: "United Kingdom",
    code: "GB",
    region: "Europe",
    states: [
      { name: "England", code: "EN", cities: ["London", "Birmingham", "Manchester", "Liverpool", "Sheffield", "Bristol", "Newcastle", "Nottingham", "Southampton", "Leicester"] },
      { name: "Scotland", code: "SC", cities: ["Edinburgh", "Glasgow", "Aberdeen", "Dundee", "Stirling", "Perth", "Inverness", "Paisley", "Hamilton", "Livingston"] },
      { name: "Wales", code: "WA", cities: ["Cardiff", "Swansea", "Newport", "Wrexham", "Barry", "Caerphilly", "Bridgend", "Neath", "Port Talbot", "Cwmbran"] },
      { name: "Northern Ireland", code: "NI", cities: ["Belfast", "Derry", "Lisburn", "Newtownabbey", "Bangor", "Craigavon", "Castlereagh", "Ballymena", "Newtownards", "Carrickfergus"] }
    ]
  },

  // ASIA
  {
    name: "India",
    code: "IN",
    region: "Asia",
    states: [
      { name: "Maharashtra", code: "MH", cities: ["Mumbai", "Pune", "Nagpur", "Thane", "Nashik", "Aurangabad", "Solapur", "Amravati", "Kolhapur", "Sangli", "Malegaon", "Akola", "Latur", "Dhule", "Ahmednagar", "Chandrapur", "Parbhani", "Jalgaon", "Bhiwandi", "Nanded"] },
      { name: "Tamil Nadu", code: "TN", cities: ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem", "Tirunelveli", "Tiruppur", "Vellore", "Erode", "Thoothukudi", "Dindigul", "Thanjavur", "Ranipet", "Sivakasi", "Karur", "Udhagamandalam", "Hosur", "Nagercoil", "Kanchipuram", "Kumarakonam"] },
      { name: "Karnataka", code: "KA", cities: ["Bangalore", "Mysore", "Hubli-Dharwad", "Mangalore", "Belgaum", "Gulbarga", "Davanagere", "Bellary", "Bijapur", "Shimoga", "Tumkur", "Raichur", "Bidar", "Hospet", "Gadag-Betageri", "Udupi", "Robertson Pet", "Bhadravati", "Chitradurga", "Hassan"] },
      { name: "Gujarat", code: "GJ", cities: ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar", "Jamnagar", "Junagadh", "Gandhinagar", "Anand", "Navsari", "Morvi", "Mahesana", "Bharuch", "Vapi", "Ankleshwar", "Nadiad", "Surendranagar", "Veraval", "Idar", "Botad"] },
      { name: "West Bengal", code: "WB", cities: ["Kolkata", "Howrah", "Durgapur", "Asansol", "Siliguri", "Bardhaman", "Malda", "Baharampur", "Habra", "Kharagpur", "Shantipur", "Dankuni", "Dhulian", "Ranaghat", "Haldia", "Raiganj", "Krishnanagar", "Nabadwip", "Medinipur", "Jalpaiguri"] },
      { name: "Rajasthan", code: "RJ", cities: ["Jaipur", "Jodhpur", "Udaipur", "Kota", "Ajmer", "Bikaner", "Alwar", "Bharatpur", "Bhilwara", "Pali", "Sri Ganganagar", "Kishangarh", "Beawar", "Tonk", "Hanumangarh", "Sikar", "Jhunjhunu", "Barmer", "Bhiwadi", "Churu"] },
      { name: "Uttar Pradesh", code: "UP", cities: ["Lucknow", "Kanpur", "Ghaziabad", "Agra", "Varanasi", "Meerut", "Allahabad", "Bareilly", "Aligarh", "Moradabad", "Saharanpur", "Gorakhpur", "Noida", "Firozabad", "Jhansi", "Muzaffarnagar", "Mathura", "Rampur", "Shahjahanpur", "Farrukhabad"] },
      { name: "Andhra Pradesh", code: "AP", cities: ["Visakhapatnam", "Vijayawada", "Guntur", "Nellore", "Kurnool", "Rajahmundry", "Tirupati", "Kakinada", "Anantapur", "Vizianagaram", "Eluru", "Ongole", "Nandyal", "Machilipatnam", "Adoni", "Tenali", "Chittoor", "Hindupur", "Bhimavaram", "Madanapalle"] },
      { name: "Kerala", code: "KL", cities: ["Thiruvananthapuram", "Kochi", "Kozhikode", "Thrissur", "Kollam", "Palakkad", "Alappuzha", "Malappuram", "Kannur", "Kasaragod", "Thalassery", "Ponnani", "Vatakara", "Kanhangad", "Payyanur", "Koyilandy", "Parappanangadi", "Kalamassery", "Neyyattinkara", "Kayamkulam"] },
      { name: "Punjab", code: "PB", cities: ["Ludhiana", "Amritsar", "Jalandhar", "Patiala", "Bathinda", "Mohali", "Firozpur", "Batala", "Pathankot", "Moga", "Abohar", "Malerkotla", "Khanna", "Phagwara", "Muktsar", "Barnala", "Rajpura", "Hoshiarpur", "Kapurthala", "Faridkot"] },
      { name: "Haryana", code: "HR", cities: ["Faridabad", "Gurgaon", "Panipat", "Ambala", "Yamunanagar", "Rohtak", "Hisar", "Karnal", "Sonipat", "Kaithal", "Sirsa", "Bahadurgarh", "Jind", "Thanesar", "Karnāl", "Rewari", "Narnaul", "Pundri", "Kosli", "Palwal"] }
    ]
  },

  // SOUTH AMERICA
  {
    name: "Brazil",
    code: "BR",
    region: "South America",
    states: [
      { name: "São Paulo", code: "SP", cities: ["São Paulo", "Guarulhos", "Campinas", "São Bernardo do Campo", "Santo André", "Osasco", "Ribeirão Preto", "Sorocaba", "Mauá", "São José dos Campos", "Diadema", "Jundiaí", "Carapicuíba", "Piracicaba", "Bauru", "São Vicente", "Franca", "Itaquaquecetuba", "Guarujá", "Taubaté"] },
      { name: "Rio de Janeiro", code: "RJ", cities: ["Rio de Janeiro", "São Gonçalo", "Duque de Caxias", "Nova Iguaçu", "Niterói", "Belford Roxo", "São João de Meriti", "Campos dos Goytacazes", "Petrópolis", "Volta Redonda", "Magé", "Macaé", "Itaboraí", "Cabo Frio", "Angra dos Reis", "Nova Friburgo", "Barra Mansa", "Teresópolis", "Mesquita", "Nilópolis"] },
      { name: "Minas Gerais", code: "MG", cities: ["Belo Horizonte", "Uberlândia", "Contagem", "Juiz de Fora", "Betim", "Montes Claros", "Ribeirão das Neves", "Uberaba", "Governador Valadares", "Ipatinga", "Santa Luzia", "Sete Lagoas", "Divinópolis", "Ibirité", "Poços de Caldas", "Patos de Minas", "Teófilo Otoni", "Sabará", "Pouso Alegre", "Barbacena"] },
      { name: "Bahia", code: "BA", cities: ["Salvador", "Feira de Santana", "Vitória da Conquista", "Camaçari", "Juazeiro", "Ilhéus", "Itabuna", "Lauro de Freitas", "Jequié", "Teixeira de Freitas", "Alagoinhas", "Porto Seguro", "Simões Filho", "Paulo Afonso", "Eunápolis", "Candeias", "Guanambi", "Jacobina", "Serrinha", "Senhor do Bonfim"] },
      { name: "Paraná", code: "PR", cities: ["Curitiba", "Londrina", "Maringá", "Ponta Grossa", "Cascavel", "São José dos Pinhais", "Foz do Iguaçu", "Colombo", "Guarapuava", "Paranaguá", "Araucária", "Toledo", "Apucarana", "Pinhais", "Campo Largo", "Arapongas", "Almirante Tamandaré", "Umuarama", "Paranavaí", "Cambé"] },
      { name: "Rio Grande do Sul", code: "RS", cities: ["Porto Alegre", "Caxias do Sul", "Pelotas", "Canoas", "Santa Maria", "Gravataí", "Viamão", "Novo Hamburgo", "São Leopoldo", "Rio Grande", "Alvorada", "Passo Fundo", "Sapucaia do Sul", "Uruguaiana", "Santa Cruz do Sul", "Cachoeirinha", "Bagé", "Bento Gonçalves", "Erechim", "Guaíba"] },
      { name: "Ceará", code: "CE", cities: ["Fortaleza", "Caucaia", "Juazeiro do Norte", "Maracanaú", "Sobral", "Crato", "Itapipoca", "Maranguape", "Iguatu", "Quixadá", "Canindé", "Aquiraz", "Pacajus", "Crateús", "Cascavel", "Pacatuba", "Icó", "Horizonte", "Camocim", "Morada Nova"] },
      { name: "Pernambuco", code: "PE", cities: ["Recife", "Jaboatão dos Guararapes", "Olinda", "Caruaru", "Petrolina", "Paulista", "Cabo de Santo Agostinho", "Camaragibe", "Garanhuns", "Vitória de Santo Antão", "Igarassu", "São Lourenço da Mata", "Santa Cruz do Capibaribe", "Abreu e Lima", "Ipojuca", "Serra Talhada", "Araripina", "Gravatá", "Carpina", "Goiana"] },
      { name: "Pará", code: "PA", cities: ["Belém", "Ananindeua", "Santarém", "Marabá", "Parauapebas", "Castanhal", "Abaetetuba", "Cametá", "Bragança", "Marituba", "Tucuruí", "Benevides", "Paragominas", "Redenção", "Altamira", "Itaituba", "Barcarena", "Tailândia", "Oriximiná", "Capanema"] }
    ]
  },
  {
    name: "Argentina",
    code: "AR",
    region: "South America",
    states: [
      { name: "Buenos Aires", code: "BA", cities: ["Buenos Aires", "La Plata", "Mar del Plata", "Bahía Blanca", "Tandil", "Olavarría", "Pergamino", "Junín", "Azul", "Necochea"] },
      { name: "Córdoba", code: "CB", cities: ["Córdoba", "Villa María", "Río Cuarto", "San Francisco", "Villa Carlos Paz", "Alta Gracia", "Jesús María", "Marcos Juárez", "Bell Ville", "La Carlota"] },
      { name: "Santa Fe", code: "SF", cities: ["Rosario", "Santa Fe", "Rafaela", "Venado Tuerto", "Reconquista", "Gálvez", "Casilda", "Esperanza", "Santo Tomé", "Villa Gobernador Gálvez"] },
      { name: "Mendoza", code: "MZ", cities: ["Mendoza", "San Rafael", "Godoy Cruz", "Guaymallén", "Maipú", "Las Heras", "San Martín", "Rivadavia", "Luján de Cuyo", "Tupungato"] }
    ]
  },
  {
    name: "Colombia",
    code: "CO",
    region: "South America",
    states: [
      { name: "Bogotá D.C.", code: "DC", cities: ["Bogotá", "Suba", "Kennedy", "Engativá", "Soacha", "Bosa", "San Cristóbal", "Ciudad Bolívar", "Usme", "Fontibón"] },
      { name: "Antioquia", code: "ANT", cities: ["Medellín", "Itagüí", "Envigado", "Bello", "Sabaneta", "La Estrella", "Caldas", "Copacabana", "Girardota", "Barbosa"] },
      { name: "Valle del Cauca", code: "VAC", cities: ["Cali", "Palmira", "Buenaventura", "Tuluá", "Cartago", "Buga", "Jamundí", "Yumbo", "Candelaria", "Florida"] },
      { name: "Atlántico", code: "ATL", cities: ["Barranquilla", "Soledad", "Malambo", "Sabanagrande", "Puerto Colombia", "Galapa", "Baranoa", "Sabanalarga", "Santo Tomás", "Palmar de Varela"] }
    ]
  },
  {
    name: "Chile",
    code: "CL",
    region: "South America",
    states: [
      { name: "Santiago Metropolitan", code: "RM", cities: ["Santiago", "Puente Alto", "Maipú", "Las Condes", "La Florida", "Peñalolén", "San Bernardo", "Ñuñoa", "Providencia", "Vitacura"] },
      { name: "Valparaíso", code: "VS", cities: ["Valparaíso", "Viña del Mar", "Villa Alemana", "Quilpué", "San Antonio", "Limache", "Quillota", "Los Andes", "Casablanca", "Concón"] },
      { name: "Biobío", code: "BB", cities: ["Concepción", "Talcahuano", "Chiguayante", "San Pedro de la Paz", "Hualpén", "Coronel", "Los Ángeles", "Tomé", "Penco", "Lota"] }
    ]
  },
  {
    name: "Peru",
    code: "PE",
    region: "South America",
    states: [
      { name: "Lima", code: "LIM", cities: ["Lima", "Callao", "San Juan de Lurigancho", "San Martín de Porres", "Ate", "Comas", "Villa El Salvador", "Villa María del Triunfo", "San Juan de Miraflores", "Los Olivos"] },
      { name: "Arequipa", code: "ARE", cities: ["Arequipa", "Cayma", "Cerro Colorado", "Yanahuara", "Miraflores", "Paucarpata", "Mariano Melgar", "Jacobo Hunter", "Sachaca", "Tiabaya"] },
      { name: "La Libertad", code: "LAL", cities: ["Trujillo", "El Porvenir", "Florencia de Mora", "La Esperanza", "Víctor Larco Herrera", "Huanchaco", "Laredo", "Moche", "Salaverry", "Simbal"] }
    ]
  },

  // VENEZUELA
  {
    name: "Venezuela",
    code: "VE",
    region: "South America",
    states: [
      { name: "Distrito Capital", code: "DC", cities: ["Caracas", "Libertador", "Chacao", "Baruta", "Sucre", "El Hatillo", "Petare", "Catia", "Macarao", "La Vega"] },
      { name: "Miranda", code: "MI", cities: ["Los Teques", "Guarenas", "Guatire", "Charallave", "Carrizal", "San Antonio de los Altos", "Cúa", "Ocumare del Tuy", "Santa Teresa", "Caucagua"] },
      { name: "Zulia", code: "ZU", cities: ["Maracaibo", "Cabimas", "Ciudad Ojeda", "Punto Fijo", "Los Puertos de Altagracia", "Santa Rita", "La Concepción", "Lagunillas", "Bachaquero", "Tía Juana"] }
    ]
  },

  // ECUADOR
  {
    name: "Ecuador",
    code: "EC",
    region: "South America",
    states: [
      { name: "Pichincha", code: "P", cities: ["Quito", "Mejía", "Rumiñahui", "Pedro Moncayo", "Cayambe", "San Miguel de los Bancos", "Pedro Vicente Maldonado", "Puerto Quito", "Distrito Metropolitano"] },
      { name: "Guayas", code: "G", cities: ["Guayaquil", "Durán", "Milagro", "Daule", "Samborondón", "Yaguachi", "El Triunfo", "Naranjal", "Palestina", "Pedro Carbo"] },
      { name: "Manabí", code: "M", cities: ["Portoviejo", "Manta", "Chone", "Montecristi", "Jipijapa", "Bahía de Caráquez", "Calceta", "Tosagua", "Rocafuerte", "Santa Ana"] }
    ]
  },

  // BOLIVIA
  {
    name: "Bolivia",
    code: "BO",
    region: "South America",
    states: [
      { name: "La Paz", code: "LP", cities: ["La Paz", "El Alto", "Viacha", "Achocalla", "Palca", "Mecapaca", "Pucarani", "Laja", "Batallas", "Los Andes"] },
      { name: "Santa Cruz", code: "SC", cities: ["Santa Cruz de la Sierra", "Montero", "Warnes", "La Guardia", "Cotoca", "Porongo", "El Torno", "Okinawa", "Pailón", "San Ignacio"] },
      { name: "Cochabamba", code: "CB", cities: ["Cochabamba", "Quillacollo", "Sacaba", "Colcapirhua", "Vinto", "Sipe Sipe", "Tiquipaya", "Cercado", "Punata", "Cliza"] }
    ]
  },

  // URUGUAY
  {
    name: "Uruguay",
    code: "UY",
    region: "South America",
    states: [
      { name: "Montevideo", code: "MO", cities: ["Montevideo", "Ciudad Vieja", "Centro", "Cordón", "Barrio Sur", "Palermo", "Parque Rodó", "Punta Carretas", "Pocitos", "Buceo"] },
      { name: "Canelones", code: "CA", cities: ["Canelones", "Las Piedras", "Pando", "La Paz", "Progreso", "Toledo", "Tala", "Santa Lucía", "Atlántida", "Solymar"] },
      { name: "Maldonado", code: "MA", cities: ["Maldonado", "Punta del Este", "San Carlos", "Piriápolis", "Pan de Azúcar", "Aiguá", "Garzón", "Solís", "Gregorio Aznárez", "José Ignacio"] }
    ]
  },

  // PARAGUAY
  {
    name: "Paraguay",
    code: "PY",
    region: "South America",
    states: [
      { name: "Central", code: "CE", cities: ["Asunción", "Luque", "San Lorenzo", "Capiatá", "Lambaré", "Fernando de la Mora", "Mariano Roque Alonso", "Ñemby", "Villa Elisa", "San Antonio"] },
      { name: "Alto Paraná", code: "AP", cities: ["Ciudad del Este", "Hernandarias", "Presidente Franco", "Minga Guazú", "Santa Rita", "Juan León Mallorquín", "Itakyry", "Naranjal", "Yguazú", "Santa Rosa del Monday"] },
      { name: "Itapúa", code: "IT", cities: ["Encarnación", "Hohenau", "Obligado", "Bella Vista", "María Auxiliadora", "San Juan del Paraná", "Jesús", "Trinidad", "Tomás Romero Pereira", "General Delgado"] }
    ]
  },

  // GUYANA
  {
    name: "Guyana",
    code: "GY",
    region: "South America",
    states: [
      { name: "Demerara-Mahaica", code: "DE", cities: ["Georgetown", "Diamond", "Grove", "Timehri", "Soesdyke", "Land of Canaan", "Herstelling", "Bagotville", "Friendship", "Golden Grove"] },
      { name: "East Berbice-Corentyne", code: "EB", cities: ["New Amsterdam", "Rose Hall", "Skeldon", "Corriverton", "Springlands", "Port Mourant", "Albion", "Crabwood Creek", "Number 43 Village", "Corentyne"] },
      { name: "Essequibo Islands-West Demerara", code: "ES", cities: ["Parika", "Vreed-en-Hoop", "Wales", "Tuschen", "Uitvlugt", "Anna Regina", "Charity", "Adventure", "Pomeroon", "Supenaam"] }
    ]
  },

  // SURINAME
  {
    name: "Suriname",
    code: "SR",
    region: "South America",
    states: [
      { name: "Paramaribo", code: "PM", cities: ["Paramaribo", "Lelydorp", "Brokopondo", "Groningen", "Uitkijk", "Kwatta", "Nieuw Nickerie", "Flora", "Commewijne", "Burnside"] },
      { name: "Wanica", code: "WA", cities: ["Lelydorp", "Houttuin", "Koewarasan", "Saramacca", "De Nieuwe Grond", "Kwatta", "Kantoor Grond", "Sara Creek", "Domburg", "Tijgerkreek"] },
      { name: "Nickerie", code: "NI", cities: ["Nieuw Nickerie", "Wageningen", "Groot Henar", "Coronie", "Friendship", "Westgate", "Section B", "Jenny", "Katwijk", "Post Utrecht"] }
    ]
  },

  // FRENCH GUIANA
  {
    name: "French Guiana",
    code: "GF",
    region: "South America",
    states: [
      { name: "Cayenne", code: "CAY", cities: ["Cayenne", "Remire-Montjoly", "Matoury", "Kourou", "Saint-Laurent-du-Maroni", "Sinnamary", "Iracoubo", "Mana", "Apatou", "Grand-Santi"] },
      { name: "Saint-Laurent-du-Maroni", code: "SLM", cities: ["Saint-Laurent-du-Maroni", "Mana", "Apatou", "Grand-Santi", "Papaïchton", "Saül", "Maripasoula", "Antecume-Pata", "Awala-Yalimapo", "Camopi"] },
      { name: "Kourou", code: "KOU", cities: ["Kourou", "Sinnamary", "Iracoubo", "Saint-Élie", "Saül", "Regina", "Roura", "Montsinéry-Tonnegrande", "Macouria", "Centre Spatial Guyanais"] }
    ]
  },

  // EUROPE
  {
    name: "Germany",
    code: "DE",
    region: "Europe",
    states: [
      { name: "Bavaria", code: "BY", cities: ["Munich", "Nuremberg", "Augsburg", "Würzburg", "Regensburg", "Ingolstadt", "Fürth", "Erlangen", "Bayreuth", "Bamberg"] },
      { name: "North Rhine-Westphalia", code: "NW", cities: ["Cologne", "Düsseldorf", "Dortmund", "Essen", "Duisburg", "Bochum", "Wuppertal", "Bielefeld", "Bonn", "Münster"] },
      { name: "Baden-Württemberg", code: "BW", cities: ["Stuttgart", "Mannheim", "Karlsruhe", "Freiburg", "Heidelberg", "Ulm", "Heilbronn", "Pforzheim", "Reutlingen", "Ludwigsburg"] },
      { name: "Lower Saxony", code: "NI", cities: ["Hanover", "Brunswick", "Oldenburg", "Osnabrück", "Wolfsburg", "Göttingen", "Salzgitter", "Hildesheim", "Wilhelmshaven", "Peine"] },
      { name: "Hesse", code: "HE", cities: ["Frankfurt", "Wiesbaden", "Kassel", "Darmstadt", "Offenbach", "Gießen", "Marburg", "Fulda", "Rüsselsheim", "Hanau"] },
      { name: "Saxony", code: "SN", cities: ["Dresden", "Leipzig", "Chemnitz", "Zwickau", "Plauen", "Görlitz", "Freiberg", "Bautzen", "Pirna", "Meißen"] }
    ]
  },
  {
    name: "France",
    code: "FR",
    region: "Europe",
    states: [
      { name: "Île-de-France", code: "IDF", cities: ["Paris", "Boulogne-Billancourt", "Saint-Denis", "Argenteuil", "Montreuil", "Créteil", "Nanterre", "Colombes", "Aulnay-sous-Bois", "Rueil-Malmaison"] },
      { name: "Provence-Alpes-Côte d'Azur", code: "PAC", cities: ["Marseille", "Nice", "Toulon", "Aix-en-Provence", "Antibes", "Cannes", "Avignon", "Fréjus", "Arles", "Gap"] },
      { name: "Auvergne-Rhône-Alpes", code: "ARA", cities: ["Lyon", "Saint-Étienne", "Grenoble", "Villeurbanne", "Clermont-Ferrand", "Chambéry", "Valence", "Annecy", "Bourg-en-Bresse", "Roanne"] },
      { name: "Nouvelle-Aquitaine", code: "NAQ", cities: ["Bordeaux", "Limoges", "Poitiers", "Pau", "La Rochelle", "Mérignac", "Pessac", "Bayonne", "Angoulême", "Niort"] },
      { name: "Occitanie", code: "OCC", cities: ["Toulouse", "Montpellier", "Nîmes", "Perpignan", "Béziers", "Narbonne", "Carcassonne", "Albi", "Tarbes", "Auch"] },
      { name: "Hauts-de-France", code: "HDF", cities: ["Lille", "Amiens", "Tourcoing", "Roubaix", "Dunkerque", "Calais", "Villeneuve-d'Ascq", "Saint-Quentin", "Beauvais", "Compiègne"] }
    ]
  },
  {
    name: "Italy",
    code: "IT",
    region: "Europe",
    states: [
      { name: "Lombardy", code: "LOM", cities: ["Milan", "Brescia", "Monza", "Bergamo", "Varese", "Como", "Pavia", "Cremona", "Mantua", "Lecco"] },
      { name: "Lazio", code: "LAZ", cities: ["Rome", "Latina", "Guidonia Montecelio", "Fiumicino", "Aprilia", "Tivoli", "Anzio", "Pomezia", "Nettuno", "Velletri"] },
      { name: "Campania", code: "CAM", cities: ["Naples", "Salerno", "Giugliano in Campania", "Torre del Greco", "Pozzuoli", "Casoria", "Castellammare di Stabia", "Afragola", "Cava de' Tirreni", "Battipaglia"] },
      { name: "Sicily", code: "SIC", cities: ["Palermo", "Catania", "Messina", "Syracuse", "Marsala", "Gela", "Ragusa", "Trapani", "Vittoria", "Caltanissetta"] },
      { name: "Veneto", code: "VEN", cities: ["Venice", "Verona", "Padua", "Vicenza", "Treviso", "Rovigo", "Belluno", "Chioggia", "Bassano del Grappa", "San Donà di Piave"] }
    ]
  },
  {
    name: "Spain",
    code: "ES",
    region: "Europe",
    states: [
      { name: "Madrid", code: "MD", cities: ["Madrid", "Móstoles", "Alcalá de Henares", "Fuenlabrada", "Leganés", "Getafe", "Alcorcón", "Torrejón de Ardoz", "Parla", "Alcobendas"] },
      { name: "Catalonia", code: "CT", cities: ["Barcelona", "L'Hospitalet de Llobregat", "Badalona", "Terrassa", "Sabadell", "Lleida", "Tarragona", "Mataró", "Santa Coloma de Gramenet", "Reus"] },
      { name: "Valencia", code: "VC", cities: ["Valencia", "Alicante", "Elche", "Castellón de la Plana", "Torrevieja", "Orihuela", "Benidorm", "Alcoy", "Gandía", "Paterna"] },
      { name: "Andalusia", code: "AN", cities: ["Seville", "Málaga", "Córdoba", "Granada", "Jerez de la Frontera", "Almería", "Huelva", "Marbella", "Dos Hermanas", "Cádiz"] }
    ]
  },
  {
    name: "Netherlands",
    code: "NL",
    region: "Europe",
    states: [
      { name: "North Holland", code: "NH", cities: ["Amsterdam", "Haarlem", "Zaanstad", "Haarlemmermeer", "Alkmaar", "Hilversum", "Amstelveen", "Purmerend", "Hoorn", "Velsen"] },
      { name: "South Holland", code: "ZH", cities: ["The Hague", "Rotterdam", "Leiden", "Dordrecht", "Zoetermeer", "Delft", "Alphen aan den Rijn", "Westland", "Gouda", "Spijkenisse"] },
      { name: "North Brabant", code: "NB", cities: ["Eindhoven", "Tilburg", "Breda", "'s-Hertogenbosch", "Almere", "Apeldoorn", "Nijmegen", "Haarlem", "Arnhem", "Zaanstad"] },
      { name: "Utrecht", code: "UT", cities: ["Utrecht", "Amersfoort", "Veenendaal", "Nieuwegein", "Zeist", "IJsselstein", "Houten", "Vianen", "Woerden", "De Bilt"] }
    ]
  },

  // ASIA EXPANDED
  {
    name: "China",
    code: "CN",
    region: "Asia",
    states: [
      { name: "Guangdong", code: "GD", cities: ["Guangzhou", "Shenzhen", "Dongguan", "Foshan", "Zhongshan", "Zhuhai", "Jiangmen", "Huizhou", "Zhaoqing", "Shantou"] },
      { name: "Jiangsu", code: "JS", cities: ["Nanjing", "Suzhou", "Wuxi", "Changzhou", "Nantong", "Yangzhou", "Yancheng", "Huai'an", "Lianyungang", "Zhenjiang"] },
      { name: "Shandong", code: "SD", cities: ["Jinan", "Qingdao", "Yantai", "Weifang", "Zibo", "Weihai", "Dongying", "Tai'an", "Jining", "Linyi"] },
      { name: "Zhejiang", code: "ZJ", cities: ["Hangzhou", "Ningbo", "Wenzhou", "Shaoxing", "Huzhou", "Jiaxing", "Jinhua", "Quzhou", "Zhoushan", "Taizhou"] },
      { name: "Henan", code: "HA", cities: ["Zhengzhou", "Luoyang", "Kaifeng", "Anyang", "Xinyang", "Nanyang", "Zhumadian", "Shangqiu", "Xinxiang", "Jiaozuo"] },
      { name: "Sichuan", code: "SC", cities: ["Chengdu", "Mianyang", "Deyang", "Nanchong", "Yibin", "Zigong", "Luzhou", "Dazhou", "Leshan", "Neijiang"] }
    ]
  },
  {
    name: "Japan",
    code: "JP",
    region: "Asia",
    states: [
      { name: "Tokyo", code: "13", cities: ["Tokyo", "Hachioji", "Tachikawa", "Musashino", "Mitaka", "Ome", "Fuchu", "Akishima", "Chofu", "Machida"] },
      { name: "Osaka", code: "27", cities: ["Osaka", "Sakai", "Higashiosaka", "Hirakata", "Toyonaka", "Takatsuki", "Suita", "Yao", "Neyagawa", "Kishiwada"] },
      { name: "Kanagawa", code: "14", cities: ["Yokohama", "Kawasaki", "Sagamihara", "Fujisawa", "Chigasaki", "Hiratsuka", "Odawara", "Machida", "Yamato", "Atsugi"] },
      { name: "Aichi", code: "23", cities: ["Nagoya", "Toyota", "Okazaki", "Kasugai", "Ichinomiya", "Anjo", "Komaki", "Kariya", "Tokai", "Inazawa"] },
      { name: "Saitama", code: "11", cities: ["Saitama", "Kawaguchi", "Kawagoe", "Tokorozawa", "Koshigaya", "Kuki", "Ageo", "Kasukabe", "Kumagaya", "Iruma"] },
      { name: "Chiba", code: "12", cities: ["Chiba", "Funabashi", "Matsudo", "Ichikawa", "Kashiwa", "Ichihara", "Yachiyo", "Narashino", "Kamagaya", "Kisarazu"] }
    ]
  },
  {
    name: "South Korea",
    code: "KR",
    region: "Asia",
    states: [
      { name: "Seoul", code: "11", cities: ["Seoul", "Gangnam", "Gangdong", "Gangbuk", "Gangseo", "Gwanak", "Gwangjin", "Guro", "Geumcheon", "Nowon"] },
      { name: "Busan", code: "26", cities: ["Busan", "Haeundae", "Nam", "Dong", "Busanjin", "Buk", "Sasang", "Saha", "Yeonje", "Suyeong"] },
      { name: "Gyeonggi", code: "41", cities: ["Suwon", "Seongnam", "Goyang", "Yongin", "Bucheon", "Ansan", "Cheoin", "Anyang", "Hwaseong", "Namyang"] },
      { name: "Incheon", code: "28", cities: ["Incheon", "Yeonsu", "Namdong", "Bupyeong", "Seo", "Nam", "Dong", "Jung", "Gyeyang", "Ganghwa"] }
    ]
  },
  {
    name: "Indonesia",
    code: "ID",
    region: "Asia",
    states: [
      { name: "Jakarta", code: "JK", cities: ["Jakarta", "South Jakarta", "East Jakarta", "West Jakarta", "North Jakarta", "Central Jakarta", "Bekasi", "Tangerang", "Depok", "Bogor"] },
      { name: "West Java", code: "JB", cities: ["Bandung", "Bekasi", "Depok", "Bogor", "Cimahi", "Tasikmalaya", "Banjar", "Sukabumi", "Cirebon", "Garut"] },
      { name: "East Java", code: "JI", cities: ["Surabaya", "Malang", "Kediri", "Blitar", "Mojokerto", "Madiun", "Pasuruan", "Probolinggo", "Batu", "Sidoarjo"] },
      { name: "Central Java", code: "JT", cities: ["Semarang", "Surakarta", "Salatiga", "Pekalongan", "Tegal", "Magelang", "Kudus", "Purwokerto", "Klaten", "Karanganyar"] }
    ]
  },
  {
    name: "Thailand",
    code: "TH",
    region: "Asia",
    states: [
      { name: "Bangkok", code: "10", cities: ["Bangkok", "Thonburi", "Dusit", "Bang Rak", "Samphanthawong", "Phaya Thai", "Ratchathewi", "Pathum Wan", "Pom Prap Sattru Phai", "Huai Khwang"] },
      { name: "Chiang Mai", code: "50", cities: ["Chiang Mai", "San Kamphaeng", "San Sai", "Doi Saket", "Mae Taeng", "Mae Rim", "Hang Dong", "Hot", "Doi Tao", "Omgoi"] },
      { name: "Phuket", code: "83", cities: ["Phuket City", "Patong", "Kathu", "Chalong", "Rawai", "Kamala", "Surin", "Bang Tao", "Nai Harn", "Karon"] }
    ]
  },

  // AFRICA EXPANDED
  {
    name: "Nigeria",
    code: "NG",
    region: "Africa",
    states: [
      { name: "Lagos", code: "LA", cities: ["Lagos", "Ikeja", "Ikorodu", "Epe", "Badagry", "Mushin", "Alimosho", "Agege", "Kosofe", "Oshodi"] },
      { name: "Kano", code: "KN", cities: ["Kano", "Fagge", "Dala", "Gwale", "Tarauni", "Nassarawa", "Municipal", "Ungogo", "Kumbotso", "Warawa"] },
      { name: "Rivers", code: "RI", cities: ["Port Harcourt", "Obio-Akpor", "Okrika", "Ogu–Bolo", "Eleme", "Tai", "Gokana", "Oyigbo", "Opobo–Nkoro", "Andoni"] },
      { name: "Kaduna", code: "KD", cities: ["Kaduna", "Zaria", "Kafanchan", "Kagoro", "Zonkwa", "Makarfi", "Sabon Gari", "Giwa", "Lere", "Kudan"] },
      { name: "Oyo", code: "OY", cities: ["Ibadan", "Ogbomoso", "Oyo", "Iseyin", "Eruwa", "Igboho", "Shaki", "Lalupon", "Kishi", "Saki"] }
    ]
  },
  {
    name: "South Africa",
    code: "ZA",
    region: "Africa",
    states: [
      { name: "Gauteng", code: "GP", cities: ["Johannesburg", "Pretoria", "Soweto", "Ekurhuleni", "Tembisa", "Germiston", "Randburg", "Sandton", "Benoni", "Boksburg"] },
      { name: "Western Cape", code: "WC", cities: ["Cape Town", "Bellville", "Mitchell's Plain", "Khayelitsha", "Somerset West", "George", "Wynberg", "Constantia", "Strand", "Goodwood"] },
      { name: "KwaZulu-Natal", code: "KZN", cities: ["Durban", "Pietermaritzburg", "Pinetown", "Chatsworth", "Umlazi", "Newcastle", "Ladysmith", "Richards Bay", "Empangeni", "Vryheid"] }
    ]
  },
  {
    name: "Egypt",
    code: "EG",
    region: "Africa",
    states: [
      { name: "Cairo", code: "C", cities: ["Cairo", "Giza", "Shubra El Kheima", "Port Said", "Suez", "Luxor", "al-Mahallah al-Kubra", "Tanta", "Asyut", "Ismailia"] },
      { name: "Alexandria", code: "ALX", cities: ["Alexandria", "Damanhur", "Kafr el-Dawwar", "Rashid", "Edko", "Abu Qir", "Idku", "Mahmudiyya", "Kafr Abd al Dayim", "Sidi Salim"] },
      { name: "Giza", code: "GZ", cities: ["Giza", "6th of October City", "Sheikh Zayed City", "Badrashin", "Al Badrashein", "Atfih", "Al Saff", "Ausim", "Kerdasa", "Abu Rawash"] }
    ]
  },
  {
    name: "Kenya",
    code: "KE",
    region: "Africa",
    states: [
      { name: "Nairobi", code: "30", cities: ["Nairobi", "Kasarani", "Embakasi", "Makadara", "Kamukunji", "Starehe", "Langata", "Dagoretti", "Westlands", "Mathare"] },
      { name: "Mombasa", code: "28", cities: ["Mombasa", "Nyali", "Changamwe", "Jomba", "Chaani", "Miritini", "Mikindani", "Junda", "Bamburi", "Shanzu"] },
      { name: "Kiambu", code: "22", cities: ["Thika", "Ruiru", "Kikuyu", "Limuru", "Tigoni", "Karuri", "Githunguri", "Kiambu", "Gatundu", "Lari"] }
    ]
  },
  {
    name: "Morocco",
    code: "MA",
    region: "Africa",
    states: [
      { name: "Casablanca-Settat", code: "06", cities: ["Casablanca", "Salé", "Mohammedia", "Berrechid", "Settat", "El Jadida", "Khouribga", "Sidi Bennour", "Azemmour", "Skhirate"] },
      { name: "Rabat-Salé-Kénitra", code: "04", cities: ["Rabat", "Salé", "Kénitra", "Khémisset", "Sidi Kacem", "Sidi Slimane", "Souk Larbaa", "Temara", "Tiflet", "Mechraa Bel Ksiri"] },
      { name: "Marrakesh-Safi", code: "07", cities: ["Marrakesh", "Safi", "Essaouira", "Kelaa des Sraghna", "Chichaoua", "Youssoufia", "Sidi Bennour", "El Haouz", "Rehamna", "Chtouka Ait Baha"] }
    ]
  },
  {
    name: "Ghana",
    code: "GH",
    region: "Africa",
    states: [
      { name: "Greater Accra", code: "AA", cities: ["Accra", "Tema", "Ashaiman", "Madina", "Adenta", "Kasoa", "Dansoman", "Nungua", "Teshie", "La"] },
      { name: "Ashanti", code: "AH", cities: ["Kumasi", "Obuasi", "Ejisu", "Mampong", "Konongo", "Bekwai", "Offinso", "Tepa", "Atwima Nwabiagya", "Ahafo Ano North"] },
      { name: "Western", code: "WP", cities: ["Sekondi-Takoradi", "Tarkwa", "Axim", "Elubo", "Prestea", "Bogoso", "Dunkwa-on-Offin", "Sefwi Wiawso", "Enchi", "Daboase"] }
    ]
  },

  // ETHIOPIA
  {
    name: "Ethiopia",
    code: "ET",
    region: "Africa",
    states: [
      { name: "Addis Ababa", code: "AA", cities: ["Addis Ababa", "Arada", "Addis Ketema", "Akaky Kaliti", "Bole", "Gullele", "Kirkos", "Kolfe Keranio", "Lideta", "Nifas Silk-Lafto"] },
      { name: "Oromia", code: "OR", cities: ["Adama", "Jimma", "Bishoftu", "Shashamane", "Hawassa", "Dire Dawa", "Bahir Dar", "Dessie", "Kombolcha", "Nekemte"] },
      { name: "Amhara", code: "AM", cities: ["Bahir Dar", "Gondar", "Dessie", "Kombolcha", "Debre Markos", "Debre Birhan", "Woldia", "Lalibela", "Weldiya", "Kemise"] }
    ]
  },

  // DEMOCRATIC REPUBLIC OF CONGO
  {
    name: "Democratic Republic of Congo",
    code: "CD",
    region: "Africa",
    states: [
      { name: "Kinshasa", code: "KN", cities: ["Kinshasa", "Gombe", "Kalamu", "Lemba", "Limete", "Lingwala", "Kasa-Vubu", "Bandalungwa", "Bumbu", "Kimbanseke"] },
      { name: "North Kivu", code: "NK", cities: ["Goma", "Butembo", "Beni", "Rutshuru", "Masisi", "Walikale", "Lubero", "Nyiragongo", "Karisimbi", "Bwisha"] },
      { name: "South Kivu", code: "SK", cities: ["Bukavu", "Uvira", "Kamituga", "Minova", "Walungu", "Kabare", "Kalehe", "Shabunda", "Mwenga", "Fizi"] }
    ]
  },

  // UGANDA
  {
    name: "Uganda",
    code: "UG",
    region: "Africa",
    states: [
      { name: "Central Region", code: "C", cities: ["Kampala", "Entebbe", "Mukono", "Jinja", "Masaka", "Mbarara", "Wakiso", "Mpigi", "Luwero", "Mityana"] },
      { name: "Eastern Region", code: "E", cities: ["Jinja", "Mbale", "Soroti", "Tororo", "Iganga", "Pallisa", "Busia", "Kamuli", "Kumi", "Katakwi"] },
      { name: "Northern Region", code: "N", cities: ["Gulu", "Lira", "Arua", "Kitgum", "Pader", "Apac", "Adjumani", "Moyo", "Yumbe", "Kotido"] }
    ]
  },

  // TANZANIA
  {
    name: "Tanzania",
    code: "TZ",
    region: "Africa",
    states: [
      { name: "Dar es Salaam", code: "02", cities: ["Dar es Salaam", "Kinondoni", "Ilala", "Temeke", "Ubungo", "Kigamboni", "Kawe", "Msimbazi", "Kariakoo", "Mbagala"] },
      { name: "Arusha", code: "01", cities: ["Arusha", "Moshi", "Karatu", "Mbulu", "Monduli", "Ngorongoro", "Longido", "Simanjiro", "Meru", "Usa River"] },
      { name: "Mwanza", code: "18", cities: ["Mwanza", "Musoma", "Bukoba", "Shinyanga", "Kahama", "Geita", "Sengerema", "Kwimba", "Magu", "Ilemela"] }
    ]
  },

  // MADAGASCAR
  {
    name: "Madagascar",
    code: "MG",
    region: "Africa",
    states: [
      { name: "Analamanga", code: "T", cities: ["Antananarivo", "Antsirabe", "Ambatolampy", "Arivonimamo", "Soavinandriana", "Manjakandriana", "Anjozorobe", "Antanifotsy", "Tsiroanomandidy", "Miarinarivo"] },
      { name: "Vakinankaratra", code: "U", cities: ["Antsirabe", "Betafo", "Antanifotsy", "Faratsiho", "Mandoto", "Ambatolampy", "Soavinandriana", "Ankazobe", "Arivonimamo", "Miarinarivo"] },
      { name: "Atsinanana", code: "I", cities: ["Toamasina", "Vatomandry", "Mahanoro", "Brickaville", "Fenerive Est", "Soanierana Ivongo", "Mananara Nord", "Antanambao Manampontsy", "Marolambo", "Nosy Varika"] }
    ]
  },

  // CAMEROON
  {
    name: "Cameroon",
    code: "CM",
    region: "Africa",
    states: [
      { name: "Centre", code: "CE", cities: ["Yaoundé", "Mbalmayo", "Obala", "Akonolinga", "Bafia", "Nanga Eboko", "Mfou", "Monatele", "Ntui", "Elig-Mfomo"] },
      { name: "Littoral", code: "LT", cities: ["Douala", "Edéa", "Nkongsamba", "Loum", "Yabassi", "Manjo", "Dizangué", "Mouanko", "Dibombari", "Penja"] },
      { name: "West", code: "OU", cities: ["Bafoussam", "Dschang", "Mbouda", "Bandjoun", "Foumban", "Bangangté", "Bafang", "Penka-Michel", "Galim", "Kékem"] }
    ]
  },

  // IVORY COAST
  {
    name: "Ivory Coast",
    code: "CI",
    region: "Africa",
    states: [
      { name: "Lagunes", code: "06", cities: ["Abidjan", "Dabou", "Grand-Lahou", "Jacqueville", "Tiassalé", "Adzopé", "Agboville", "Alepe", "Sikensi", "Anyama"] },
      { name: "Haut-Sassandra", code: "02", cities: ["Daloa", "Issia", "Vavoua", "Zoukougbeu", "Gadouan", "Gagnoa", "Guiberoua", "Buyo", "Zuenoula", "Saioua"] },
      { name: "Savanes", code: "17", cities: ["Korhogo", "Ferkessédougou", "Sinématiali", "Boundiali", "Tengréla", "M'Bengué", "Dikodougou", "Karakoro", "Lataha", "Niellé"] }
    ]
  },

  // NIGER
  {
    name: "Niger",
    code: "NE",
    region: "Africa",
    states: [
      { name: "Niamey", code: "8", cities: ["Niamey", "Kollo", "Ouallam", "Say", "Torodi", "Balleyara", "Filingué", "Téra", "Tillabéri", "Gothèye"] },
      { name: "Maradi", code: "4", cities: ["Maradi", "Tessaoua", "Dakoro", "Mayahi", "Aguie", "Madarounfa", "Gazaoua", "Guidan Roumdji", "Bermo", "Tibiri"] },
      { name: "Zinder", code: "7", cities: ["Zinder", "Mirriah", "Magaria", "Matameye", "Gouré", "Dungass", "Kantché", "Takeita", "Tanout", "Damagaram Takaya"] }
    ]
  },

  // BURKINA FASO
  {
    name: "Burkina Faso",
    code: "BF",
    region: "Africa",
    states: [
      { name: "Centre", code: "03", cities: ["Ouagadougou", "Ziniaré", "Kombissiri", "Saponé", "Pô", "Manga", "Garango", "Zabré", "Tenkodogo", "Koupéla"] },
      { name: "Hauts-Bassins", code: "09", cities: ["Bobo-Dioulasso", "Banfora", "Dédougou", "Nouna", "Solenzo", "Tougan", "Djibasso", "Bondokuy", "Safané", "Boromo"] },
      { name: "Nord", code: "10", cities: ["Ouahigouya", "Yako", "Thiou", "Séguénéga", "Gourcy", "Titao", "Koumbri", "Namissiguima", "Pilimpikou", "Bassi"] }
    ]
  },

  // MALI
  {
    name: "Mali",
    code: "ML",
    region: "Africa",
    states: [
      { name: "Bamako", code: "BKO", cities: ["Bamako", "Kati", "Koulikoro", "Kolokani", "Nara", "Banamba", "Dioila", "Kangaba", "Yanfolila", "Mandé"] },
      { name: "Kayes", code: "1", cities: ["Kayes", "Bafoulabé", "Kéniéba", "Kita", "Nioro du Sahel", "Sadiola", "Yélimané", "Diéma", "Oussoubidiagna", "Logos"] },
      { name: "Sikasso", code: "3", cities: ["Sikasso", "Koutiala", "Bougouni", "Yanfolila", "Kolondiéba", "Kadiolo", "Yorosso", "Garalo", "Loulouni", "Niéna"] }
    ]
  },

  // SENEGAL
  {
    name: "Senegal",
    code: "SN",
    region: "Africa",
    states: [
      { name: "Dakar", code: "DK", cities: ["Dakar", "Pikine", "Guédiawaye", "Rufisque", "Bargny", "Sébikotane", "Diamniadio", "Sangalkam", "Yenne", "Sendou"] },
      { name: "Thiès", code: "TH", cities: ["Thiès", "Mbour", "Tivaouane", "Khombole", "Mboro", "Mékhé", "Pout", "Sindia", "Joal-Fadiouth", "Kayar"] },
      { name: "Saint-Louis", code: "SL", cities: ["Saint-Louis", "Dagana", "Podor", "Richard-Toll", "Rosso", "Louga", "Kébémer", "Linguère", "Sakal", "Dahra"] }
    ]
  },

  // GUINEA
  {
    name: "Guinea",
    code: "GN",
    region: "Africa",
    states: [
      { name: "Conakry", code: "C", cities: ["Conakry", "Coyah", "Dubréka", "Forécariah", "Fria", "Kindia", "Télimélé", "Mamou", "Dalaba", "Pita"] },
      { name: "Kankan", code: "K", cities: ["Kankan", "Kérouané", "Kouroussa", "Mandiana", "Siguiri", "Faranah", "Dinguiraye", "Dabola", "Kissidougou", "Gueckédou"] },
      { name: "Labé", code: "L", cities: ["Labé", "Koubia", "Lélouma", "Mali", "Tougué", "Gaoual", "Koundara", "Boké", "Boffa", "Fria"] }
    ]
  },

  // BENIN
  {
    name: "Benin",
    code: "BJ",
    region: "Africa",
    states: [
      { name: "Littoral", code: "LI", cities: ["Cotonou", "Porto-Novo", "Ouidah", "Abomey-Calavi", "Allada", "Toffo", "Zè", "Sô-Ava", "Tori-Bossito", "Kpomassè"] },
      { name: "Atlantique", code: "AQ", cities: ["Allada", "Ouidah", "Abomey-Calavi", "Toffo", "Zè", "Tori-Bossito", "Kpomassè", "Sô-Ava", "Zogbodomey", "Lalo"] },
      { name: "Ouémé", code: "OU", cities: ["Porto-Novo", "Sèmè-Kpodji", "Aguégués", "Adjarra", "Adjohoun", "Akpro-Missérété", "Avrankou", "Bonou", "Dangbo", "Sèmè-Podji"] }
    ]
  },

  // TOGO
  {
    name: "Togo",
    code: "TG",
    region: "Africa",
    states: [
      { name: "Maritime", code: "M", cities: ["Lomé", "Tsévié", "Tabligbo", "Aného", "Vogan", "Afagnan", "Kpalimé", "Atakpamé", "Sokodé", "Kara"] },
      { name: "Plateaux", code: "P", cities: ["Atakpamé", "Kpalimé", "Badou", "Kpandu", "Notsé", "Amou Oblo", "Agou", "Danyi", "Akébou", "Wawa"] },
      { name: "Centrale", code: "C", cities: ["Sokodé", "Tchamba", "Blitta", "Sotouboua", "Tchaoudjo", "Balanka", "Fazao", "Malfakassa", "Adjengré", "Boulouma"] }
    ]
  },

  // SIERRA LEONE
  {
    name: "Sierra Leone",
    code: "SL",
    region: "Africa",
    states: [
      { name: "Western Area", code: "W", cities: ["Freetown", "Waterloo", "Hastings", "Kent", "Lakka", "Tokeh", "York", "Grafton", "Wellington", "Leicester"] },
      { name: "Northern Province", code: "N", cities: ["Makeni", "Kabala", "Port Loko", "Kambia", "Lunsar", "Magburaka", "Kamakwie", "Koinadugu", "Binkolo", "Mange"] },
      { name: "Eastern Province", code: "E", cities: ["Kenema", "Koidu", "Kailahun", "Daru", "Segbwema", "Pendembu", "Bunumbu", "Boajibu", "Koindu", "Tombodu"] }
    ]
  },

  // LIBERIA
  {
    name: "Liberia",
    code: "LR",
    region: "Africa",
    states: [
      { name: "Montserrado", code: "MO", cities: ["Monrovia", "Paynesville", "Bensonville", "Careysburg", "Todee", "St. Paul River", "Arthington", "Johnsonville", "Brewerville", "Clay-Ashland"] },
      { name: "Nimba", code: "NI", cities: ["Sanniquellie", "Ganta", "Saclepea", "Yekepa", "Karnplay", "Bahn", "Buutuo", "Tappita", "Flumpa", "Gbapa"] },
      { name: "Grand Bassa", code: "GB", cities: ["Buchanan", "Edina", "Owensgrove", "Compound #3", "Rivercess", "Neezoke", "St. John River", "Bong Mines", "Harbel", "Kakata"] }
    ]
  },

  // GAMBIA
  {
    name: "Gambia",
    code: "GM",
    region: "Africa",
    states: [
      { name: "Banjul", code: "B", cities: ["Banjul", "Bakau", "Brikama", "Serrekunda", "Sukuta", "Gunjur", "Lamin", "Yundum", "Bijilo", "Kololi"] },
      { name: "Western", code: "W", cities: ["Brikama", "Gunjur", "Sukuta", "Yundum", "Lamin", "Tujereng", "Sanyang", "Tanji", "Kartong", "Marakissa"] },
      { name: "North Bank", code: "N", cities: ["Kerewan", "Farafenni", "Essau", "Amdalai", "Bambali", "Albreda", "Jokadu", "Njaba Kunda", "Pakau", "Upper Nuimi"] }
    ]
  },

  // GUINEA-BISSAU
  {
    name: "Guinea-Bissau",
    code: "GW",
    region: "Africa",
    states: [
      { name: "Bissau", code: "BS", cities: ["Bissau", "Bissau Velho", "Antula", "Bolama", "Bubaque", "Canchungo", "Cacheu", "Mansôa", "Fulacunda", "Quinhámel"] },
      { name: "Gabú", code: "GA", cities: ["Gabú", "Bafatá", "Pirada", "Bambadinca", "Contuboel", "Sonaco", "Xitole", "Pitche", "Cosse", "Boé"] },
      { name: "Bafatá", code: "BA", cities: ["Bafatá", "Bambadinca", "Contuboel", "Gamamundo", "Xitole", "Galomaro", "Cosse", "Cossé", "Saltinho", "Bafatá Oio"] }
    ]
  },

  // CAPE VERDE
  {
    name: "Cape Verde",
    code: "CV",
    region: "Africa",
    states: [
      { name: "Santiago", code: "S", cities: ["Praia", "Assomada", "Cidade Velha", "São Domingos", "Tarrafal", "Santa Catarina", "Ribeira Grande", "São Lourenço", "São Salvador", "Pedra Badejo"] },
      { name: "São Vicente", code: "SV", cities: ["Mindelo", "Salamansa", "Calhau", "Baía das Gatas", "São Pedro", "Matiota", "Ribeira de Julião", "Monte Cara", "Topim", "Madeiralzinho"] },
      { name: "Sal", code: "SL", cities: ["Espargos", "Santa Maria", "Pedra de Lume", "Palmeira", "Murdeira", "Fontona", "Feijoal", "Terra Boa", "Algodoeiro", "Monte Grande"] }
    ]
  },

  // ADDITIONAL AFRICAN COUNTRIES
  {
    name: "Algeria",
    code: "DZ",
    region: "Africa",
    states: [
      { name: "Algiers", code: "16", cities: ["Algiers", "Dar El Beida", "Bab Ezzouar", "Draria", "Baraki", "El Achour", "Bordj El Kiffan", "Rouiba", "Reghaïa", "Zeralda"] },
      { name: "Oran", code: "31", cities: ["Oran", "Es Senia", "Bir El Djir", "Sidi Chami", "Hassi Bounif", "Bethioua", "Marsat El Hadjadj", "Gdyel", "Hassi Mefsoukh", "Boufatis"] },
      { name: "Constantine", code: "25", cities: ["Constantine", "Ali Mendjeli", "Hamma Bouziane", "Didouche Mourad", "El Khroub", "Zighoud Youcef", "Ibn Ziad", "Messaoud Boudjeriou", "Ouled Rahmoun", "Ain Abid"] }
    ]
  },
  {
    name: "Tunisia",
    code: "TN",
    region: "Africa",
    states: [
      { name: "Tunis", code: "11", cities: ["Tunis", "Ariana", "Ben Arous", "La Manouba", "Carthage", "Sidi Bou Said", "La Marsa", "Ezzahra", "Radès", "Mégrine"] },
      { name: "Sfax", code: "61", cities: ["Sfax", "Sakiet Ezzit", "Sakiet Eddaïer", "Thyna", "Agareb", "Jebiniana", "El Hencha", "Ghraïba", "Kerkennah", "Bir Ali Ben Khalifa"] },
      { name: "Sousse", code: "51", cities: ["Sousse", "M'saken", "Kalâa Kebira", "Kalâa Seghira", "Akouda", "Hammam Sousse", "Hergla", "Enfida", "Bouficha", "Kondar"] }
    ]
  },
  {
    name: "Libya",
    code: "LY",
    region: "Africa",
    states: [
      { name: "Tripoli", code: "TB", cities: ["Tripoli", "Tajoura", "Janzour", "Zawiya", "Sabratha", "Surman", "Zliten", "Khoms", "Misrata", "Tarhuna"] },
      { name: "Benghazi", code: "BA", cities: ["Benghazi", "Al Bayda", "Derna", "Tobruk", "Ajdabiya", "Marj", "Shahat", "Tocra", "Lamluda", "Qaminis"] },
      { name: "Sabha", code: "SB", cities: ["Sabha", "Murzuq", "Ubari", "Ghat", "Wadi al Shatii", "Jufra", "Waw al Namus", "Tmassah", "Germa", "Qatrun"] }
    ]
  },
  {
    name: "Sudan",
    code: "SD",
    region: "Africa",
    states: [
      { name: "Khartoum", code: "KH", cities: ["Khartoum", "Omdurman", "Khartoum North", "Sharg an Nil", "Jabal Awliya", "Al Kalakla", "Soba", "Burri", "Khartoum East", "Mayo"] },
      { name: "Kassala", code: "KA", cities: ["Kassala", "Port Sudan", "Suakin", "Haya", "New Halfa", "Khashm el Girba", "Wad el Helou", "Telkuk", "Hamashkoreib", "Aroma"] },
      { name: "Darfur", code: "DF", cities: ["El Fasher", "Nyala", "El Geneina", "Zalingei", "Ed Daein", "Kutum", "Tawila", "Kabkabiya", "Um Keddada", "Mellit"] }
    ]
  },
  {
    name: "Chad",
    code: "TD",
    region: "Africa",
    states: [
      { name: "N'Djamena", code: "ND", cities: ["N'Djamena", "Farcha", "Goudji", "Chagoua", "Amriguébé", "Gardolé", "Kilométro Neuf", "Moursal", "Ndjari", "Abéché"] },
      { name: "Logone Occidental", code: "LO", cities: ["Moundou", "Doba", "Koumra", "Laï", "Kélo", "Pala", "Beinamar", "Baibokoum", "Bé", "Gounou Gaya"] },
      { name: "Mayo-Kebbi Est", code: "ME", cities: ["Bongor", "Fianga", "Guelendeng", "Gounou Gaya", "Kanem", "Magaria", "Maga", "Moulkou", "Rigaza", "Torrock"] }
    ]
  },
  {
    name: "Central African Republic",
    code: "CF",
    region: "Africa",
    states: [
      { name: "Bangui", code: "BGF", cities: ["Bangui", "Bimbo", "Bégoua", "PK5", "Fatima", "Kilomètre Cinq", "Lakouanga", "Boeing", "Combattant", "Galabadja"] },
      { name: "Ombella-M'Poko", code: "MP", cities: ["Bimbo", "Damara", "Boali", "Yaloké", "Bogangolo", "Bossembélé", "Bouali", "Bogoin", "Mongoumba", "Bagari"] },
      { name: "Lobaye", code: "LB", cities: ["Mbaïki", "Mongoumba", "Bogoin", "Boda", "Boganangone", "Bagandou", "Botambi", "Bossangoa", "Lokoti", "Sibut"] }
    ]
  },
  {
    name: "Republic of the Congo",
    code: "CG",
    region: "Africa",
    states: [
      { name: "Brazzaville", code: "BZV", cities: ["Brazzaville", "Bacongo", "Poto-Poto", "Moungali", "Ouenzé", "Talangaï", "Mfilou", "Madibou", "Djiri", "Kintélé"] },
      { name: "Pointe-Noire", code: "16", cities: ["Pointe-Noire", "Loandjili", "Tié-Tié", "Mvou-Mvou", "Ngoyo", "Tchimbamba", "Mongo-Mpoukou", "Vindoulou", "Mbota", "Nziou"] },
      { name: "Pool", code: "12", cities: ["Kinkala", "Boko", "Mindouli", "Goma Tsé-Tsé", "Loumo", "Mayama", "Ngamaba", "Vinza", "Mbandza-Ndounga", "Louingui"] }
    ]
  },
  {
    name: "Gabon",
    code: "GA",
    region: "Africa",
    states: [
      { name: "Estuaire", code: "1", cities: ["Libreville", "Owendo", "Akanda", "Ntoum", "Kango", "Cocobeach", "Mitzic", "Médouneu", "Bifoun", "Lambaréné"] },
      { name: "Haut-Ogooué", code: "3", cities: ["Franceville", "Moanda", "Mounana", "Okondja", "Bongoville", "Lékédi", "Bakoumba", "Akiéni", "Poubara", "Onga"] },
      { name: "Ogooué-Maritime", code: "8", cities: ["Port-Gentil", "Omboué", "Gamba", "Mayumba", "Tchibanga", "Nyanga", "Mouila", "Lambaréné", "Fougamou", "Mimongo"] }
    ]
  },
  {
    name: "Equatorial Guinea",
    code: "GQ",
    region: "Africa",
    states: [
      { name: "Bioko Norte", code: "BN", cities: ["Malabo", "Rebola", "Sipopo", "Ela Nguema", "Baney", "Sampaka", "Basacato del Oeste", "Basacato del Este", "Basupu", "Bakake Grande"] },
      { name: "Río Muni", code: "RM", cities: ["Bata", "Mbini", "Acurenam", "Cogo", "Evinayong", "Mongomo", "Niefang", "Nsok", "Ayene", "Acalayong"] },
      { name: "Annobón", code: "AN", cities: ["San Antonio de Palé", "Mabana", "Anganchi", "Bokoco", "Buela", "Conceição", "Covete", "Cruz", "Palé", "San Pedro"] }
    ]
  },
  {
    name: "São Tomé and Príncipe",
    code: "ST",
    region: "Africa",
    states: [
      { name: "São Tomé", code: "S", cities: ["São Tomé", "Trindade", "Santana", "Guadalupe", "Pantufo", "Riboque", "Neves", "Santa Catarina", "Água Grande", "Cantagalo"] },
      { name: "Príncipe", code: "P", cities: ["Santo António", "Porto Real", "Terreiro Velho", "Paciência", "Picão", "Abade", "Bela Vista", "Sundy", "São Joaquim", "Ribeira Afonso"] }
    ]
  },

  // ADDITIONAL AFRICAN COUNTRIES (completing all 54 African countries)
  {
    name: "Angola",
    code: "AO",
    region: "Africa",
    states: [
      { name: "Luanda", code: "LUA", cities: ["Luanda", "Viana", "Cacuaco", "Belas", "Talatona", "Kilamba", "Maianga", "Ingombota", "Sambizanga", "Rangel"] },
      { name: "Huíla", code: "HUI", cities: ["Lubango", "Matala", "Chibia", "Humpata", "Quilengues", "Caconda", "Caluquembe", "Chicomba", "Jamba", "Cuvango"] },
      { name: "Benguela", code: "BGU", cities: ["Benguela", "Lobito", "Catumbela", "Cubal", "Ganda", "Baía Farta", "Chongoroi", "Bocoio", "Caimbambo", "Balombo"] }
    ]
  },
  {
    name: "Zambia",
    code: "ZM",
    region: "Africa",
    states: [
      { name: "Lusaka", code: "09", cities: ["Lusaka", "Kafue", "Chilanga", "Chongwe", "Luangwa", "Rufunsa", "Shibuyunji", "Chirundu", "Chisamba", "Chibombo"] },
      { name: "Copperbelt", code: "08", cities: ["Ndola", "Kitwe", "Chingola", "Mufulira", "Luanshya", "Kalulushi", "Chililabombwe", "Chambishi", "Konkola", "Mpongwe"] },
      { name: "Northern", code: "05", cities: ["Kasama", "Mbala", "Mpika", "Luwingu", "Mporokoso", "Nakonde", "Chilubi", "Kaputa", "Nsama", "Senga Hill"] }
    ]
  },
  {
    name: "Zimbabwe",
    code: "ZW",
    region: "Africa",
    states: [
      { name: "Harare", code: "HA", cities: ["Harare", "Chitungwiza", "Epworth", "Ruwa", "Norton", "Mazowe", "Goromonzi", "Seke", "Zvimba", "Bindura"] },
      { name: "Bulawayo", code: "BU", cities: ["Bulawayo", "Pumula", "Entumbane", "Nkulumane", "Cowdray Park", "Luveve", "Emganwini", "Nketa", "Magwegwe", "Tshabalala"] },
      { name: "Manicaland", code: "MA", cities: ["Mutare", "Rusape", "Chipinge", "Nyanga", "Makoni", "Buhera", "Chimanimani", "Headlands", "Odzi", "Penhalonga"] }
    ]
  },
  {
    name: "Botswana",
    code: "BW",
    region: "Africa",
    states: [
      { name: "South-East", code: "SE", cities: ["Gaborone", "Lobatse", "Ramotswa", "Otse", "Goodhope", "Kanye", "Molepolole", "Thamaga", "Gabane", "Mmopane"] },
      { name: "North-West", code: "NW", cities: ["Maun", "Ghanzi", "Shakawe", "Gumare", "Nokaneng", "Sehithwa", "Tsau", "Toteng", "Sepupa", "Ikoga"] },
      { name: "Central", code: "CE", cities: ["Serowe", "Palapye", "Mahalapye", "Shoshong", "Machaneng", "Bobonong", "Tuli", "Tonota", "Selebi-Phikwe", "Francistown"] }
    ]
  },
  {
    name: "Namibia",
    code: "NA",
    region: "Africa",
    states: [
      { name: "Khomas", code: "KH", cities: ["Windhoek", "Rehoboth", "Okahandja", "Dordabis", "Hosea Kutako", "Klein Windhoek", "Pioneerspark", "Wanaheda", "Katutura", "Goreangab"] },
      { name: "Erongo", code: "ER", cities: ["Swakopmund", "Walvis Bay", "Henties Bay", "Usakos", "Karibib", "Omaruru", "Arandis", "Longbeach", "Mondesa", "Narraville"] },
      { name: "Oshana", code: "ON", cities: ["Oshakati", "Ondangwa", "Ongwediva", "Okatana", "Uupindi", "Omuthiya", "Okahao", "Oniipa", "Okatyali", "Onayena"] }
    ]
  },
  {
    name: "Lesotho",
    code: "LS",
    region: "Africa",
    states: [
      { name: "Maseru", code: "A", cities: ["Maseru", "Mazenod", "Roma", "Morija", "Teyateyaneng", "Quthing", "Mohale's Hoek", "Mafeteng", "Hlotse", "Butha-Buthe"] },
      { name: "Berea", code: "D", cities: ["Teyateyaneng", "Mapoteng", "Kolojane", "Makeka", "Kanana", "Malimong", "Makhaleng", "Mahobong", "Kolobe", "Motimposo"] },
      { name: "Leribe", code: "B", cities: ["Hlotse", "Maputsoe", "Pitseng", "Kolberg", "Matukeng", "Mahobong", "Pela-Tsoeu", "Tsikoane", "Moreneng", "Malaoaneng"] }
    ]
  },
  {
    name: "Eswatini",
    code: "SZ",
    region: "Africa",
    states: [
      { name: "Hhohho", code: "HH", cities: ["Mbabane", "Piggs Peak", "Motjane", "Ntfonjeni", "Magwegwe", "Malindza", "Mahlanya", "Madlangempisi", "Buhleni", "Lobamba"] },
      { name: "Manzini", code: "MA", cities: ["Manzini", "Matsapha", "Nhlangano", "Malkerns", "Luyengo", "Bhunya", "Mankayane", "Sidvokodvo", "Mahlangatja", "Mhlume"] },
      { name: "Lubombo", code: "LU", cities: ["Siteki", "Big Bend", "Lomahasha", "Simunye", "Tshaneni", "Tambankulu", "Hlane", "Mhlumeni", "Siphofaneni", "Nsoko"] }
    ]
  },
  {
    name: "Malawi",
    code: "MW",
    region: "Africa",
    states: [
      { name: "Central Region", code: "C", cities: ["Lilongwe", "Salima", "Kasungu", "Mchinji", "Nkhotakota", "Ntchisi", "Dowa", "Dedza", "Ntcheu", "Lilongwe City"] },
      { name: "Southern Region", code: "S", cities: ["Blantyre", "Zomba", "Chiradzulu", "Nsanje", "Chikwawa", "Thyolo", "Mulanje", "Phalombe", "Machinga", "Mangochi"] },
      { name: "Northern Region", code: "N", cities: ["Mzuzu", "Karonga", "Chitipa", "Rumphi", "Nkhata Bay", "Likoma", "Mzimba", "Nkhotakota", "Ekwendeni", "Embangweni"] }
    ]
  },
  {
    name: "Mozambique",
    code: "MZ",
    region: "Africa",
    states: [
      { name: "Maputo City", code: "MPM", cities: ["Maputo", "Matola", "Boane", "Marracuene", "Namaacha", "Moamba", "Magude", "Manhiça", "Matutuíne", "Costa do Sol"] },
      { name: "Gaza", code: "G", cities: ["Xai-Xai", "Chókwè", "Chibuto", "Bilene", "Manjacaze", "Guijá", "Massingir", "Chicualacuala", "Mandlakazi", "Praia do Bilene"] },
      { name: "Inhambane", code: "I", cities: ["Inhambane", "Maxixe", "Vilanculos", "Massinga", "Morrumbene", "Homoine", "Jangamo", "Inharrime", "Zavala", "Funhalouro"] }
    ]
  },
  {
    name: "Rwanda",
    code: "RW",
    region: "Africa",
    states: [
      { name: "Kigali City", code: "01", cities: ["Kigali", "Nyarugenge", "Gasabo", "Kicukiro", "Remera", "Kimisagara", "Gikondo", "Kanombe", "Kinyinya", "Kibagabaga"] },
      { name: "Eastern Province", code: "02", cities: ["Rwamagana", "Kayonza", "Kirehe", "Ngoma", "Gatsibo", "Nyagatare", "Bugesera", "Rukara", "Gahini", "Kabarondo"] },
      { name: "Northern Province", code: "03", cities: ["Musanze", "Gicumbi", "Rulindo", "Gakenke", "Burera", "Ruhengeri", "Kinigi", "Nyabihu", "Mukamira", "Cyeru"] }
    ]
  },
  {
    name: "Burundi",
    code: "BI",
    region: "Africa",
    states: [
      { name: "Bujumbura Mairie", code: "BM", cities: ["Bujumbura", "Rohero", "Buyenzi", "Bwiza", "Nyakabiga", "Kinama", "Kamenge", "Cibitoke", "Kanyosha", "Kajaga"] },
      { name: "Gitega", code: "GI", cities: ["Gitega", "Ryansoro", "Makebuko", "Gishubi", "Mutaho", "Itaba", "Bugendana", "Buraza", "Giheta", "Nyarusange"] },
      { name: "Ngozi", code: "NG", cities: ["Ngozi", "Mwumba", "Tangara", "Nyamurenza", "Ruhororo", "Kiremba", "Busiga", "Gashikanwa", "Marangara", "Mivo"] }
    ]
  },
  {
    name: "Djibouti",
    code: "DJ",
    region: "Africa",
    states: [
      { name: "Djibouti", code: "DJ", cities: ["Djibouti", "Balbala", "Arhiba", "Ambouli", "Haramous", "PK12", "Hayableh", "Douda", "Loyada", "Nagad"] },
      { name: "Ali Sabieh", code: "AS", cities: ["Ali Sabieh", "Holhol", "Assamo", "Chabelley", "Guelile", "Gobaad", "Adailou", "Dewele", "Grand Bara", "Holl-Holl"] },
      { name: "Dikhil", code: "DI", cities: ["Dikhil", "Yoboki", "As Eyla", "Galafi", "Hanlé", "Gobaad", "Day", "Agna", "Sankal", "Gaggade"] }
    ]
  },
  {
    name: "Eritrea",
    code: "ER",
    region: "Africa",
    states: [
      { name: "Maekel", code: "MA", cities: ["Asmara", "Mendefera", "Adi Quala", "Senafe", "Tsorona", "Debarwa", "Dekemhare", "Ghala Nefhi", "Serejeka", "Adi Ugri"] },
      { name: "Debub", code: "DU", cities: ["Mendefera", "Adi Quala", "Senafe", "Tsorona", "Debarwa", "Mai-Mne", "Emni Haili", "Segeneiti", "Adi Keih", "Mareb"] },
      { name: "Gash-Barka", code: "GB", cities: ["Barentu", "Agordat", "Keren", "Nakfa", "Mensura", "Haykota", "Logo Anseba", "Molki", "Dghe", "Tessenei"] }
    ]
  },
  {
    name: "Somalia",
    code: "SO",
    region: "Africa",
    states: [
      { name: "Banaadir", code: "BN", cities: ["Mogadishu", "Hodan", "Hawl-Wadag", "Wardhiigleey", "Shibis", "Abdiaziz", "Bondhere", "Daynile", "Dharkenley", "Kahda"] },
      { name: "Woqooyi Galbeed", code: "WO", cities: ["Hargeisa", "Berbera", "Sheikh", "Gabiley", "Wajaale", "Salahley", "Baligubadle", "Oodweyne", "Hargeysa", "Faraweyne"] },
      { name: "Bari", code: "BR", cities: ["Bosaso", "Qardho", "Iskushuban", "Alula", "Hafun", "Caluula", "Bereeda", "Qaw", "Murcanyo", "Gumbax"] }
    ]
  },

  // MIDDLE EAST
  {
    name: "Saudi Arabia",
    code: "SA",
    region: "Middle East",
    states: [
      { name: "Riyadh Province", code: "01", cities: ["Riyadh", "Al Kharj", "Afif", "Az Zulfi", "Ad Dilam", "Al Majma'ah", "Al Ghat", "Shaqra", "Hotat Bani Tamim", "Layla"] },
      { name: "Makkah Province", code: "02", cities: ["Mecca", "Jeddah", "Taif", "Al Qunfudhah", "Rabigh", "Thuwal", "Al Jumum", "Bahrah", "Al Kamil", "Ranyah"] },
      { name: "Eastern Province", code: "04", cities: ["Dammam", "Al Khobar", "Dhahran", "Al Jubail", "Hafar Al-Batin", "Al Qatif", "Ras Tanura", "Khafji", "Al Ahsa", "Abqaiq"] }
    ]
  },
  {
    name: "United Arab Emirates",
    code: "AE",
    region: "Middle East",
    states: [
      { name: "Dubai", code: "DU", cities: ["Dubai", "Deira", "Bur Dubai", "Jumeirah", "Downtown Dubai", "Dubai Marina", "Business Bay", "Al Barsha", "Mirdif", "Al Karama"] },
      { name: "Abu Dhabi", code: "AZ", cities: ["Abu Dhabi", "Al Ain", "Zayed City", "Ruwais", "Liwa Oasis", "Madinat Zayed", "Ghayathi", "Sila", "Dalma", "Sir Bani Yas"] },
      { name: "Sharjah", code: "SH", cities: ["Sharjah", "Khor Fakkan", "Kalba", "Dibba Al-Hisn", "Mleiha", "Al Madam", "Al Hamriyah", "Al Dhaid", "Al Suyoh", "Wadi Al Helo"] }
    ]
  },
  {
    name: "Turkey",
    code: "TR",
    region: "Middle East",
    states: [
      { name: "Istanbul", code: "34", cities: ["Istanbul", "Beyoğlu", "Kadıköy", "Üsküdar", "Beşiktaş", "Şişli", "Fatih", "Bakırköy", "Zeytinburnu", "Maltepe"] },
      { name: "Ankara", code: "06", cities: ["Ankara", "Çankaya", "Keçiören", "Yenimahalle", "Mamak", "Sincan", "Etimesgut", "Gölbaşı", "Pursaklar", "Altındağ"] },
      { name: "İzmir", code: "35", cities: ["İzmir", "Konak", "Bornova", "Karşıyaka", "Buca", "Bayraklı", "Gaziemir", "Alsancak", "Balçova", "Çiğli"] }
    ]
  },
  {
    name: "Iran",
    code: "IR",
    region: "Middle East",
    states: [
      { name: "Tehran", code: "07", cities: ["Tehran", "Karaj", "Eslamshahr", "Ray", "Shahriar", "Baharestan", "Robat Karim", "Nazarabad", "Fardis", "Hashtgerd"] },
      { name: "Isfahan", code: "04", cities: ["Isfahan", "Kashan", "Khomeini Shahr", "Najafabad", "Shahinshahr", "Mobarakeh", "Falavarjan", "Lenjan", "Borkhar", "Ardestan"] },
      { name: "Fars", code: "14", cities: ["Shiraz", "Marvdasht", "Jahrom", "Fasa", "Kazerun", "Darab", "Lar", "Firuzabad", "Abadeh", "Estahban"] }
    ]
  },
  {
    name: "Israel",
    code: "IL",
    region: "Middle East",
    states: [
      { name: "Tel Aviv", code: "TA", cities: ["Tel Aviv", "Ramat Gan", "Petah Tikva", "Holon", "Bnei Brak", "Bat Yam", "Ramat HaSharon", "Herzliya", "Kfar Saba", "Ra'anana"] },
      { name: "Jerusalem", code: "JM", cities: ["Jerusalem", "Beit Shemesh", "Mevaseret Zion", "Abu Ghosh", "Givat Zeev", "Ma'ale Adumim", "Efrat", "Gush Etzion", "Har Adar", "Ein Kerem"] },
      { name: "Haifa", code: "HA", cities: ["Haifa", "Nesher", "Tirat Carmel", "Kiryat Ata", "Kiryat Motzkin", "Kiryat Yam", "Kiryat Bialik", "Akko", "Nahariya", "Carmiel"] }
    ]
  },

  // LEBANON
  {
    name: "Lebanon",
    code: "LB",
    region: "Middle East",
    states: [
      { name: "Beirut", code: "BA", cities: ["Beirut", "Achrafieh", "Hamra", "Verdun", "Ras Beirut", "Mar Mikhael", "Gemmayzeh", "Downtown Beirut", "Badaro", "Ain el-Mraiseh"] },
      { name: "Mount Lebanon", code: "JL", cities: ["Jounieh", "Byblos", "Zahlé", "Baabda", "Aley", "Broummana", "Dhour el Choueir", "Bikfaya", "Faraya", "Harissa"] },
      { name: "North", code: "AS", cities: ["Tripoli", "Batroun", "Koura", "Zgharta", "Bcharre", "Halba", "Akkar", "Minieh-Danniyeh", "Enfeh", "Chekka"] }
    ]
  },

  // SYRIA
  {
    name: "Syria",
    code: "SY",
    region: "Middle East",
    states: [
      { name: "Damascus", code: "DI", cities: ["Damascus", "Douma", "Daraya", "Harasta", "Saqba", "Zamalka", "Arbin", "Hammouriyeh", "Kafr Batna", "Jisreen"] },
      { name: "Aleppo", code: "HL", cities: ["Aleppo", "Azaz", "Al-Bab", "Manbij", "Afrin", "Jarablus", "Mare", "Atareb", "Daret Azza", "Haritan"] },
      { name: "Homs", code: "HO", cities: ["Homs", "Palmyra", "Al-Qusayr", "Rastan", "Talkalakh", "Al-Mukharram", "Shin", "Furqlus", "Sadad", "Hawsh Hammad"] }
    ]
  },

  // JORDAN
  {
    name: "Jordan",
    code: "JO",
    region: "Middle East",
    states: [
      { name: "Amman", code: "AM", cities: ["Amman", "Zarqa", "Russeifa", "Wadi as-Sir", "Sahab", "Al Jizah", "Marj al-Hamam", "Na'ur", "Marka", "Abu Alanda"] },
      { name: "Irbid", code: "IR", cities: ["Irbid", "Ramtha", "Mafraq", "Ajloun", "Jerash", "Umm Qais", "Koura", "Bani Kinanah", "Taybeh", "Kura"] },
      { name: "Aqaba", code: "AQ", cities: ["Aqaba", "Wadi Rum", "Quweira", "Diesah", "Wadi Musa", "Mudawwara", "Humeima", "Rashidiyya", "Manshiyya", "Ayl"] }
    ]
  },

  // IRAQ
  {
    name: "Iraq",
    code: "IQ",
    region: "Middle East",
    states: [
      { name: "Baghdad", code: "BG", cities: ["Baghdad", "Sadr City", "Kadhimiya", "Adhamiyah", "Karrada", "Mansour", "New Baghdad", "Dora", "Shuala", "Ghazaliya"] },
      { name: "Basra", code: "BA", cities: ["Basra", "Az Zubayr", "Abu Al Khaseeb", "Al Qurna", "Shatt al-Arab", "Fao", "Umm Qasr", "Safwan", "Khor az-Zubayr", "Tanuma"] },
      { name: "Erbil", code: "AR", cities: ["Erbil", "Shaqlawa", "Koya", "Makhmur", "Rawanduz", "Choman", "Soran", "Mergasur", "Sidakan", "Dinarta"] }
    ]
  },

  // KUWAIT
  {
    name: "Kuwait",
    code: "KW",
    region: "Middle East",
    states: [
      { name: "Al Asimah", code: "KU", cities: ["Kuwait City", "Shuwaikh", "Sharq", "Jibla", "Dasman", "Qadsia", "Dasma", "Kaifan", "Shamiya", "Sulaibikhat"] },
      { name: "Hawalli", code: "HA", cities: ["Hawalli", "Salmiya", "Nugra", "Maidan Hawalli", "Bayan", "Mishref", "Salwa", "Hitteen", "Rumaithiya", "Shaab"] },
      { name: "Ahmadi", code: "AH", cities: ["Ahmadi", "Fahaheel", "Mahboula", "Mangaf", "Abu Halifa", "Fintas", "Sabah Al-Ahmad", "Wafra", "Zour", "Khiran"] }
    ]
  },

  // BAHRAIN
  {
    name: "Bahrain",
    code: "BH",
    region: "Middle East",
    states: [
      { name: "Capital", code: "13", cities: ["Manama", "Tubli", "Isa Town", "Jidhafs", "Bilad Al Qadeem", "Sanabis", "Hoora", "Adliya", "Gudaibiya", "Zinj"] },
      { name: "Muharraq", code: "15", cities: ["Muharraq", "Hidd", "Busaiteen", "Halat Bu Maher", "Galali", "Samaheej", "Dair", "Halat Seltah", "Qalali", "Arad"] },
      { name: "Northern", code: "17", cities: ["Hamad Town", "A'ali", "Janabiyah", "Budaiya", "Barbar", "Diraz", "Bani Jamra", "Saar", "Dumistan", "Karbabad"] }
    ]
  },

  // QATAR
  {
    name: "Qatar",
    code: "QA",
    region: "Middle East",
    states: [
      { name: "Doha", code: "DA", cities: ["Doha", "West Bay", "Al Sadd", "Al Nasr", "Al Waab", "Al Muntazah", "Al Hilal", "Al Mansoura", "Al Aziziyah", "Al Markhiya"] },
      { name: "Al Rayyan", code: "RA", cities: ["Al Rayyan", "Al Gharafa", "Madinat Khalifa", "Abu Hamour", "Al Waab", "Education City", "Duhail", "Al Thumama", "Umm Salal", "Al Khor"] },
      { name: "Al Wakrah", code: "WA", cities: ["Al Wakrah", "Mesaieed", "Al Wukair", "Umm Al Quwain", "Al Khor", "Al Egla", "Sealine Beach", "Fuwairit", "Zekreet", "Al Areesh"] }
    ]
  },

  // OMAN
  {
    name: "Oman",
    code: "OM",
    region: "Middle East",
    states: [
      { name: "Muscat", code: "MA", cities: ["Muscat", "Mutrah", "Ruwi", "Al Khuwair", "Al Ghubra", "Bawshar", "Al Seeb", "Al Amerat", "Qurum", "Azaiba"] },
      { name: "Dhofar", code: "ZU", cities: ["Salalah", "Taqah", "Mirbat", "Raysut", "Thumrait", "Sadah", "Dhalkut", "Hasik", "Shuwaymiyah", "Al Mughsail"] },
      { name: "Al Batinah North", code: "BS", cities: ["Sohar", "Shinas", "Liwa", "Saham", "Al Khaburah", "As Suwayq", "Nakhal", "Wadi Al Maawil", "Al Awabi", "Al Musanaah"] }
    ]
  },

  // YEMEN
  {
    name: "Yemen",
    code: "YE",
    region: "Middle East",
    states: [
      { name: "Sana'a", code: "SA", cities: ["Sana'a", "Bani Al Harith", "Al Wahdah", "Az Zubairi", "As Sabain", "Ma'ain", "Hamdan", "Jihanah", "Sanhan", "Arhab"] },
      { name: "Aden", code: "AD", cities: ["Aden", "Crater", "Tawahi", "Mualla", "Khormaksar", "Sheikh Othman", "Dar Saad", "Al Mansura", "Al Buraiqa", "Lahij"] },
      { name: "Hadramaut", code: "HD", cities: ["Al Mukalla", "Seiyun", "Shibam", "Tarim", "Al Shihr", "Qusayr", "Ghayl Bin Yamin", "Al Qatn", "Thamud", "Sayun"] }
    ]
  },

  // CYPRUS
  {
    name: "Cyprus",
    code: "CY",
    region: "Middle East",
    states: [
      { name: "Nicosia", code: "01", cities: ["Nicosia", "Strovolos", "Lakatamia", "Latsia", "Geri", "Tseri", "Kokkinotrimithia", "Pera", "Aglantzia", "Engomi"] },
      { name: "Limassol", code: "02", cities: ["Limassol", "Germasogeia", "Mesa Geitonia", "Agios Athanasios", "Ypsonas", "Parekklisia", "Mouttagiaka", "Pyrgos", "Erimi", "Kolossi"] },
      { name: "Larnaca", code: "03", cities: ["Larnaca", "Aradippou", "Livadia", "Dromolaxia", "Meneou", "Kiti", "Pervolia", "Oroklini", "Pyla", "Alaminos"] }
    ]
  },

  // ADDITIONAL EUROPE
  {
    name: "Russia",
    code: "RU",
    region: "Europe",
    states: [
      { name: "Moscow", code: "MOW", cities: ["Moscow", "Zelenograd", "Troitsk", "Shcherbinka", "Podolsk", "Khimki", "Balashikha", "Mytishchi", "Korolev", "Lyubertsy"] },
      { name: "Saint Petersburg", code: "SPE", cities: ["Saint Petersburg", "Kolpino", "Pushkin", "Peterhof", "Kronstadt", "Lomonosov", "Sestroretsk", "Zelenogorsk", "Pavlovsk", "Gatchina"] },
      { name: "Novosibirsk Oblast", code: "NVS", cities: ["Novosibirsk", "Berdsk", "Iskitim", "Ob", "Kuybyshev", "Tatarsk", "Barabinsk", "Karasuk", "Chulym", "Toguchin"] }
    ]
  },
  {
    name: "Poland",
    code: "PL",
    region: "Europe",
    states: [
      { name: "Masovian Voivodeship", code: "MZ", cities: ["Warsaw", "Radom", "Płock", "Siedlce", "Ostrołęka", "Ciechanów", "Mińsk Mazowiecki", "Piaseczno", "Legionowo", "Pruszków"] },
      { name: "Lesser Poland Voivodeship", code: "MA", cities: ["Kraków", "Tarnów", "Nowy Sącz", "Oświęcim", "Chrzanów", "Olkusz", "Skawina", "Gorlice", "Bochnia", "Zakopane"] },
      { name: "Silesian Voivodeship", code: "SL", cities: ["Katowice", "Częstochowa", "Sosnowiec", "Gliwice", "Zabrze", "Bytom", "Bielsko-Biała", "Ruda Śląska", "Rybnik", "Tychy"] }
    ]
  },
  {
    name: "Ukraine",
    code: "UA",
    region: "Europe",
    states: [
      { name: "Kyiv Oblast", code: "32", cities: ["Kyiv", "Bila Tserkva", "Boryspil", "Brovary", "Vasylkiv", "Irpin", "Bucha", "Fastiv", "Obukhiv", "Pereyaslav"] },
      { name: "Kharkiv Oblast", code: "63", cities: ["Kharkiv", "Lozova", "Chuhuiv", "Izyum", "Kupiansk", "Balakliia", "Pervomaiskyi", "Merefa", "Derhachi", "Vovchansk"] },
      { name: "Dnipropetrovsk Oblast", code: "12", cities: ["Dnipro", "Kryvyi Rih", "Kamianske", "Nikopol", "Pavlohrad", "Novomoskovsk", "Marhanets", "Pershotravensk", "Vilnohirsk", "Synelnykove"] }
    ]
  },

  // ROMANIA
  {
    name: "Romania",
    code: "RO",
    region: "Europe",
    states: [
      { name: "Bucharest", code: "B", cities: ["Bucharest", "Voluntari", "Popești-Leordeni", "Chiajna", "Bragadiru", "Pantelimon", "Magurele", "Chitila", "Otopeni", "Corbeanca"] },
      { name: "Cluj", code: "CJ", cities: ["Cluj-Napoca", "Turda", "Dej", "Câmpia Turzii", "Gherla", "Huedin", "Apahida", "Florești", "Băișoara", "Beliș"] },
      { name: "Timiș", code: "TM", cities: ["Timișoara", "Lugoj", "Sânnicolau Mare", "Jimbolia", "Făget", "Buziaș", "Recaș", "Deta", "Gătaia", "Ciacova"] }
    ]
  },

  // CZECH REPUBLIC
  {
    name: "Czech Republic",
    code: "CZ",
    region: "Europe",
    states: [
      { name: "Prague", code: "10", cities: ["Prague", "Praha 1", "Praha 2", "Praha 3", "Praha 4", "Praha 5", "Praha 6", "Praha 7", "Praha 8", "Praha 9"] },
      { name: "South Moravian", code: "64", cities: ["Brno", "Břeclav", "Hodonín", "Vyškov", "Znojmo", "Blansko", "Boskovice", "Kyjov", "Mikulov", "Pohořelice"] },
      { name: "Central Bohemian", code: "20", cities: ["Kladno", "Mladá Boleslav", "Příbram", "Kolín", "Beroun", "Mělník", "Rakovník", "Nymburk", "Benešov", "Kutná Hora"] }
    ]
  },

  // HUNGARY
  {
    name: "Hungary",
    code: "HU",
    region: "Europe",
    states: [
      { name: "Budapest", code: "BU", cities: ["Budapest", "Budafok", "Óbuda", "Pest", "Buda", "Zugló", "Kispest", "Újpest", "Ferencváros", "Józsefváros"] },
      { name: "Pest", code: "PE", cities: ["Érd", "Vác", "Szentendre", "Gödöllő", "Cegléd", "Dunaújváros", "Monor", "Vecsés", "Dunakeszi", "Budakeszi"] },
      { name: "Borsod-Abaúj-Zemplén", code: "BAZ", cities: ["Miskolc", "Kazincbarcika", "Ózd", "Tiszaújváros", "Sátoraljaújhely", "Mezőkövesd", "Encs", "Szerencs", "Tokaj", "Cigánd"] }
    ]
  },

  // SLOVAKIA
  {
    name: "Slovakia",
    code: "SK",
    region: "Europe",
    states: [
      { name: "Bratislava", code: "BL", cities: ["Bratislava", "Pezinok", "Senec", "Malacky", "Stupava", "Modra", "Svätý Jur", "Bernolákovo", "Ivanka pri Dunaji", "Záhorská Bystrica"] },
      { name: "Košice", code: "KI", cities: ["Košice", "Michalovce", "Spišská Nová Ves", "Rožňava", "Trebišov", "Sobrance", "Gelnica", "Moldava nad Bodvou", "Veľké Kapušany", "Strážske"] },
      { name: "Prešov", code: "PV", cities: ["Prešov", "Poprad", "Humenné", "Bardejov", "Vranov nad Topľou", "Snina", "Kežmarok", "Levoča", "Stropkov", "Medzilaborce"] }
    ]
  },

  // BULGARIA
  {
    name: "Bulgaria",
    code: "BG",
    region: "Europe",
    states: [
      { name: "Sofia City", code: "22", cities: ["Sofia", "Bankya", "Novi Iskar", "Bozhurishte", "Kostinbrod", "Elin Pelin", "Gorna Malina", "Dolni Bogrov", "Vladaya", "Pancharevo"] },
      { name: "Plovdiv", code: "16", cities: ["Plovdiv", "Asenovgrad", "Karlovo", "Parvomay", "Krichim", "Perushtitsa", "Rakovski", "Sadovo", "Stamboliyski", "Maritsa"] },
      { name: "Varna", code: "03", cities: ["Varna", "Devnya", "Provadiya", "Suvorovo", "Valchi Dol", "Vetrino", "Avren", "Aksakovo", "Beloslav", "Byala"] }
    ]
  },

  // CROATIA
  {
    name: "Croatia",
    code: "HR",
    region: "Europe",
    states: [
      { name: "Zagreb", code: "21", cities: ["Zagreb", "Sesvete", "Velika Gorica", "Samobor", "Zaprešić", "Dugo Selo", "Vrbovec", "Ivanić-Grad", "Jastrebarsko", "Sveta Nedelja"] },
      { name: "Split-Dalmatia", code: "17", cities: ["Split", "Kaštela", "Solin", "Trogir", "Sinj", "Imotski", "Makarska", "Omiš", "Vrgorac", "Trilj"] },
      { name: "Primorje-Gorski Kotar", code: "08", cities: ["Rijeka", "Pula", "Opatija", "Crikvenica", "Krk", "Mali Lošinj", "Rab", "Delnice", "Vrbovsko", "Čabar"] }
    ]
  },

  // SERBIA
  {
    name: "Serbia",
    code: "RS",
    region: "Europe",
    states: [
      { name: "Belgrade", code: "00", cities: ["Belgrade", "Zemun", "Novi Beograd", "Zvezdara", "Voždovac", "Vračar", "Savski Venac", "Stari Grad", "Palilula", "Čukarica"] },
      { name: "Vojvodina", code: "VO", cities: ["Novi Sad", "Subotica", "Zrenjanin", "Pančevo", "Kikinda", "Sombor", "Vršac", "Ruma", "Inđija", "Stara Pazova"] },
      { name: "Šumadija and Western Serbia", code: "10", cities: ["Kragujevac", "Čačak", "Kraljevo", "Smederevo", "Jagodina", "Užice", "Valjevo", "Kruševac", "Leskovac", "Vranje"] }
    ]
  },

  // SLOVENIA
  {
    name: "Slovenia",
    code: "SI",
    region: "Europe",
    states: [
      { name: "Central Slovenia", code: "061", cities: ["Ljubljana", "Kamnik", "Domžale", "Vrhnika", "Grosuplje", "Litija", "Škofljica", "Mengeš", "Komenda", "Lukovica"] },
      { name: "Podravska", code: "041", cities: ["Maribor", "Ptuj", "Slovenska Bistrica", "Ormož", "Lenart", "Ruše", "Starše", "Pesnica", "Markovci", "Kidričevo"] },
      { name: "Savinjska", code: "031", cities: ["Celje", "Velenje", "Žalec", "Laško", "Mozirje", "Šoštanj", "Prebold", "Polzela", "Braslovče", "Vransko"] }
    ]
  },

  // BOSNIA AND HERZEGOVINA
  {
    name: "Bosnia and Herzegovina",
    code: "BA",
    region: "Europe",
    states: [
      { name: "Federation of Bosnia and Herzegovina", code: "BIH", cities: ["Sarajevo", "Tuzla", "Zenica", "Mostar", "Bihać", "Brčko", "Cazin", "Visoko", "Goražde", "Konjic"] },
      { name: "Republika Srpska", code: "SRP", cities: ["Banja Luka", "Bijeljina", "Prijedor", "Doboj", "Zvornik", "Gradiška", "Trebinje", "Foča", "Pale", "Nevesinje"] },
      { name: "Brčko District", code: "BRC", cities: ["Brčko", "Rahić", "Dubrave Donje", "Dubrave Gornje", "Brod", "Ulice", "Gornja Skakava", "Donja Skakava", "Bijela", "Klanac"] }
    ]
  },

  // ALBANIA
  {
    name: "Albania",
    code: "AL",
    region: "Europe",
    states: [
      { name: "Tirana", code: "11", cities: ["Tirana", "Kamëz", "Kavajë", "Vorë", "Rrogozhinë", "Krujë", "Mamurras", "Paskuqan", "Farkë", "Dajt"] },
      { name: "Durrës", code: "02", cities: ["Durrës", "Krujë", "Shijak", "Mamurras", "Sukth", "Katund i Ri", "Fushë-Krujë", "Bubq", "Xhafzotaj", "Manëz"] },
      { name: "Vlorë", code: "12", cities: ["Vlorë", "Fier", "Ballsh", "Patos", "Roskovec", "Cakran", "Selenicë", "Orikum", "Himarë", "Delvinë"] }
    ]
  },

  // NORTH MACEDONIA
  {
    name: "North Macedonia",
    code: "MK",
    region: "Europe",
    states: [
      { name: "Skopje", code: "85", cities: ["Skopje", "Kumanovo", "Tetovo", "Gostivar", "Veles", "Ohrid", "Bitola", "Prilep", "Štip", "Kočani"] },
      { name: "Eastern", code: "2", cities: ["Štip", "Kočani", "Vinica", "Probištip", "Sveti Nikole", "Kratovo", "Kriva Palanka", "Delčevo", "Berovo", "Pehčevo"] },
      { name: "Southeastern", code: "4", cities: ["Strumica", "Radoviš", "Gevgelija", "Valandovo", "Dojran", "Bosilovo", "Konče", "Novo Selo", "Star Dojran", "Bogdanci"] }
    ]
  },

  // MONTENEGRO
  {
    name: "Montenegro",
    code: "ME",
    region: "Europe",
    states: [
      { name: "Central Montenegro", code: "06", cities: ["Podgorica", "Cetinje", "Danilovgrad", "Nikšić", "Kolašin", "Šavnik", "Žabljak", "Plužine", "Mojkovac", "Berane"] },
      { name: "Coastal Montenegro", code: "19", cities: ["Bar", "Ulcinj", "Budva", "Kotor", "Tivat", "Herceg Novi", "Perast", "Petrovac", "Sutomore", "Sveti Stefan"] },
      { name: "Northern Montenegro", code: "20", cities: ["Bijelo Polje", "Berane", "Rožaje", "Plav", "Andrijevica", "Gusinje", "Petnjica", "Murino", "Vusanje", "Tuzi"] }
    ]
  },

  // GREECE
  {
    name: "Greece",
    code: "GR",
    region: "Europe",
    states: [
      { name: "Attica", code: "I", cities: ["Athens", "Piraeus", "Peristeri", "Kallithea", "Nikaia", "Glyfada", "Voula", "Elliniko", "Nea Smyrni", "Marousi"] },
      { name: "Central Macedonia", code: "B", cities: ["Thessaloniki", "Serres", "Katerini", "Veria", "Edessa", "Giannitsa", "Kilkis", "Polygyros", "Naousa", "Alexandria"] },
      { name: "Crete", code: "M", cities: ["Heraklion", "Chania", "Rethymno", "Agios Nikolaos", "Ierapetra", "Sitia", "Kissamos", "Paleochora", "Malia", "Hersonissos"] }
    ]
  },

  // PORTUGAL
  {
    name: "Portugal",
    code: "PT",
    region: "Europe",
    states: [
      { name: "Lisbon", code: "11", cities: ["Lisbon", "Sintra", "Cascais", "Loures", "Amadora", "Oeiras", "Odivelas", "Mafra", "Vila Franca de Xira", "Torres Vedras"] },
      { name: "Porto", code: "13", cities: ["Porto", "Vila Nova de Gaia", "Matosinhos", "Gondomar", "Valongo", "Maia", "Póvoa de Varzim", "Vila do Conde", "Santo Tirso", "Trofa"] },
      { name: "Braga", code: "03", cities: ["Braga", "Guimarães", "Famalicão", "Barcelos", "Esposende", "Cabeceiras de Basto", "Fafe", "Póvoa de Lanhoso", "Vieira do Minho", "Terras de Bouro"] }
    ]
  },

  // AUSTRIA
  {
    name: "Austria",
    code: "AT",
    region: "Europe",
    states: [
      { name: "Vienna", code: "9", cities: ["Vienna", "Donaustadt", "Favoriten", "Floridsdorf", "Simmering", "Meidling", "Ottakring", "Rudolfsheim-Fünfhaus", "Hernals", "Hietzing"] },
      { name: "Lower Austria", code: "3", cities: ["St. Pölten", "Wiener Neustadt", "Krems", "Klosterneuburg", "Baden", "Amstetten", "Tulln", "Mödling", "Melk", "Korneuburg"] },
      { name: "Upper Austria", code: "4", cities: ["Linz", "Wels", "Steyr", "Traun", "Leonding", "Ansfelden", "Enns", "Pasching", "Marchtrenk", "Hörsching"] }
    ]
  },

  // SWITZERLAND
  {
    name: "Switzerland",
    code: "CH",
    region: "Europe",
    states: [
      { name: "Zurich", code: "ZH", cities: ["Zurich", "Winterthur", "Uster", "Dübendorf", "Dietikon", "Wetzikon", "Kloten", "Schlieren", "Vernier", "Rapperswil-Jona"] },
      { name: "Bern", code: "BE", cities: ["Bern", "Biel/Bienne", "Thun", "Köniz", "Steffisburg", "Ostermundigen", "Burgdorf", "Langenthal", "Worb", "Lyss"] },
      { name: "Geneva", code: "GE", cities: ["Geneva", "Vernier", "Lancy", "Meyrin", "Carouge", "Onex", "Thônex", "Versoix", "Le Grand-Saconnex", "Plan-les-Ouates"] }
    ]
  },

  // BELGIUM
  {
    name: "Belgium",
    code: "BE",
    region: "Europe",
    states: [
      { name: "Brussels", code: "BRU", cities: ["Brussels", "Antwerp", "Ghent", "Charleroi", "Liège", "Bruges", "Namur", "Leuven", "Mons", "Aalst"] },
      { name: "Flanders", code: "VLG", cities: ["Antwerp", "Ghent", "Bruges", "Leuven", "Aalst", "Mechelen", "Kortrijk", "Hasselt", "Ostend", "Sint-Niklaas"] },
      { name: "Wallonia", code: "WAL", cities: ["Charleroi", "Liège", "Namur", "Mons", "La Louvière", "Tournai", "Verviers", "Seraing", "Mouscron", "Arlon"] }
    ]
  },

  // DENMARK
  {
    name: "Denmark",
    code: "DK",
    region: "Europe",
    states: [
      { name: "Capital Region", code: "84", cities: ["Copenhagen", "Frederiksberg", "Gentofte", "Gladsaxe", "Lyngby-Taarbæk", "Rødovre", "Hvidovre", "Ballerup", "Albertslund", "Tårnby"] },
      { name: "Central Denmark", code: "82", cities: ["Aarhus", "Randers", "Horsens", "Vejle", "Silkeborg", "Herning", "Holstebro", "Viborg", "Skanderborg", "Ringkøbing-Skjern"] },
      { name: "Southern Denmark", code: "83", cities: ["Odense", "Esbjerg", "Kolding", "Fredericia", "Haderslev", "Sønderborg", "Aabenraa", "Varde", "Vejen", "Tønder"] }
    ]
  },

  // SWEDEN
  {
    name: "Sweden",
    code: "SE",
    region: "Europe",
    states: [
      { name: "Stockholm", code: "AB", cities: ["Stockholm", "Göteborg", "Malmö", "Uppsala", "Sollentuna", "Västerås", "Örebro", "Linköping", "Helsingborg", "Jönköping"] },
      { name: "Västra Götaland", code: "O", cities: ["Göteborg", "Borås", "Trollhättan", "Uddevalla", "Skövde", "Lidköping", "Alingsås", "Lerum", "Mölndal", "Kungälv"] },
      { name: "Skåne", code: "M", cities: ["Malmö", "Helsingborg", "Lund", "Kristianstad", "Landskrona", "Trelleborg", "Ängelholm", "Hässleholm", "Ystad", "Eslöv"] }
    ]
  },

  // NORWAY
  {
    name: "Norway",
    code: "NO",
    region: "Europe",
    states: [
      { name: "Oslo", code: "03", cities: ["Oslo", "Bærum", "Asker", "Lørenskog", "Drammen", "Sandvika", "Kolbotn", "Ski", "Ås", "Oppegård"] },
      { name: "Viken", code: "30", cities: ["Drammen", "Fredrikstad", "Sarpsborg", "Moss", "Sandefjord", "Tønsberg", "Askim", "Kongsberg", "Horten", "Holmestrand"] },
      { name: "Vestland", code: "46", cities: ["Bergen", "Stavanger", "Haugesund", "Ålesund", "Kristiansund", "Molde", "Florø", "Førde", "Odda", "Voss"] }
    ]
  },

  // FINLAND
  {
    name: "Finland",
    code: "FI",
    region: "Europe",
    states: [
      { name: "Uusimaa", code: "01", cities: ["Helsinki", "Espoo", "Vantaa", "Kauniainen", "Järvenpää", "Kerava", "Kirkkonummi", "Nurmijärvi", "Sipoo", "Tuusula"] },
      { name: "Pirkanmaa", code: "06", cities: ["Tampere", "Nokia", "Ylöjärvi", "Kangasala", "Lempäälä", "Orivesi", "Pirkkala", "Valkeakoski", "Ikaalinen", "Mänttä-Vilppula"] },
      { name: "Varsinais-Suomi", code: "02", cities: ["Turku", "Kaarina", "Raisio", "Naantali", "Salo", "Loimaa", "Parainen", "Uusikaupunki", "Somero", "Paimio"] }
    ]
  },

  // IRELAND
  {
    name: "Ireland",
    code: "IE",
    region: "Europe",
    states: [
      { name: "Dublin", code: "D", cities: ["Dublin", "Cork", "Limerick", "Galway", "Waterford", "Drogheda", "Dundalk", "Swords", "Bray", "Navan"] },
      { name: "Cork", code: "C", cities: ["Cork", "Ballincollig", "Carrigaline", "Midleton", "Cobh", "Mallow", "Youghal", "Fermoy", "Macroom", "Skibbereen"] },
      { name: "Galway", code: "G", cities: ["Galway", "Tuam", "Ballinasloe", "Loughrea", "Athenry", "Gort", "Clifden", "Oughterard", "Headford", "Portumna"] }
    ]
  },

  // ADDITIONAL ASIA
  {
    name: "Pakistan",
    code: "PK",
    region: "Asia",
    states: [
      { name: "Punjab", code: "PB", cities: ["Lahore", "Faisalabad", "Rawalpindi", "Multan", "Gujranwala", "Sialkot", "Bahawalpur", "Sargodha", "Sheikhupura", "Jhang"] },
      { name: "Sindh", code: "SD", cities: ["Karachi", "Hyderabad", "Sukkur", "Larkana", "Nawabshah", "Mirpur Khas", "Jacobabad", "Shikarpur", "Khairpur", "Dadu"] },
      { name: "Khyber Pakhtunkhwa", code: "KP", cities: ["Peshawar", "Mardan", "Mingora", "Kohat", "Dera Ismail Khan", "Bannu", "Swabi", "Charsadda", "Nowshera", "Mansehra"] }
    ]
  },
  {
    name: "Bangladesh",
    code: "BD",
    region: "Asia",
    states: [
      { name: "Dhaka Division", code: "C", cities: ["Dhaka", "Gazipur", "Narayanganj", "Tangail", "Manikganj", "Munshiganj", "Narsingdi", "Faridpur", "Rajbari", "Madaripur"] },
      { name: "Chittagong Division", code: "B", cities: ["Chittagong", "Cox's Bazar", "Comilla", "Brahmanbaria", "Noakhali", "Feni", "Lakshmipur", "Chandpur", "Rangamati", "Khagrachhari"] },
      { name: "Rajshahi Division", code: "H", cities: ["Rajshahi", "Rangpur", "Bogura", "Pabna", "Sirajganj", "Natore", "Joypurhat", "Chapai Nawabganj", "Naogaon", "Kushtia"] }
    ]
  },
  {
    name: "Vietnam",
    code: "VN",
    region: "Asia",
    states: [
      { name: "Hanoi", code: "HN", cities: ["Hanoi", "Ha Dong", "Son Tay", "Ba Vi", "Phuc Tho", "Dan Phuong", "Hoai Duc", "Quoc Oai", "Thach That", "Chuong My"] },
      { name: "Ho Chi Minh City", code: "SG", cities: ["Ho Chi Minh City", "Thu Duc", "District 1", "District 3", "District 4", "District 5", "District 6", "District 7", "District 8", "District 10"] },
      { name: "Da Nang", code: "DN", cities: ["Da Nang", "Hai Chau", "Cam Le", "Son Tra", "Ngu Hanh Son", "Thanh Khe", "Lien Chieu", "Hoa Vang", "Ba Na Hills", "Marble Mountains"] }
    ]
  },
  {
    name: "Philippines",
    code: "PH",
    region: "Asia",
    states: [
      { name: "Metro Manila", code: "00", cities: ["Manila", "Quezon City", "Caloocan", "Las Piñas", "Makati", "Malabon", "Mandaluyong", "Marikina", "Muntinlupa", "Navotas"] },
      { name: "Cebu", code: "07", cities: ["Cebu City", "Lapu-Lapu", "Mandaue", "Talisay", "Toledo", "Naga", "Carcar", "Danao", "Bogo", "Alegria"] },
      { name: "Davao", code: "11", cities: ["Davao City", "Tagum", "Panabo", "Samal", "Digos", "Mati", "Malita", "Bansalan", "Hagonoy", "Magsaysay"] }
    ]
  },
  {
    name: "Malaysia",
    code: "MY",
    region: "Asia",
    states: [
      { name: "Selangor", code: "10", cities: ["Shah Alam", "Subang Jaya", "Petaling Jaya", "Klang", "Ampang", "Cheras", "Kajang", "Selayang", "Puchong", "Serdang"] },
      { name: "Kuala Lumpur", code: "14", cities: ["Kuala Lumpur", "Cheras", "Kepong", "Setapak", "Wangsa Maju", "Segambut", "Seputeh", "Lembah Pantai", "Bandar Tun Razak", "Bukit Bintang"] },
      { name: "Johor", code: "01", cities: ["Johor Bahru", "Skudai", "Pasir Gudang", "Kulai", "Senai", "Masai", "Gelang Patah", "Nusajaya", "Pontian", "Batu Pahat"] }
    ]
  },

  // SINGAPORE
  {
    name: "Singapore",
    code: "SG",
    region: "Asia",
    states: [
      { name: "Central Region", code: "01", cities: ["Singapore", "Bukit Timah", "Marina Bay", "Orchard", "Downtown Core", "Museum", "Newton", "Novena", "Rochor", "Tanglin"] },
      { name: "East Region", code: "02", cities: ["Bedok", "Changi", "Pasir Ris", "Tampines", "Simei", "Kembangan", "Eunos", "Paya Lebar", "Ubi", "Kaki Bukit"] },
      { name: "North Region", code: "03", cities: ["Yishun", "Sembawang", "Woodlands", "Admiralty", "Marsiling", "Canberra", "Khatib", "Yio Chu Kang", "Ang Mo Kio", "Bishan"] }
    ]
  },

  // BRUNEI
  {
    name: "Brunei",
    code: "BN",
    region: "Asia",
    states: [
      { name: "Brunei-Muara", code: "BM", cities: ["Bandar Seri Begawan", "Muara", "Berakas", "Gadong", "Kiulap", "Kiarong", "Sengkurong", "Mentiri", "Serasa", "Lumapas"] },
      { name: "Belait", code: "BE", cities: ["Seria", "Kuala Belait", "Labi", "Melilas", "Bukit Sawat", "Sungai Liang", "Rasau", "Mumong", "Badas", "Sukang"] },
      { name: "Tutong", code: "TU", cities: ["Tutong", "Lamunin", "Rambai", "Ukong", "Tanjong Maya", "Keriam", "Bukit Panggal", "Telisai", "Kiudang", "Sengkarai"] }
    ]
  },

  // MYANMAR
  {
    name: "Myanmar",
    code: "MM",
    region: "Asia",
    states: [
      { name: "Yangon Region", code: "06", cities: ["Yangon", "Thanlyin", "Dala", "Seikgyikanaungto", "Cocokyun", "Kawhmu", "Kungyangon", "Kyauktan", "Hmawbi", "Hlegu"] },
      { name: "Mandalay Region", code: "04", cities: ["Mandalay", "Meiktila", "Pyinoolwin", "Nyaung-U", "Kyaukse", "Mahlaing", "Thazi", "Wundwin", "Taungtha", "Natogyi"] },
      { name: "Naypyidaw Union Territory", code: "18", cities: ["Naypyidaw", "Pyinmana", "Lewe", "Tatkon", "Dekkhinathiri", "Ottarathiri", "Pobbathiri", "Zabuthiri", "Zeyathiri", "Pyigyitagon"] }
    ]
  },

  // LAOS
  {
    name: "Laos",
    code: "LA",
    region: "Asia",
    states: [
      { name: "Vientiane Prefecture", code: "VT", cities: ["Vientiane", "Sisattanak", "Chanthabuly", "Sikhottabong", "Xaysetha", "Sivilay", "Parkngum", "Hatxaifong", "Sangthong", "Mayparkngum"] },
      { name: "Champasak", code: "CH", cities: ["Pakse", "Champasak", "Bachiangchaleunsouk", "Khong", "Mounlapamok", "Pakxong", "Pathounmphon", "Phonthong", "Sanasomboun", "Soukhouma"] },
      { name: "Luang Prabang", code: "LP", cities: ["Luang Prabang", "Xieng Ngeun", "Nan", "Pak Ou", "Nambak", "Ngoi", "Pak Xeng", "Phonxay", "Phou Khoun", "Viengkham"] }
    ]
  },

  // CAMBODIA
  {
    name: "Cambodia",
    code: "KH",
    region: "Asia",
    states: [
      { name: "Phnom Penh", code: "12", cities: ["Phnom Penh", "Chamkar Mon", "Doun Penh", "Prampir Meakkakra", "Tuol Kouk", "Dangkao", "Mean Chey", "Russey Keo", "Sen Sok", "Pou Senchey"] },
      { name: "Siem Reap", code: "17", cities: ["Siem Reap", "Angkor Chum", "Angkor Thom", "Banteay Srei", "Chi Kraeng", "Kralanh", "Puok", "Prasat Bakong", "Sout Nikom", "Srei Snam"] },
      { name: "Battambang", code: "02", cities: ["Battambang", "Banan", "Thma Koul", "Bavel", "Ek Phnom", "Moung Ruessei", "Rotanak Mondol", "Sangkae", "Samlout", "Sampov Lun"] }
    ]
  },

  // SRI LANKA
  {
    name: "Sri Lanka",
    code: "LK",
    region: "Asia",
    states: [
      { name: "Western Province", code: "1", cities: ["Colombo", "Gampaha", "Kalutara", "Negombo", "Moratuwa", "Panadura", "Horana", "Wattala", "Kelaniya", "Ja-Ela"] },
      { name: "Central Province", code: "2", cities: ["Kandy", "Matale", "Nuwara Eliya", "Gampola", "Hatton", "Nawalapitiya", "Dambulla", "Sigiriya", "Peradeniya", "Kadugannawa"] },
      { name: "Southern Province", code: "3", cities: ["Galle", "Matara", "Hambantota", "Hikkaduwa", "Tangalle", "Weligama", "Ambalangoda", "Bentota", "Mirissa", "Tissamaharama"] }
    ]
  },

  // MALDIVES
  {
    name: "Maldives",
    code: "MV",
    region: "Asia",
    states: [
      { name: "Malé", code: "MLE", cities: ["Malé", "Hulhumalé", "Vilimalé", "Malé Atoll", "Hulhulé", "Funadhoo", "Thulusdhoo", "Himmafushi", "Huraa", "Kuda Huraa"] },
      { name: "Addu Atoll", code: "01", cities: ["Addu City", "Hithadhoo", "Maradhoo", "Feydhoo", "Hulhudhoo", "Meedhoo", "Maradhoo-Feydhoo", "Gan", "Shangani", "Koattey"] },
      { name: "Fuvahmulah", code: "02", cities: ["Fuvahmulah", "Dhadimago", "Diguvāndo", "Hōdhado", "Mālegan", "Miskimmago", "Funadhoo", "Dūndigan", "Hau", "Ghā"] }
    ]
  },

  // AFGHANISTAN
  {
    name: "Afghanistan",
    code: "AF",
    region: "Asia",
    states: [
      { name: "Kabul", code: "KAB", cities: ["Kabul", "Paghman", "Deh Sabz", "Musayi", "Qarabagh", "Shakardara", "Surobi", "Bagrami", "Khak-e Jabbar", "Guldara"] },
      { name: "Herat", code: "HER", cities: ["Herat", "Injil", "Guzara", "Pashtun Zarghun", "Adraskan", "Ghoryan", "Obe", "Karkh", "Kushk", "Kushki Kuhna"] },
      { name: "Kandahar", code: "KAN", cities: ["Kandahar", "Daman", "Panjwayi", "Arghandab", "Zhari", "Maywand", "Spin Boldak", "Arghistan", "Maruf", "Shorabak"] }
    ]
  },

  // UZBEKISTAN
  {
    name: "Uzbekistan",
    code: "UZ",
    region: "Asia",
    states: [
      { name: "Tashkent", code: "TK", cities: ["Tashkent", "Chirchiq", "Angren", "Olmaliq", "Bekabad", "Yangiabad", "Bostanliq", "Parkent", "Piskent", "Qibray"] },
      { name: "Samarkand", code: "SA", cities: ["Samarkand", "Kattaqo'rg'on", "Ishtixon", "Jomboy", "Koshrabot", "Narpay", "Nurobod", "Oqdaryo", "Payariq", "Pastdarg'om"] },
      { name: "Fergana", code: "FA", cities: ["Fergana", "Margilan", "Quvasoy", "Qo'qon", "Beshariq", "Bog'dod", "Buvayda", "Dang'ara", "Furqat", "Oltiariq"] }
    ]
  },

  // KAZAKHSTAN
  {
    name: "Kazakhstan",
    code: "KZ",
    region: "Asia",
    states: [
      { name: "Almaty", code: "ALA", cities: ["Almaty", "Talgar", "Kapchagai", "Issyk", "Esik", "Sarkand", "Taldykorgan", "Tekeli", "Zharkent", "Kerbulak"] },
      { name: "Nur-Sultan", code: "NUR", cities: ["Nur-Sultan", "Arshaly", "Atbasar", "Yesil", "Akmol", "Bulandy", "Enbekshilder", "Ereymentau", "Kokshetau", "Makinsk"] },
      { name: "Shymkent", code: "SHY", cities: ["Shymkent", "Kentau", "Saryagash", "Lenger", "Arys", "Turkestan", "Zhety suu", "Makta-Aral", "Sholakkorgan", "Turar Ryskulov"] }
    ]
  },

  // KYRGYZSTAN
  {
    name: "Kyrgyzstan",
    code: "KG",
    region: "Asia",
    states: [
      { name: "Bishkek", code: "GB", cities: ["Bishkek", "Kant", "Tokmok", "Kemin", "Sokuluk", "Ysyk-Ata", "Chuy", "Alamedin", "Moskva", "Belovodsk"] },
      { name: "Osh", code: "O", cities: ["Osh", "Nookat", "Uzgen", "Kara-Suu", "Aravan", "Chong-Alay", "Kara-Kulja", "Alay", "Gulcha", "Ozgon"] },
      { name: "Jalal-Abad", code: "J", cities: ["Jalal-Abad", "Kara-Kul", "Suzak", "Bazar-Korgon", "Tash-Kumyr", "Kerben", "Ala-Buka", "Aksy", "Toguz-Toro", "Chatkal"] }
    ]
  },

  // TAJIKISTAN
  {
    name: "Tajikistan",
    code: "TJ",
    region: "Asia",
    states: [
      { name: "Dushanbe", code: "DU", cities: ["Dushanbe", "Hisor", "Vahdat", "Tursunzoda", "Rudaki", "Shahrinav", "Fayzabad", "Varzob", "Sangvor", "Lakhsh"] },
      { name: "Sughd", code: "SU", cities: ["Khujand", "Istaravshan", "Konibodom", "Isfara", "Panjakent", "Chkalovsk", "Kayrakum", "Taboshar", "Zafarabad", "Mastchoh"] },
      { name: "Khatlon", code: "KT", cities: ["Qurghonteppa", "Kulob", "Bokhtar", "Norak", "Yovon", "Vakhsh", "Jomi", "Danghara", "Panj", "Qumsangir"] }
    ]
  },

  // TURKMENISTAN
  {
    name: "Turkmenistan",
    code: "TM",
    region: "Asia",
    states: [
      { name: "Ahal", code: "A", cities: ["Ashgabat", "Anau", "Babadayhan", "Gokdepe", "Kaka", "Tejen", "Altyn Asyr", "Berkararlyk", "Ruhabat", "Choganly"] },
      { name: "Balkan", code: "B", cities: ["Balkanabat", "Turkmenbashi", "Bereket", "Gumdag", "Kazanjik", "Krasnovodsk", "Cheleken", "Hazar", "Esenguly", "Gyzylarbat"] },
      { name: "Mary", code: "M", cities: ["Mary", "Bayramaly", "Yoloten", "Murgab", "Tagtabazar", "Vekilbazar", "Sandykachi", "Sakarchage", "Garrygala", "Murghab"] }
    ]
  },

  // NEPAL
  {
    name: "Nepal",
    code: "NP",
    region: "Asia",
    states: [
      { name: "Bagmati Province", code: "3", cities: ["Kathmandu", "Lalitpur", "Bhaktapur", "Kirtipur", "Madhyapur Thimi", "Gokarneshwar", "Budhanilkantha", "Dakshinkali", "Nagarjun", "Kageshwari Manohara"] },
      { name: "Gandaki Province", code: "4", cities: ["Pokhara", "Gorkha", "Lamjung", "Tanahu", "Syangja", "Kaski", "Parbat", "Baglung", "Myagdi", "Mustang"] },
      { name: "Lumbini Province", code: "5", cities: ["Butwal", "Bhairahawa", "Taulihawa", "Ghorahi", "Tulsipur", "Nepalgunj", "Kohalpur", "Lamahi", "Rapti", "Musikot"] }
    ]
  },

  // BHUTAN
  {
    name: "Bhutan",
    code: "BT",
    region: "Asia",
    states: [
      { name: "Thimphu", code: "11", cities: ["Thimphu", "Serbithang", "Babesa", "Lungtenphu", "Hejo", "Taba", "Dechencholing", "Kawajangsa", "Simtokha", "Changzamtog"] },
      { name: "Paro", code: "33", cities: ["Paro", "Drugyal", "Lamgong", "Shapa", "Wangdue", "Dogar", "Hungrel", "Tsento", "Dopshari", "Doteng"] },
      { name: "Punakha", code: "23", cities: ["Punakha", "Wangdue", "Lobesa", "Toewang", "Dzomi", "Shengana", "Guma", "Toedwang", "Chhubu", "Talo"] }
    ]
  },

  // MONGOLIA
  {
    name: "Mongolia",
    code: "MN",
    region: "Asia",
    states: [
      { name: "Ulaanbaatar", code: "1", cities: ["Ulaanbaatar", "Nalaikh", "Bagakhangai", "Baganuur", "Bagануур", "Sonsgolon", "Zaisan", "Khan Uul", "Bayangol", "Bayanzurkh"] },
      { name: "Darkhan-Uul", code: "37", cities: ["Darkhan", "Khongor", "Sharyngol", "Orkhon", "Shaamar", "Kharaa", "Tsagaan-Uul", "Zuun-Mod", "Dulaankhaan", "Hongor"] },
      { name: "Erdenet", code: "65", cities: ["Erdenet", "Bayan-Ondor", "Jargalant", "Mandal", "Orkhon", "Bayan", "Saikhan", "Khatgal", "Shine-Ider", "Murun"] }
    ]
  },

  // AUSTRALIA (completing the 195 countries)
  {
    name: "Australia",
    code: "AU",
    region: "Oceania",
    states: [
      { name: "New South Wales", code: "NSW", cities: ["Sydney", "Newcastle", "Wollongong", "Central Coast", "Maitland", "Albury", "Wagga Wagga", "Port Macquarie", "Tamworth", "Orange"] },
      { name: "Victoria", code: "VIC", cities: ["Melbourne", "Geelong", "Ballarat", "Bendigo", "Frankston", "Melton", "Casey", "Monash", "Latrobe", "Greater Dandenong"] },
      { name: "Queensland", code: "QLD", cities: ["Brisbane", "Gold Coast", "Townsville", "Cairns", "Toowoomba", "Mackay", "Rockhampton", "Bundaberg", "Hervey Bay", "Gladstone"] },
      { name: "Western Australia", code: "WA", cities: ["Perth", "Mandurah", "Bunbury", "Kalgoorlie", "Geraldton", "Albany", "Busselton", "Broome", "Port Hedland", "Karratha"] },
      { name: "South Australia", code: "SA", cities: ["Adelaide", "Mount Gambier", "Whyalla", "Murray Bridge", "Port Lincoln", "Port Pirie", "Victor Harbor", "Gawler", "Port Augusta", "Mount Barker"] },
      { name: "Tasmania", code: "TAS", cities: ["Hobart", "Launceston", "Devonport", "Burnie", "Somerset", "Wynyard", "Smithton", "George Town", "St Helens", "Queenstown"] },
      { name: "Australian Capital Territory", code: "ACT", cities: ["Canberra", "Gungahlin", "Tuggeranong", "Weston Creek", "Woden", "Belconnen", "Molonglo Valley", "Jerrabomberra", "Queanbeyan", "Fyshwick"] },
      { name: "Northern Territory", code: "NT", cities: ["Darwin", "Alice Springs", "Palmerston", "Katherine", "Nhulunbuy", "Tennant Creek", "Jabiru", "Yulara", "Pine Creek", "Mataranka"] }
    ]
  },

  // NEW ZEALAND
  {
    name: "New Zealand",
    code: "NZ",
    region: "Oceania",
    states: [
      { name: "Auckland", code: "AUK", cities: ["Auckland", "Manukau", "North Shore", "Waitakere", "Papakura", "Franklin", "Rodney", "Henderson", "Albany", "Botany Downs"] },
      { name: "Wellington", code: "WGN", cities: ["Wellington", "Lower Hutt", "Upper Hutt", "Porirua", "Kapiti Coast", "Masterton", "Carterton", "South Wairarapa", "Featherston", "Greytown"] },
      { name: "Canterbury", code: "CAN", cities: ["Christchurch", "Timaru", "Ashburton", "Rangiora", "Rolleston", "Lincoln", "Kaiapoi", "Prebbleton", "Methven", "Geraldine"] }
    ]
  },

  // ADDITIONAL OCEANIA COUNTRIES
  {
    name: "Papua New Guinea",
    code: "PG",
    region: "Oceania",
    states: [
      { name: "National Capital District", code: "NCD", cities: ["Port Moresby", "Boroko", "Gordons", "Gerehu", "Waigani", "Hohola", "Korobosea", "Sabama", "Badili", "Kila Kila"] },
      { name: "Western Highlands", code: "WHP", cities: ["Mount Hagen", "Tambul", "Mul", "Baiyer River", "Kagua", "Kutubu", "Koroba", "Margarima", "Tari", "Komo"] },
      { name: "Morobe", code: "MPL", cities: ["Lae", "Wau", "Bulolo", "Madang", "Finschhafen", "Morobe", "Tewae-Siassi", "Huon", "Kabwum", "Markham"] }
    ]
  },
  {
    name: "Fiji",
    code: "FJ",
    region: "Oceania",
    states: [
      { name: "Central Division", code: "C", cities: ["Suva", "Nasinu", "Lami", "Nausori", "Navua", "Korovou", "Vunidawa", "Tailevu", "Rewa", "Serua"] },
      { name: "Western Division", code: "W", cities: ["Lautoka", "Nadi", "Ba", "Tavua", "Sigatoka", "Vatukoula", "Rakiraki", "Nadarivatu", "Keiyasi", "Yasawa"] },
      { name: "Northern Division", code: "N", cities: ["Labasa", "Savusavu", "Nabouwalu", "Seaqaqa", "Dreketi", "Korotogo", "Viani", "Natewa", "Rabi", "Kioa"] }
    ]
  },
  {
    name: "Solomon Islands",
    code: "SB",
    region: "Oceania",
    states: [
      { name: "Guadalcanal", code: "GU", cities: ["Honiara", "Marau", "Tetere", "Tandai", "Aola", "Malango", "Duidui", "Makaruka", "Ruaniu", "Longgu"] },
      { name: "Malaita", code: "ML", cities: ["Auki", "Kirakira", "Malu'u", "Afio", "Fauabu", "Gulalofou", "Takwa", "Fouia", "Kwai", "Langa Langa"] },
      { name: "Western Province", code: "WE", cities: ["Gizo", "Munda", "Taro Island", "Choiseul Bay", "Ringgi", "Sasamunga", "Noro", "Kolombangara", "Vona Vona", "Shortland"] }
    ]
  },
  {
    name: "Vanuatu",
    code: "VU",
    region: "Oceania",
    states: [
      { name: "Shefa", code: "SEE", cities: ["Port Vila", "Forari", "Erakor", "Tagabe", "Anabrou", "Eratap", "Ifira", "Pango", "Blacksands", "Freswota"] },
      { name: "Sanma", code: "SAM", cities: ["Luganville", "Port Olry", "Hog Harbour", "Fanafo", "Saratamata", "Canal", "Turtle Bay", "Matantas", "Champagne Beach", "Lonnoc"] },
      { name: "Tafea", code: "TAE", cities: ["Isangel", "Lenakel", "Whitegrass", "Aneityum", "Futuna", "Aniwa", "Ipota", "Kwamera", "Imaki", "Port Resolution"] }
    ]
  },
  {
    name: "Samoa",
    code: "WS",
    region: "Oceania",
    states: [
      { name: "Upolu", code: "UPO", cities: ["Apia", "Vaitele", "Faleolo", "Mulifanua", "Leulumoega", "Falelatai", "Lotofaga", "Siumu", "Falealupo", "Safotulafai"] },
      { name: "Savai'i", code: "SAV", cities: ["Salelologa", "Asau", "Safotulafai", "Fagamalo", "Patamea", "Vaisala", "Gautavai", "Lano", "Saleaula", "Safune"] }
    ]
  },
  {
    name: "Tonga",
    code: "TO",
    region: "Oceania",
    states: [
      { name: "Tongatapu", code: "01", cities: ["Nuku'alofa", "Mu'a", "Tatakamotonga", "Vaini", "Havelu", "Pea", "Lapaha", "Kolofo'ou", "Kolomotu'a", "Sopu"] },
      { name: "Vava'u", code: "02", cities: ["Neiafu", "Tu'anekivale", "Holonga", "Toula", "Makave", "Longomapu", "Faleloa", "Pangai", "Leimatu'a", "'Utulei"] },
      { name: "Ha'apai", code: "03", cities: ["Pangai", "Hihifo", "Koulo", "Holopeka", "Ha'ano", "Foa", "Lifuka", "Uiha", "Tatafa", "Nukunuku"] }
    ]
  },
  {
    name: "Kiribati",
    code: "KI",
    region: "Oceania",
    states: [
      { name: "Gilbert Islands", code: "G", cities: ["South Tarawa", "Betio", "Bairiki", "Bikenibeu", "Teaoraereke", "Banraeaba", "Eita", "Nawerewere", "Bonriki", "Tanaea"] },
      { name: "Line Islands", code: "L", cities: ["Kiritimati", "Tabuaeran", "Teraina", "Caroline Island", "Flint Island", "Vostok Island", "Starbuck Island", "Malden Island", "Jarvis Island", "Palmyra"] },
      { name: "Phoenix Islands", code: "P", cities: ["Kanton", "Enderbury Island", "Birnie Island", "McKean Island", "Rawaki", "Manra", "Orona", "Nikumaroro", "Phoenix Islands", "Howland"] }
    ]
  },
  {
    name: "Tuvalu",
    code: "TV",
    region: "Oceania",
    states: [
      { name: "Funafuti", code: "FUN", cities: ["Funafuti", "Vaiaku", "Alapi", "Senala", "Tengasu", "Tutanga", "Lofeagai", "Papa", "Mulitefala", "Tekavatoetoe"] },
      { name: "Nanumea", code: "NME", cities: ["Nanumea", "Lolua", "Tonga", "Lakena", "Tokelau", "Holonga", "Tepuka", "Sikulua", "Nanumea Lasi", "Nanumea Iti"] },
      { name: "Nui", code: "NUI", cities: ["Nui", "Tanrake", "Alamai", "Meang", "Tekaumea", "Unimai", "Taumaleke", "Apifolau", "Pongalei", "Amatuku"] }
    ]
  },
  {
    name: "Nauru",
    code: "NR",
    region: "Oceania",
    states: [
      { name: "Aiwo", code: "01", cities: ["Aiwo", "Denigomodu", "Nibok", "Uaboe", "Baiti", "Ewa", "Location", "Ronave", "Topside", "Command Ridge"] },
      { name: "Anabar", code: "02", cities: ["Anabar", "Ijuw", "Anibare", "Meneng", "Buada", "Anetan", "Boe", "Yaren", "Anibare Bay", "Anibare Harbour"] },
      { name: "Anetan", code: "03", cities: ["Anetan", "Boe", "Yaren", "Buada", "Denigomodu", "Ewa", "Ijuw", "Meneng", "Nibok", "Uaboe"] }
    ]
  },
  {
    name: "Palau",
    code: "PW",
    region: "Oceania",
    states: [
      { name: "Koror", code: "002", cities: ["Koror", "Airai", "Ngerulmud", "Meyungs", "Ngardmau", "Ngiwal", "Ngaraard", "Ngeremlengui", "Aimeliik", "Peleliu"] },
      { name: "Airai", code: "004", cities: ["Airai", "Babeldaob", "Ngerulmud", "Medalaii", "Ngetkib", "Ngerkeai", "Ngeruluobel", "Ngchesar", "Ngardmau", "Ngiwal"] },
      { name: "Babeldaob", code: "050", cities: ["Melekeok", "Ngardmau", "Ngeremlengui", "Ngiwal", "Ngaraard", "Ngchesar", "Aimeliik", "Airai", "Koror", "Kayangel"] }
    ]
  },
  {
    name: "Marshall Islands",
    code: "MH",
    region: "Oceania",
    states: [
      { name: "Majuro", code: "MAJ", cities: ["Majuro", "Delap-Uliga-Djarrit", "Rita", "Ajeltake", "Rairok", "Jenrok", "Saide", "Woja", "Laura", "Ejit"] },
      { name: "Kwajalein", code: "KWA", cities: ["Ebeye", "Kwajalein", "Roi-Namur", "Carlos", "Enniburr", "Illeginni", "Legan", "Omelek", "Gagan", "Gellinam"] },
      { name: "Arno", code: "ARN", cities: ["Arno", "Ine", "Kobjeltak", "Rearlaplap", "Tutu", "Ajeltokrok", "Bokanbotok", "Jeh", "Dilapelap", "Barrigada"] }
    ]
  },
  {
    name: "Federated States of Micronesia",
    code: "FM",
    region: "Oceania",
    states: [
      { name: "Pohnpei", code: "PNI", cities: ["Palikir", "Kolonia", "Madolenihmw", "Kitti", "Net", "Nett", "Sokehs", "Sapwuahfik", "Mokil", "Pingelap"] },
      { name: "Chuuk", code: "TRK", cities: ["Weno", "Tonoas", "Fefan", "Uman", "Tol", "Udot", "Romanum", "Eot", "Fanapanges", "Pis"] },
      { name: "Yap", code: "YAP", cities: ["Colonia", "Rull", "Fanif", "Weloy", "Tomil", "Gagil", "Gilman", "Maap", "Rumung", "Kanifay"] }
    ]
  }
];

// Helper functions for accessing location data
export function getAllCountries(): string[] {
  return worldwideLocationData.map(country => country.name).sort();
}

export function getAllStatesByCountry(countryName: string): string[] {
  const country = worldwideLocationData.find(c => c.name === countryName);
  return country ? country.states.map(state => state.name).sort() : [];
}

export function getAllCitiesByState(countryName: string, stateName: string): string[] {
  const country = worldwideLocationData.find(c => c.name === countryName);
  if (!country) return [];
  
  const state = country.states.find(s => s.name === stateName);
  return state ? state.cities.sort() : [];
}

export function getCountriesByRegion(region: string): string[] {
  return worldwideLocationData
    .filter(country => country.region === region)
    .map(country => country.name)
    .sort();
}