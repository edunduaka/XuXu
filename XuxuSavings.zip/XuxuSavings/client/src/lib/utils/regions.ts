// Regions utility for the registration system
// This handles the region filtering for the location dropdown

import { getMiddleEastCountries } from './middle-east-countries';
import { worldwideLocationData } from './comprehensive-world-locations';

// Function to get countries by region
export const getCountriesByRegion = (region: string): string[] => {
  // Handle Middle East region specially since we have a dedicated list
  if (region === "Middle East") {
    return getMiddleEastCountries();
  }
  
  // For other regions, use the standard worldwide location data
  return worldwideLocationData
    .filter(country => country.region === region)
    .map(country => country.name)
    .sort();
};