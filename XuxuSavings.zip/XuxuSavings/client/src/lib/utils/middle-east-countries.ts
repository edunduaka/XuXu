// Middle East Countries Data
// This defines all countries in the Middle East region for the registration system

export interface MiddleEastCountry {
  name: string;
  code: string;
}

export const middleEastCountries: MiddleEastCountry[] = [
  { name: "Bahrain", code: "BH" },
  { name: "Cyprus", code: "CY" },
  { name: "Egypt", code: "EG" },
  { name: "Iran", code: "IR" },
  { name: "Iraq", code: "IQ" },
  { name: "Israel", code: "IL" },
  { name: "Jordan", code: "JO" },
  { name: "Kuwait", code: "KW" },
  { name: "Lebanon", code: "LB" },
  { name: "Oman", code: "OM" },
  { name: "Palestine", code: "PS" },
  { name: "Qatar", code: "QA" },
  { name: "Saudi Arabia", code: "SA" },
  { name: "Syria", code: "SY" },
  { name: "Turkey", code: "TR" },
  { name: "United Arab Emirates", code: "AE" },
  { name: "Yemen", code: "YE" }
];

// Helper function to get all Middle East country names
export const getMiddleEastCountries = (): string[] => {
  return middleEastCountries.map(country => country.name).sort();
};