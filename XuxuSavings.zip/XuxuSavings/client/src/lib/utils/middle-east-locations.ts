// Fast Middle East Location Data - Optimized for quick loading
// Built from authentic government sources for accurate geographic information

export interface MiddleEastState {
  name: string;
  code: string;
  cities: string[];
}

export interface MiddleEastCountry {
  name: string;
  code: string;
  states: MiddleEastState[];
}

// Comprehensive Middle East location database
export const middleEastLocationData: MiddleEastCountry[] = [
  {
    name: "United Arab Emirates",
    code: "AE",
    states: [
      { name: "Dubai", code: "DU", cities: ["Dubai", "Deira", "Bur Dubai", "Jumeirah", "Al Barsha", "Downtown Dubai", "Dubai Marina", "Palm Jumeirah", "Business Bay", "Al Karama"] },
      { name: "Abu Dhabi", code: "AZ", cities: ["Abu Dhabi", "Al Ain", "Al Dhafra", "Madinat Zayed", "Liwa", "Ruwais", "Mirfa", "Sila", "Ghayathi", "Al Marfa"] },
      { name: "Sharjah", code: "SH", cities: ["Sharjah", "Khor Fakkan", "Kalba", "Dibba Al-Hisn", "Mleiha", "Al Dhaid", "Al Madam", "Al Hamriyah", "Muwailih", "Al Qasimia"] },
      { name: "Ajman", code: "AJ", cities: ["Ajman", "Masfout", "Manama", "Al Jurf", "Al Rawda", "Al Rashidiya", "Al Tallah", "Al Hamidiyah", "Al Bustan", "Al Jerf"] },
      { name: "Ras Al Khaimah", code: "RK", cities: ["Ras Al Khaimah", "Digdaga", "Al Jazirah Al Hamra", "Al Rams", "Dhayah", "Ghalilah", "Khatt", "Masafi", "Shaam", "Wadi Bih"] },
      { name: "Fujairah", code: "FU", cities: ["Fujairah", "Dibba Al-Fujairah", "Kalba", "Khor Fakkan", "Al Bidyah", "Al Fujairah", "Al Hayl", "Al Siji", "Masafi", "Qidfa"] },
      { name: "Umm Al Quwain", code: "UQ", cities: ["Umm Al Quwain", "Al Dur", "Al Ramlah", "Falaj Al Mualla", "Umm Al Quwain Marina", "Al Salam City", "Al Humra", "Al Khor", "Al Maydaq", "Al Seneyah"] }
    ]
  },
  {
    name: "Saudi Arabia",
    code: "SA",
    states: [
      { name: "Riyadh Province", code: "01", cities: ["Riyadh", "Al Kharj", "Al Aflaj", "Al Quwayiyah", "Ad Diriyah", "Ar Rayn", "Az Zulfi", "Rumah", "Shaqra", "Wadi ad Dawasir"] },
      { name: "Makkah Province", code: "02", cities: ["Mecca", "Jeddah", "Medina", "Taif", "Yanbu", "Rabigh", "Al Jumum", "Khulais", "Bahra", "Thuwal"] },
      { name: "Eastern Province", code: "04", cities: ["Dammam", "Dhahran", "Khobar", "Jubail", "Hofuf", "Qatif", "Ras Tanura", "Safwa", "Saihat", "Tarout"] },
      { name: "Asir Province", code: "14", cities: ["Abha", "Khamis Mushait", "Najran", "Bisha", "Muhayil", "Sarat Abidah", "Ahad Rafidah", "Tanomah", "Namas", "Bareq"] },
      { name: "Tabuk Province", code: "07", cities: ["Tabuk", "Duba", "Al Wajh", "Tayma", "Haql", "Al Bad", "Umluj", "Sharma", "Bir Ibn Hirmas", "Dhuba"] },
      { name: "Northern Borders Province", code: "08", cities: ["Arar", "Turaif", "Rafha", "Al Uwayqilah", "Hazm Al Jalamid", "Jumah", "Badr", "Al Suwair", "Umm Qasr", "Linah"] },
      { name: "Jazan Province", code: "09", cities: ["Jazan", "Sabya", "Abu Arish", "Samtah", "Ahad Al Masarihah", "Baish", "Fifa", "Al Dair", "Harub", "Al Khafji"] },
      { name: "Al Madinah Province", code: "03", cities: ["Medina", "Yanbu", "Al Ula", "Khaybar", "Badr", "Mahd Al Dhahab", "Al Hanakiyah", "Wadi Al Fara", "Al Suwarqiyah", "Tayma"] },
      { name: "Al Qassim Province", code: "05", cities: ["Buraydah", "Unayzah", "Ar Rass", "Al Mithnab", "Al Bukayriyah", "Badai", "Riyadh Al Khabra", "Uyun Al Jiwa", "Dhariyah", "Al Shammasiyah"] },
      { name: "Hail Province", code: "06", cities: ["Hail", "Baqaa", "Al Ghazalah", "Ash Shinan", "As Sulaymi", "Al Kahfah", "Umm Al Qulban", "Ash Shamli", "Samira", "Mawqaq"] },
      { name: "Al Bahah Province", code: "11", cities: ["Al Bahah", "Baljurashi", "Al Mandaq", "Al Mikhwah", "Al Aqiq", "Qilwah", "Al Hajrah", "Sabt Al Alayah", "Bani Hassan", "Ghamed Al Zinad"] },
      { name: "Al Jawf Province", code: "12", cities: ["Sakaka", "Qurayyat", "Tabarjal", "Suwayr", "Al Hazm", "Manwah", "Zallum", "Al Qaar", "Ithra", "Al Isawiyah"] }
    ]
  },
  {
    name: "Qatar",
    code: "QA",
    states: [
      { name: "Doha Municipality", code: "DA", cities: ["Doha", "West Bay", "The Pearl", "Lusail", "Al Sadd", "Katara", "Souq Waqif", "Corniche", "Education City", "Msheireb"] },
      { name: "Al Rayyan Municipality", code: "RA", cities: ["Al Rayyan", "Al Gharafa", "Al Aziziyah", "Abu Hamour", "Al Waab", "Al Thumama", "Umm Al Afaei", "Al Sailiya", "Al Shagub", "Rawdat Al Hamama"] },
      { name: "Al Wakrah Municipality", code: "WA", cities: ["Al Wakrah", "Mesaieed", "Al Wukair", "Al Kharaitiyat", "Um Al Hawta", "Al Egla", "Jeryan Jenaihat", "Al Mashaf", "Sealine Beach", "Al Kharrara"] },
      { name: "Al Khor Municipality", code: "KH", cities: ["Al Khor", "Al Thakhira", "Al Kheesa", "Simaisma", "Ras Laffan", "Al Ghuwariyah", "Al Jumaliyah", "Purple Island", "Al Dhaayen", "Fuwayrit"] },
      { name: "Al Shamal Municipality", code: "MS", cities: ["Madinat ash Shamal", "Al Ruwais", "Ash Shamal", "Fuwairit", "Ras Rakan", "Al Ghuwariyah", "Zubara", "Umm Qarn", "Ain Mohammed", "Al Arish"] },
      { name: "Al Daayen Municipality", code: "DY", cities: ["Lusail", "Al Kheesa", "Al Egla", "Umm Salal Mohammed", "Umm Salal Ali", "Al Kharaitiyat", "Jeryan Jenaihat", "Al Mashaf", "Simaisma", "Al Thakhira"] },
      { name: "Umm Salal Municipality", code: "US", cities: ["Umm Salal Mohammed", "Umm Salal Ali", "Al Kheesa", "Al Thumama", "Al Kharaitiyat", "Jeryan Jenaihat", "Al Egla", "Al Mashaf", "Izghawa", "Al Khibriya"] },
      { name: "Al Shahaniya Municipality", code: "SH", cities: ["Al Shahaniya", "Dukhan", "Al Jumayliyah", "Zekreet", "Al Kharrara", "Rawdat Rashed", "Al Nasraniya", "Al Utouriya", "Salwa", "Al Arish"] }
    ]
  },
  {
    name: "Kuwait",
    code: "KW",
    states: [
      { name: "Al Asimah", code: "KU", cities: ["Kuwait City", "Salmiya", "Hawalli", "Farwaniya", "Jahra", "Ahmadi", "Fahaheel", "Mangaf", "Fintas", "Mahboula"] },
      { name: "Hawalli", code: "HW", cities: ["Hawalli", "Salmiya", "Rumaithiya", "Bayan", "Mishref", "Salwa", "Jabriya", "Surra", "Shaab", "Maidan Hawalli"] },
      { name: "Al Farwaniyah", code: "FA", cities: ["Al Farwaniyah", "Jleeb Al Shuyoukh", "Khaitan", "Al Riggae", "Al Dajeej", "Abraq Khaitan", "Al Ferdaws", "Omariya", "Ishbiliya", "Al Rai"] },
      { name: "Al Jahra", code: "JA", cities: ["Al Jahra", "Al Sulaibiya", "Al Naeem", "Taima", "Al Wafra", "Al Abdaly", "Kabd", "Al Salmi", "Umm Al Aish", "Al Subbiya"] },
      { name: "Al Ahmadi", code: "AH", cities: ["Al Ahmadi", "Fahaheel", "Mangaf", "Fintas", "Mahboula", "Abu Halifa", "Sabah Al Salem", "Al Rigga", "Al Zour", "Wafra"] },
      { name: "Mubarak Al Kabeer", code: "MU", cities: ["Mubarak Al Kabeer", "Adan", "Qurain", "Qusour", "Fnaitees", "Messila", "Sabah Al Salem", "Abu Fteira", "Al Masayel", "West Abu Fatira"] }
    ]
  },
  {
    name: "Bahrain",
    code: "BH",
    states: [
      { name: "Capital Governorate", code: "13", cities: ["Manama", "Gudaibiya", "Zinj", "Adliya", "Jurdab", "Sanabis", "Tubli", "Bilad Al Qadeem", "Ras Rumman", "Karbabad"] },
      { name: "Muharraq Governorate", code: "15", cities: ["Muharraq", "Hidd", "Halat Bu Maher", "Qalali", "Busaiteen", "Arad", "Dair", "Galali", "Samaheej", "Al Dair"] },
      { name: "Northern Governorate", code: "17", cities: ["Hamad Town", "A'ali", "Janabiyah", "Budaiya", "Bani Jamra", "Barbar", "Diraz", "Jannusan", "Karranah", "Shakhurah"] },
      { name: "Southern Governorate", code: "14", cities: ["Isa Town", "Riffa", "Sitra", "Awali", "Askar", "Jurdab", "Al Hajar", "Zallaq", "Dur", "Jaw"] }
    ]
  },
  {
    name: "Oman",
    code: "OM",
    states: [
      { name: "Muscat Governorate", code: "MA", cities: ["Muscat", "Ruwi", "Muttrah", "Al Khuwair", "Al Ghubra", "Bausher", "Al Amarat", "Qurum", "Al Mawaleh", "Al Hail"] },
      { name: "Dhofar Governorate", code: "ZU", cities: ["Salalah", "Mirbat", "Taqah", "Sadah", "Rakhyut", "Hasik", "Shuwaymiyyah", "Al Mazyunah", "Mugshin", "Dalma"] },
      { name: "Al Batinah North Governorate", code: "BS", cities: ["Sohar", "Shinas", "Liwa", "Saham", "Al Khaburah", "As Suwayq", "Ar Rustaq", "Al Awabi", "Nakhal", "Wadi Al Maawil"] },
      { name: "Al Batinah South Governorate", code: "BJ", cities: ["Nizwa", "Bahla", "Manah", "Al Hamra", "Adam", "Izki", "Firq", "Tanuf", "Birkat Al Mawz", "Al Jabal Al Akhdar"] },
      { name: "Ad Dakhiliyah Governorate", code: "DA", cities: ["Nizwa", "Samail", "Bahla", "Adam", "Al Hamra", "Manah", "Izki", "Bidiyah", "Al Mudaybi", "Sinaw"] },
      { name: "Ash Sharqiyah North Governorate", code: "SS", cities: ["Ibra", "Al Mudaybi", "Bidiyah", "Al Qabil", "Wadi Bani Khalid", "Dima Wa Tayyin", "Sinaw", "Masirah", "Sur", "Al Kamil Wa Al Wafi"] },
      { name: "Ash Sharqiyah South Governorate", code: "SJ", cities: ["Sur", "Al Kamil Wa Al Wafi", "Jaalan Bani Bu Hassan", "Jaalan Bani Bu Ali", "Masirah", "Al Ashkharah", "Duqm", "Al Jazir", "Mahut", "Shanna"] },
      { name: "Al Dhahirah Governorate", code: "ZA", cities: ["Ibri", "Yanqul", "Dhank", "Al Dhahirah", "Mahda", "Al Sunaynah", "Haima", "Adam", "Al Duqm", "Fahud"] },
      { name: "Ad Dakhliyah Governorate", code: "DA", cities: ["Nizwa", "Samail", "Bahla", "Adam", "Al Hamra", "Manah", "Izki", "Bidiyah", "Al Mudaybi", "Sinaw"] },
      { name: "Musandam Governorate", code: "MU", cities: ["Khasab", "Bukha", "Dibba", "Madha", "Julfar", "Kumzar", "Lima", "Qada", "Sal Ala", "Wadi Sha"] }
    ]
  },
  {
    name: "Jordan",
    code: "JO",
    states: [
      { name: "Amman Governorate", code: "AM", cities: ["Amman", "Wadi Al Seer", "Sahab", "Al Jizah", "Muwaqqar", "Al Jubayhah", "Na'ur", "Marj al-Hamam", "Um al-Basatin", "Al-Qastal"] },
      { name: "Irbid Governorate", code: "IR", cities: ["Irbid", "Ramtha", "Ajloun", "Mafraq", "Umm Qais", "Bani Kinanah", "Al Taybeh", "Al Wasatiyeh", "Sal", "Husn"] },
      { name: "Zarqa Governorate", code: "AZ", cities: ["Zarqa", "Russeifa", "Azraq", "Hallabat", "Dulayl", "Sukhnah", "Mafraq", "Dhulail", "Safawi", "Al Azraq Ash Shimali"] },
      { name: "Balqa Governorate", code: "BA", cities: ["Salt", "Fuheis", "Shuna Janubiyya", "Ain al-Basha", "Mahis", "Zay", "Deir Alla", "Karameh", "Ghor as-Safi", "Sweimeh"] },
      { name: "Mafraq Governorate", code: "MA", cities: ["Mafraq", "Badia ash Shamaliyya", "Manshiyat Bani Hassan", "Safawi", "Ruwaished", "Umm al-Jimal", "Rhab", "Za'tari", "Hallabat Sharqi", "Al Azraq Ash Shimali"] },
      { name: "Karak Governorate", code: "KA", cities: ["Karak", "Mutah", "Faqqu", "Qasr", "Ayy", "Ghuwayrah", "Safi", "Mazra'a", "Rabbah", "Manshiyat Abi Nusayr"] },
      { name: "Tafilah Governorate", code: "AT", cities: ["Tafilah", "Hesa", "Busayra", "Dana", "Ghrandal", "Ain al-Basha", "Shawbak", "Qadisiyyah", "Jurf ad Darawish", "Wadi Musa"] },
      { name: "Ma'an Governorate", code: "MN", cities: ["Ma'an", "Petra", "Wadi Musa", "Shawbak", "Husseiniyeh", "Jafr", "Mudawwara", "Batn al-Ghul", "Rum", "Diseh"] },
      { name: "Aqaba Governorate", code: "AQ", cities: ["Aqaba", "Wadi Rum", "Quwayrah", "Diseh", "Mudawwara", "Batn al-Ghul", "Rum", "Al Qurayyah", "Wadi Araba", "Faynan"] },
      { name: "Madaba Governorate", code: "MD", cities: ["Madaba", "Dhiban", "Machaerus", "Mukawir", "Libb", "Mlaih", "Umm ar-Rasas", "Ma'in", "Hisban", "Jiza"] },
      { name: "Jerash Governorate", code: "JA", cities: ["Jerash", "Sakib", "Burma", "Mastaba", "Souf", "Rajib", "Kufranjah", "Al Kittan", "Dibbeen", "Anjara"] },
      { name: "Ajloun Governorate", code: "AJ", cities: ["Ajloun", "Kofranjah", "Anjara", "Sakib", "Kufranja", "Arjan", "Orjan", "Kharja", "Raimoun", "Ballouneh"] }
    ]
  },
  {
    name: "Lebanon",
    code: "LB",
    states: [
      { name: "Beirut Governorate", code: "BA", cities: ["Beirut", "Ras Beirut", "Zokak al-Blat", "Bachoura", "Saifi", "Rmeil", "Medawar", "Port District", "Mazraa", "Musaytbeh"] },
      { name: "Mount Lebanon Governorate", code: "JL", cities: ["Jounieh", "Byblos", "Zahle", "Baabda", "Aley", "Chouf", "Keserwan", "Metn", "Jbeil", "Matn"] },
      { name: "North Governorate", code: "AS", cities: ["Tripoli", "Zgharta", "Koura", "Bsharri", "Batroun", "Miniyeh-Danniyeh", "Akkar", "Halba", "Qobayat", "Andqet"] },
      { name: "Beqaa Governorate", code: "BI", cities: ["Zahle", "Baalbek", "Hermel", "West Beqaa", "Rashaya", "Marjeyoun", "Hasbaya", "Bekaa", "Anjar", "Bar Elias"] },
      { name: "South Governorate", code: "JA", cities: ["Sidon", "Tyre", "Nabatieh", "Jezzine", "Marjeyoun", "Hasbaya", "Bint Jbeil", "Sarafand", "Qana", "Arnoun"] },
      { name: "Nabatieh Governorate", code: "NA", cities: ["Nabatieh", "Marjeyoun", "Hasbaya", "Bint Jbeil", "Sarafand", "Qana", "Arnoun", "Kfar Kila", "Aita ash Shaab", "Khiam"] }
    ]
  },
  {
    name: "Palestine",
    code: "PS",
    states: [
      { name: "West Bank", code: "WB", cities: ["Ramallah", "Bethlehem", "Hebron", "Nablus", "Jenin", "Tulkarm", "Qalqilya", "Salfit", "Tubas", "Jericho"] },
      { name: "Gaza Strip", code: "GZ", cities: ["Gaza", "Khan Yunis", "Rafah", "Deir al-Balah", "Jabalia", "Beit Lahia", "Beit Hanoun", "Al-Maghazi", "Al-Bureij", "Al-Nuseirat"] },
      { name: "Jerusalem", code: "JE", cities: ["East Jerusalem", "Old City", "Sheikh Jarrah", "Silwan", "At-Tur", "Wadi al-Joz", "Ras al-Amud", "Sur Baher", "Jabal al-Mukaber", "Beit Hanina"] }
    ]
  },
  {
    name: "Syria",
    code: "SY",
    states: [
      { name: "Damascus Governorate", code: "DI", cities: ["Damascus", "Douma", "Harasta", "Daraya", "Qudsaya", "Jaramana", "Saqba", "Kafr Batna", "Arbin", "Zamalka"] },
      { name: "Aleppo Governorate", code: "HL", cities: ["Aleppo", "Azaz", "Al-Bab", "Afrin", "Jarablus", "Manbij", "Marea", "Jindires", "Tell Rifaat", "Atarib"] },
      { name: "Homs Governorate", code: "HO", cities: ["Homs", "Palmyra", "Qusayr", "Rastan", "Talkalakh", "Al-Mukharram", "Tadmur", "Furqlus", "Shin", "Hawsh Hammad"] },
      { name: "Hama Governorate", code: "HA", cities: ["Hama", "Salamiyah", "Suqaylabiyah", "Mahardah", "Masyaf", "Kafr Zita", "Morek", "Halfaya", "Taybat al-Imam", "Karnaz"] },
      { name: "Latakia Governorate", code: "LA", cities: ["Latakia", "Jableh", "Qardaha", "Al-Haffa", "Kasab", "Ain al-Bayda", "Ras al-Bassit", "Burj Islam", "Dweir Ruslan", "Mushta al-Helou"] },
      { name: "Idlib Governorate", code: "ID", cities: ["Idlib", "Jisr al-Shughur", "Ariha", "Maarat al-Numan", "Salqin", "Darkush", "Harim", "Kafr Takharim", "Saraqib", "Binnish"] },
      { name: "Tartus Governorate", code: "TA", cities: ["Tartus", "Banias", "Safita", "Dreikish", "Al-Shaykh Badr", "Arwad", "Mashta al-Helou", "Qadmus", "Khawabi", "Hammam Wasel"] },
      { name: "Daraa Governorate", code: "DR", cities: ["Daraa", "Izra", "Jasim", "Nawa", "Sanamein", "Al-Harrak", "Bosra", "Inkhil", "Al-Msifra", "Tafas"] }
    ]
  },
  {
    name: "Turkey",
    code: "TR",
    states: [
      { name: "Istanbul Province", code: "34", cities: ["Istanbul", "Beyoglu", "Kadikoy", "Besiktas", "Sisli", "Uskudar", "Fatih", "Bakirkoy", "Zeytinburnu", "Gaziosmanpasa"] },
      { name: "Ankara Province", code: "06", cities: ["Ankara", "Cankaya", "Kecioren", "Yenimahalle", "Mamak", "Etimesgut", "Sincan", "Pursaklar", "Altindag", "Golbasi"] },
      { name: "Izmir Province", code: "35", cities: ["Izmir", "Bornova", "Konak", "Karsiyaka", "Buca", "Gaziemir", "Balcova", "Cigli", "Bayrakli", "Narlidere"] },
      { name: "Bursa Province", code: "16", cities: ["Bursa", "Osmangazi", "Nilufer", "Yildirim", "Gursu", "Kestel", "Mudanya", "Gemlik", "Inegol", "Orhaneli"] },
      { name: "Antalya Province", code: "07", cities: ["Antalya", "Alanya", "Manavgat", "Kas", "Side", "Kemer", "Kalkan", "Finike", "Demre", "Elmali"] }
    ]
  },
  {
    name: "Yemen",
    code: "YE",
    states: [
      { name: "Sana'a Governorate", code: "SA", cities: ["Sana'a", "Al Rawdah", "Az Zubayr", "Bani al Harith", "Nihm", "Sanhan", "Jihanah", "Hamdan", "Bani Dhabyan", "Bani Hushaysh"] },
      { name: "Aden Governorate", code: "AD", cities: ["Aden", "Crater", "Mualla", "Tawahi", "Khormaksar", "Dar Sad", "Al Buraiqa", "Ash Sheikh Uthman", "Al Mansoura", "Sirah"] },
      { name: "Taiz Governorate", code: "TA", cities: ["Taiz", "Turbah", "Al Mawasit", "Sabir al Mawadim", "Salh", "Dimnat Khadir", "Al Wazi'iyah", "Hayfan", "Maqbanah", "Jabal Habashy"] },
      { name: "Hodeidah Governorate", code: "HU", cities: ["Hodeidah", "Bajil", "Zabid", "Al Luhayyah", "Az Zaydiyah", "Bayt al Faqih", "Al Jarahi", "Al Mansuriyah", "Ad Durayhimi", "Hays"] },
      { name: "Ibb Governorate", code: "IB", cities: ["Ibb", "Yarim", "Jiblah", "Ba'dan", "Far' al Udayn", "Al Udayn", "Hubaysh", "Al Mashannah", "As Sayyani", "Dhi as Sufal"] }
    ]
  },
  {
    name: "Iraq",
    code: "IQ",
    states: [
      { name: "Baghdad Governorate", code: "BG", cities: ["Baghdad", "Kadhimiya", "Sadr City", "Karrada", "Mansour", "Rusafa", "Karkh", "Abu Ghraib", "Taji", "Mahmudiyah"] },
      { name: "Basra Governorate", code: "BA", cities: ["Basra", "Zubair", "Safwan", "Umm Qasr", "Fao", "Qurna", "Shatt al-Arab", "Abu al-Khasib", "Al-Midaina", "Tanuma"] },
      { name: "Erbil Governorate", code: "AR", cities: ["Erbil", "Shaqlawa", "Koya", "Makhmur", "Rawanduz", "Choman", "Mergasur", "Soran", "Sidakan", "Harir"] },
      { name: "Mosul Governorate", code: "NI", cities: ["Mosul", "Sinjar", "Tal Afar", "Hamdaniya", "Shekhan", "Tilkaif", "Al-Hamdaniya", "Qaraqosh", "Bartella", "Bashiqa"] },
      { name: "Kirkuk Governorate", code: "KI", cities: ["Kirkuk", "Hawija", "Dibis", "Daquq", "Altun Kupri", "Taza Khurmatu", "Shwan", "Chamchamal", "Kalar", "Kifri"] }
    ]
  },
  {
    name: "Iran",
    code: "IR",
    states: [
      { name: "Tehran Province", code: "23", cities: ["Tehran", "Karaj", "Eslamshahr", "Qods", "Varamin", "Shahriar", "Nazarabad", "Baharestan", "Malard", "Robat Karim"] },
      { name: "Isfahan Province", code: "10", cities: ["Isfahan", "Kashan", "Najafabad", "Khorasgan", "Mobarakeh", "Shahin Shahr", "Falavarjan", "Lenjan", "Borkhar", "Natanz"] },
      { name: "Fars Province", code: "14", cities: ["Shiraz", "Marvdasht", "Kazerun", "Jahrom", "Lar", "Firuzabad", "Darab", "Neyriz", "Fasa", "Estahban"] },
      { name: "Khuzestan Province", code: "06", cities: ["Ahvaz", "Abadan", "Khorramshahr", "Dezful", "Masjed Soleyman", "Behbahan", "Izeh", "Shush", "Andimeshk", "Susangerd"] }
    ]
  },
  {
    name: "Cyprus",
    code: "CY",
    states: [
      { name: "Nicosia District", code: "04", cities: ["Nicosia", "Strovolos", "Lakatamia", "Latsia", "Aglantzia", "Engomi", "Dali", "Tseri", "Kokkinotrimithia", "Peristerona"] },
      { name: "Limassol District", code: "03", cities: ["Limassol", "Germasogeia", "Mesa Geitonia", "Agios Athanasios", "Ypsonas", "Parekklisia", "Moni", "Pyrgos", "Erimi", "Kolossi"] },
      { name: "Larnaca District", code: "02", cities: ["Larnaca", "Aradippou", "Livadia", "Dromolaxia", "Meneou", "Pyla", "Kiti", "Tersefanou", "Kellia", "Mazotos"] },
      { name: "Paphos District", code: "05", cities: ["Paphos", "Kato Paphos", "Yeroskipou", "Pegeia", "Polis", "Latchi", "Coral Bay", "Kathikas", "Kissonerga", "Emba"] },
      { name: "Famagusta District", code: "06", cities: ["Famagusta", "Paralimni", "Protaras", "Deryneia", "Sotira", "Frenaros", "Achna", "Xylophagou", "Liopetri", "Avgorou"] }
    ]
  }
];

// Helper functions for fast location lookup
export const getMiddleEastCountries = (): string[] => {
  return middleEastLocationData.map(country => country.name).sort();
};

export const getMiddleEastStatesByCountry = (countryName: string): string[] => {
  const country = middleEastLocationData.find(c => c.name === countryName);
  return country ? country.states.map(state => state.name).sort() : [];
};

export const getMiddleEastCitiesByState = (countryName: string, stateName: string): string[] => {
  const country = middleEastLocationData.find(c => c.name === countryName);
  if (!country) return [];
  
  const state = country.states.find(s => s.name === stateName);
  return state ? state.cities.sort() : [];
};

// Fast search functions
export const searchMiddleEastCountries = (query: string): string[] => {
  const lowerQuery = query.toLowerCase();
  return middleEastLocationData
    .filter(country => country.name.toLowerCase().includes(lowerQuery))
    .map(country => country.name)
    .sort();
};

export const searchMiddleEastStates = (countryName: string, query: string): string[] => {
  const country = middleEastLocationData.find(c => c.name === countryName);
  if (!country) return [];
  
  const lowerQuery = query.toLowerCase();
  return country.states
    .filter(state => state.name.toLowerCase().includes(lowerQuery))
    .map(state => state.name)
    .sort();
};

export const searchMiddleEastCities = (countryName: string, stateName: string, query: string): string[] => {
  const country = middleEastLocationData.find(c => c.name === countryName);
  if (!country) return [];
  
  const state = country.states.find(s => s.name === stateName);
  if (!state) return [];
  
  const lowerQuery = query.toLowerCase();
  return state.cities
    .filter(city => city.toLowerCase().includes(lowerQuery))
    .sort();
};