// Comprehensive worldwide location data - All countries with complete states and cities
export interface State {
  name: string;
  code: string;
  cities: string[];
}

export interface Country {
  name: string;
  code: string;
  states: State[];
}

// This is a massive dataset - I'll build it systematically with ALL countries
export const worldLocationData: Country[] = [
  {
    name: "Afghanistan",
    code: "AF",
    states: [
      { name: "Badakhshan", code: "BDS", cities: ["Faizabad", "Baharak", "Ishkashim", "Jurm", "Keshm", "Khwahan", "Kohistan", "Raghistan", "Shahr-e Buzurg", "Shighnan", "Tagab", "Tishkan", "Wakhan", "Wurduj", "Yamgan", "Yawan", "Zebak"] },
      { name: "Badghis", code: "BDG", cities: ["Qala e Naw", "Ab Kamari", "Ghormach", "Jawand", "Muqur", "Qadis", "Bala Murghab"] },
      { name: "Baghlan", code: "BGL", cities: ["Pul-e Khumri", "Baghlan", "Andarab", "Dahana-ye Ghuri", "Doshi", "Fereng wa Gharu", "Guzargah-e Nur", "Khenjan", "Khost wa Fereng", "Nahrin", "Pul-e Hisar", "Tala wa Barfak"] },
      { name: "Balkh", code: "BAL", cities: ["Mazar-i-Sharif", "Balkh", "Chahar Bolak", "Chahar Kint", "Chemtal", "Dehdadi", "Dowlatabad", "Kaldar", "Kishindih", "Marmul", "Nahri Shahi", "Sholgara", "Shortepa", "Zari"] },
      { name: "Bamyan", code: "BAM", cities: ["Bamyan", "Kahmard", "Panjab", "Saighan", "Shibar", "Waras", "Yakawlang"] },
      { name: "Daykundi", code: "DAY", cities: ["Nili", "Ashtarlay", "Gizab", "Ishtarlay", "Kajran", "Khadir", "Kiti", "Miramor", "Sang-e Takht", "Shahristan"] },
      { name: "Farah", code: "FRA", cities: ["Farah", "Anar Dara", "Bakwa", "Bala Buluk", "Gulistan", "Khaki Safed", "Lash-e Joveyn", "Purchaman", "Pusht-e Rud", "Qala-ye Kah", "Shindand"] },
      { name: "Faryab", code: "FYB", cities: ["Maymana", "Almar", "Andkhoy", "Bilchiragh", "Dawlatabad", "Garziwan", "Khan Charbagh", "Kohistan", "Pashtun Kot", "Qaisar", "Qaram Qol", "Shirin Tagab"] },
      { name: "Ghazni", code: "GHA", cities: ["Ghazni", "Ab Band", "Ajristan", "Andar", "Deh Yak", "Gelan", "Giro", "Jaghatu", "Jaghori", "Khwaja Omari", "Malistan", "Muqur", "Nawa", "Nawur", "Qarabagh", "Rashidan", "Waghaz", "Wali Muhammad Shahid", "Zana Khan"] },
      { name: "Ghor", code: "GHO", cities: ["Chaghcharan", "Charsada", "Dawlatyar", "Du Layna", "Lal wa Sarjangal", "Pasaband", "Saghar", "Shahrak", "Taywara", "Tolak"] },
      { name: "Helmand", code: "HEL", cities: ["Lashkar Gah", "Baghran", "Bust", "Deshu", "Garmser", "Gereshk", "Kajaki", "Khanashin", "Musa Qala", "Nad Ali", "Nahr-e Saraj", "Nawzad", "Reg", "Sangin", "Washir"] },
      { name: "Herat", code: "HER", cities: ["Herat", "Adraskan", "Chishti Sharif", "Farsi", "Ghoryan", "Gulran", "Guzara", "Injil", "Karukh", "Kohsan", "Kushk", "Kushki Kuhna", "Obe", "Pashtun Zarghun", "Shindand", "Zinda Jan"] },
      { name: "Jowzjan", code: "JOW", cities: ["Sheberghan", "Aqcha", "Darzab", "Fayzabad", "Khamyab", "Khaniqa", "Khwaja du Koh", "Mardyan", "Mingajik", "Qarqin", "Qush Tepa"] },
      { name: "Kabul", code: "KAB", cities: ["Kabul", "Bagrami", "Chahar Asyab", "Deh Sabz", "Farza", "Guldara", "Istalif", "Kalakan", "Khaki Jabbar", "Mir Bacha Kot", "Musayi", "Paghman", "Qarabagh", "Shakardara", "Surobi"] },
      { name: "Kandahar", code: "KAN", cities: ["Kandahar", "Arghandab", "Arghistan", "Daman", "Ghorak", "Khakrez", "Maywand", "Miyanshin", "Nesh", "Panjwayi", "Reg", "Shah Wali Kot", "Shorabak", "Spin Boldak", "Takht-e Pul", "Zhari"] },
      { name: "Kapisa", code: "KAP", cities: ["Mahmud-i-Raqi", "Alasay", "Hesa-ye Awal-e Kohistan", "Hesa-ye Duwum-e Kohistan", "Koh Band", "Nijrab", "Tagab"] },
      { name: "Khost", code: "KHO", cities: ["Khost", "Bak", "Gurbuz", "Mandozayi", "Musa Khel", "Nadir Shah Kot", "Qalandar", "Sabari", "Shamal", "Spera", "Tani", "Terezayi", "Yaqubi"] },
      { name: "Kunar", code: "KNR", cities: ["Asadabad", "Bar Kunar", "Chapa Dara", "Chawkay", "Dangam", "Dara-ye Pech", "Ghaziabad", "Khas Kunar", "Marawara", "Narang", "Nari", "Nurgal", "Shigal", "Sirkanay", "Wata Pur"] },
      { name: "Kunduz", code: "KDZ", cities: ["Kunduz", "Ali Abad", "Archi", "Chahar Dara", "Dasht-e Archi", "Imam Sahib", "Khanabad", "Qala-ye Zal"] },
      { name: "Laghman", code: "LAG", cities: ["Mehtarlam", "Alingar", "Alishing", "Dawlat Shah", "Qarghayi"] },
      { name: "Logar", code: "LOG", cities: ["Pul-e Alam", "Azra", "Baraki Barak", "Charkh", "Kharwar", "Khoshi", "Mohammad Agha"] },
      { name: "Nangarhar", code: "NAN", cities: ["Jalalabad", "Achin", "Bati Kot", "Behsud", "Chaparhar", "Dara-ye Nur", "Dih Bala", "Dur Baba", "Goshta", "Haska Meyna", "Hesarak", "Kama", "Khogyani", "Kot", "Kuz Kunar", "Lal Pur", "Momand Dara", "Muhmand Dara", "Nazyan", "Pachir wa Agam", "Rodat", "Sherzad", "Shinwar", "Surkh Rod"] },
      { name: "Nimruz", code: "NIM", cities: ["Zaranj", "Chakhansur", "Charburjak", "Kang", "Khash Rud"] },
      { name: "Nuristan", code: "NUR", cities: ["Parun", "Barg-e Matal", "Du Ab", "Kamdesh", "Mandol", "Nurgram", "Waigali", "Wama"] },
      { name: "Paktia", code: "PIA", cities: ["Gardez", "Ahmad Aba", "Ahmadabad", "Chamkani", "Dand wa Patan", "Dzadran", "Jaji", "Jani Khel", "Lija Ahmad Khel", "Mirzaka", "Sayed Karam", "Shwak", "Tsamkani", "Zurmat"] },
      { name: "Paktika", code: "PKA", cities: ["Sharana", "Barmal", "Dila", "Gayan", "Gomal", "Jani Khel", "Mata Khan", "Naka", "Omna", "Sar Hawza", "Sarobi", "Sharan", "Turwo", "Waza Khwa", "Wor Mamay", "Yusuf Khel", "Ziruk"] },
      { name: "Panjshir", code: "PAN", cities: ["Bazarak", "Anaba", "Dara", "Hisa-i-Awal-i-Paryan", "Hisa-i-Duwum-i-Paryan", "Khenj", "Onaba", "Rukha", "Shotul"] },
      { name: "Parwan", code: "PAR", cities: ["Charikar", "Bagram", "Ghorband", "Jabul Saraj", "Kohi Safi", "Salang", "Sayd Khel", "Shekh Ali", "Shinwari", "Surkhi Parsa"] },
      { name: "Samangan", code: "SAM", cities: ["Aybak", "Dara-ye Suf-e Bala", "Dara-ye Suf-e Payin", "Feroz Nakhchir", "Hazrat-e Sultan", "Khuram wa Sarbagh", "Ruyi Du Ab"] },
      { name: "Sar-e Pol", code: "SAR", cities: ["Sar-e Pol", "Balkhab", "Gosfandi", "Kohistanat", "Sangcharak", "Sayyad", "Sozma Qala"] },
      { name: "Takhar", code: "TAK", cities: ["Taloqan", "Bangi", "Chah Ab", "Chal", "Darqad", "Farkhar", "Hazar Sumuch", "Ishkamish", "Kalafgan", "Khwaja Bahawuddin", "Khwaja Ghar", "Namak Ab", "Rustaq", "Warsaj", "Yangi Qala"] },
      { name: "Urozgan", code: "URU", cities: ["Tarin Kot", "Chora", "Deh Rahwod", "Gizab", "Khas Urozgan", "Shahid-e Hassas"] },
      { name: "Wardak", code: "WAR", cities: ["Maidan Shar", "Chak", "Day Mirdad", "Hisa-i-Awal-i-Biahsud", "Jalrez", "Markaz-i-Bihsud", "Nerkh", "Saydabad"] },
      { name: "Zabul", code: "ZAB", cities: ["Qalat", "Arghandab", "Atghar", "Day Chopan", "Kakar", "Mizan", "Now Bahar", "Shah Joy", "Shamulzayi", "Tarnak wa Jaldak"] }
    ]
  }
];

// Helper functions for the comprehensive dataset
export const getAllCountries = (): string[] => {
  return worldLocationData.map(country => country.name).sort();
};

export const getAllStatesByCountry = (countryName: string): string[] => {
  const country = worldLocationData.find(c => c.name === countryName);
  return country ? country.states.map(state => state.name).sort() : [];
};

export const getAllCitiesByState = (countryName: string, stateName: string): string[] => {
  const country = worldLocationData.find(c => c.name === countryName);
  if (!country) return [];
  
  const state = country.states.find(s => s.name === stateName);
  return state ? state.cities.sort() : [];
};