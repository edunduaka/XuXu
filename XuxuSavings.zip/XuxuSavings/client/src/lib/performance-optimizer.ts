import React, { useCallback, useMemo, useEffect, useRef } from 'react';

// Advanced image optimization and caching
export const useImageOptimization = () => {
  const imageCache = useRef(new Map<string, string>());

  const optimizeImage = useCallback(async (file: File): Promise<File> => {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d')!;
      const img = new Image();
      
      img.onload = () => {
        // Optimize dimensions for faster loading
        const maxWidth = 800;
        const maxHeight = 600;
        const ratio = Math.min(maxWidth / img.width, maxHeight / img.height);
        
        canvas.width = img.width * ratio;
        canvas.height = img.height * ratio;
        
        // High-quality compression
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        
        canvas.toBlob((blob) => {
          if (blob) {
            const optimizedFile = new File([blob], file.name, {
              type: 'image/jpeg',
              lastModified: Date.now()
            });
            resolve(optimizedFile);
          }
        }, 'image/jpeg', 0.85);
      };
      
      img.src = URL.createObjectURL(file);
    });
  }, []);

  const preloadImage = useCallback((src: string) => {
    if (!imageCache.current.has(src)) {
      const img = new Image();
      img.src = src;
      imageCache.current.set(src, src);
    }
  }, []);

  return { optimizeImage, preloadImage };
};

// Smart data caching for faster form loading
export const useSmartCache = () => {
  const cache = useRef(new Map<string, any>());
  const cacheExpiry = useRef(new Map<string, number>());

  const get = useCallback((key: string) => {
    const expiry = cacheExpiry.current.get(key);
    if (expiry && Date.now() > expiry) {
      cache.current.delete(key);
      cacheExpiry.current.delete(key);
      return null;
    }
    return cache.current.get(key);
  }, []);

  const set = useCallback((key: string, value: any, ttl = 5 * 60 * 1000) => {
    cache.current.set(key, value);
    cacheExpiry.current.set(key, Date.now() + ttl);
  }, []);

  return { get, set };
};

// Optimized input debouncing for better performance
export const useOptimizedDebounce = <T extends (...args: any[]) => any>(
  callback: T,
  delay: number = 300
) => {
  const timeoutRef = useRef<NodeJS.Timeout>();
  
  return useCallback((...args: Parameters<T>) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    timeoutRef.current = setTimeout(() => {
      callback(...args);
    }, delay);
  }, [callback, delay]);
};

// Preload critical resources for faster navigation
export const useCriticalResourcePreloader = () => {
  useEffect(() => {
    // Preload location data
    const preloadLocationData = async () => {
      try {
        await fetch('/server/processed-countries.json');
        await fetch('/server/africa-location-data.ts');
        await fetch('/server/middle-east-location-data.ts');
      } catch (error) {
        console.log('Preloading location data...');
      }
    };

    // Preload critical fonts
    const preloadFonts = () => {
      const link = document.createElement('link');
      link.rel = 'preload';
      link.as = 'font';
      link.type = 'font/woff2';
      link.crossOrigin = 'anonymous';
      document.head.appendChild(link);
    };

    // Start preloading after component mount
    setTimeout(() => {
      preloadLocationData();
      preloadFonts();
    }, 100);
  }, []);
};

// Virtual scrolling for large lists (location dropdowns)
export const useVirtualizedList = (
  items: any[],
  itemHeight: number = 40,
  containerHeight: number = 200
) => {
  const visibleItems = useMemo(() => {
    const startIndex = 0;
    const endIndex = Math.min(Math.ceil(containerHeight / itemHeight) + 5, items.length);
    return items.slice(startIndex, endIndex);
  }, [items, itemHeight, containerHeight]);

  return { visibleItems };
};

// Optimized form validation to reduce re-renders
export const useOptimizedValidation = () => {
  const validationCache = useRef(new Map<string, boolean>());

  const validateField = useCallback((field: string, value: any, validator: (val: any) => boolean) => {
    const cacheKey = `${field}-${JSON.stringify(value)}`;
    
    if (validationCache.current.has(cacheKey)) {
      return validationCache.current.get(cacheKey);
    }

    const isValid = validator(value);
    validationCache.current.set(cacheKey, isValid);
    
    // Clear old cache entries to prevent memory leaks
    if (validationCache.current.size > 100) {
      const firstKey = validationCache.current.keys().next().value;
      validationCache.current.delete(firstKey);
    }

    return isValid;
  }, []);

  return { validateField };
};

// Bundle splitting and lazy loading utilities
export const LazyComponent = (importFunction: () => Promise<any>) => {
  return React.lazy(() => importFunction());
};

// Performance monitoring
export const usePerformanceMonitor = () => {
  useEffect(() => {
    const observer = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      entries.forEach((entry) => {
        if (entry.entryType === 'measure') {
          console.log(`Performance: ${entry.name} took ${entry.duration.toFixed(2)}ms`);
        }
      });
    });

    observer.observe({ entryTypes: ['measure', 'navigation'] });

    return () => observer.disconnect();
  }, []);

  const measurePerformance = useCallback((name: string, fn: () => void) => {
    performance.mark(`${name}-start`);
    fn();
    performance.mark(`${name}-end`);
    performance.measure(name, `${name}-start`, `${name}-end`);
  }, []);

  return { measurePerformance };
};