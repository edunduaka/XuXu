import { apiRequest } from "@/lib/queryClient";

export interface PersonalInfo {
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  gender: string;
  selfieImage?: string;
}

export interface IDDocument {
  idType: string;
  documentImage: string;
}

export interface KYCValidationResult {
  success: boolean;
  confidence: number;
  matchedFields: string[];
  unmatchedFields: string[];
  message: string;
  details: {
    documentVerification: boolean;
    governmentIdVerification: boolean;
    biometricAuthentication: boolean;
    amlCheck: boolean;
  };
}

export class KYCValidator {
  private readonly documentVerificationAPI = import.meta.env.VITE_DOCUMENT_VERIFICATION_API;
  private readonly governmentIdAPI = import.meta.env.VITE_GOVERNMENT_ID_API;
  private readonly biometricAPI = import.meta.env.VITE_BIOMETRIC_API;
  private readonly amlAPI = import.meta.env.VITE_AML_CHECK_API;

  async validateKYC(personalInfo: PersonalInfo, idDocument: IDDocument): Promise<KYCValidationResult> {
    try {
      // Step 1: Document Verification API
      const documentVerification = await this.verifyDocument(idDocument);
      
      // Step 2: Government ID Verification API
      const governmentIdVerification = await this.verifyGovernmentId(idDocument);
      
      // Step 3: Biometric Authentication API
      const biometricAuthentication = await this.authenticateBiometric(personalInfo.selfieImage, idDocument.documentImage);
      
      // Step 4: AML Check API
      const amlCheck = await this.performAMLCheck(personalInfo);
      
      // Compare extracted data with personal information
      const comparisonResult = await this.compareData(personalInfo, documentVerification.extractedData);
      
      return {
        success: documentVerification.valid && 
                governmentIdVerification.valid && 
                biometricAuthentication.valid && 
                amlCheck.valid && 
                comparisonResult.matchRate > 0.8,
        confidence: comparisonResult.matchRate,
        matchedFields: comparisonResult.matchedFields,
        unmatchedFields: comparisonResult.unmatchedFields,
        message: this.generateValidationMessage(comparisonResult),
        details: {
          documentVerification: documentVerification.valid,
          governmentIdVerification: governmentIdVerification.valid,
          biometricAuthentication: biometricAuthentication.valid,
          amlCheck: amlCheck.valid
        }
      };
    } catch (error) {
      return {
        success: false,
        confidence: 0,
        matchedFields: [],
        unmatchedFields: ['firstName', 'lastName', 'dateOfBirth', 'gender'],
        message: 'KYC validation failed due to technical error. Please try again.',
        details: {
          documentVerification: false,
          governmentIdVerification: false,
          biometricAuthentication: false,
          amlCheck: false
        }
      };
    }
  }

  private async verifyDocument(idDocument: IDDocument) {
    // Document Verification API call
    return await apiRequest("POST", "/api/kyc/verify-document", {
      documentType: idDocument.idType,
      documentImage: idDocument.documentImage
    });
  }

  private async verifyGovernmentId(idDocument: IDDocument) {
    // Government ID Verification API call
    return await apiRequest("POST", "/api/kyc/verify-government-id", {
      documentType: idDocument.idType,
      documentImage: idDocument.documentImage
    });
  }

  private async authenticateBiometric(selfieImage: string | undefined, documentImage: string) {
    // Skip biometric authentication if no selfie image is provided
    if (!selfieImage) {
      return { success: true, confidence: 0 };
    }
    
    // Biometric Authentication API call
    return await apiRequest("POST", "/api/kyc/authenticate-biometric", {
      selfieImage,
      documentImage
    });
  }

  private async performAMLCheck(personalInfo: PersonalInfo) {
    // AML Check API call
    return await apiRequest("POST", "/api/kyc/aml-check", {
      firstName: personalInfo.firstName,
      lastName: personalInfo.lastName,
      dateOfBirth: personalInfo.dateOfBirth
    });
  }

  private async compareData(personalInfo: PersonalInfo, extractedData: any) {
    const matchedFields: string[] = [];
    const unmatchedFields: string[] = [];
    const detailedComparison: any = {};
    
    // Compare First Name with detailed analysis
    const normalizedPersonalFirstName = this.normalizeString(personalInfo.firstName);
    const normalizedExtractedFirstName = this.normalizeString(extractedData.firstName || '');
    
    if (normalizedPersonalFirstName === normalizedExtractedFirstName) {
      matchedFields.push('firstName');
      detailedComparison.firstName = { match: true, personal: personalInfo.firstName, document: extractedData.firstName };
    } else {
      unmatchedFields.push('firstName');
      detailedComparison.firstName = { 
        match: false, 
        personal: personalInfo.firstName, 
        document: extractedData.firstName || 'Not found on ID',
        reason: 'Name on ID document does not match personal information'
      };
    }
    
    // Compare Last Name with detailed analysis
    const normalizedPersonalLastName = this.normalizeString(personalInfo.lastName);
    const normalizedExtractedLastName = this.normalizeString(extractedData.lastName || '');
    
    if (normalizedPersonalLastName === normalizedExtractedLastName) {
      matchedFields.push('lastName');
      detailedComparison.lastName = { match: true, personal: personalInfo.lastName, document: extractedData.lastName };
    } else {
      unmatchedFields.push('lastName');
      detailedComparison.lastName = { 
        match: false, 
        personal: personalInfo.lastName, 
        document: extractedData.lastName || 'Not found on ID',
        reason: 'Last name on ID document does not match personal information'
      };
    }
    
    // Compare Date of Birth with detailed analysis
    const normalizedPersonalDOB = this.normalizeDateOfBirth(personalInfo.dateOfBirth);
    const normalizedExtractedDOB = this.normalizeDateOfBirth(extractedData.dateOfBirth || '');
    
    if (normalizedPersonalDOB === normalizedExtractedDOB) {
      matchedFields.push('dateOfBirth');
      detailedComparison.dateOfBirth = { match: true, personal: personalInfo.dateOfBirth, document: extractedData.dateOfBirth };
    } else {
      unmatchedFields.push('dateOfBirth');
      detailedComparison.dateOfBirth = { 
        match: false, 
        personal: personalInfo.dateOfBirth, 
        document: extractedData.dateOfBirth || 'Not found on ID',
        reason: 'Date of birth on ID document does not match personal information'
      };
    }
    
    // Compare Gender with detailed analysis
    const normalizedPersonalGender = this.normalizeString(personalInfo.gender);
    const normalizedExtractedGender = this.normalizeString(extractedData.gender || '');
    
    if (normalizedPersonalGender === normalizedExtractedGender) {
      matchedFields.push('gender');
      detailedComparison.gender = { match: true, personal: personalInfo.gender, document: extractedData.gender };
    } else {
      unmatchedFields.push('gender');
      detailedComparison.gender = { 
        match: false, 
        personal: personalInfo.gender, 
        document: extractedData.gender || 'Not found on ID',
        reason: 'Gender on ID document does not match personal information'
      };
    }
    
    const matchRate = matchedFields.length / 4; // Total of 4 fields to compare
    
    return {
      matchedFields,
      unmatchedFields,
      matchRate,
      detailedComparison
    };
  }

  private normalizeString(str: string): string {
    return str?.toLowerCase().trim().replace(/\s+/g, ' ') || '';
  }

  private normalizeDateOfBirth(dateStr: string): string {
    // Normalize date format for comparison
    const date = new Date(dateStr);
    return date.toISOString().split('T')[0];
  }

  private generateValidationMessage(comparisonResult: any): string {
    if (comparisonResult.matchRate >= 0.9) {
      return 'KYC validation successful! All information matches your ID document.';
    } else if (comparisonResult.matchRate >= 0.7) {
      return 'KYC validation partially successful. Some information may need review.';
    } else {
      return 'KYC validation failed. The information provided does not match your ID document.';
    }
  }
}

export const kycValidator = new KYCValidator();