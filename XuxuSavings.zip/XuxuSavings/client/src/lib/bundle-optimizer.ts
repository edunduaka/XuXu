// Bundle size optimization and smart caching
import { useMemo, useEffect } from 'react';

// Optimize country data loading
export const useOptimizedLocationData = () => {
  const cachedCountries = useMemo(() => {
    // Load countries data only once and cache it
    return new Promise(async (resolve) => {
      try {
        const { getAllCountries } = await import('@/lib/utils/comprehensive-world-locations');
        resolve(getAllCountries());
      } catch (error) {
        console.warn('Failed to load location data:', error);
        resolve([]);
      }
    });
  }, []);

  return { cachedCountries };
};

// Smart component chunking
export const useLazyChunks = () => {
  useEffect(() => {
    // Preload critical chunks during idle time
    if ('requestIdleCallback' in window) {
      requestIdleCallback(() => {
        // Preload registration components
        import('@/components/registration/ProgressSteps');
        import('@/components/ui/select');
        import('@/components/ui/radio-group');
      });
    }
  }, []);
};

// Memory optimization for large lists
export const useMemoryOptimizedList = (items: any[], chunkSize = 50) => {
  return useMemo(() => {
    const chunks = [];
    for (let i = 0; i < items.length; i += chunkSize) {
      chunks.push(items.slice(i, i + chunkSize));
    }
    return chunks;
  }, [items, chunkSize]);
};

// Fast form field optimization
export const useOptimizedFormFields = () => {
  return useMemo(() => ({
    // Pre-generate common validation patterns
    emailPattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    phonePattern: /^\+?[\d\s\-\(\)]+$/,
    namePattern: /^[a-zA-Z\s\-\']+$/,
  }), []);
};